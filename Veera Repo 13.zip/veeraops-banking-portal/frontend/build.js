const fs = require("fs");
const path = require("path");

const publicDir = path.join(__dirname, "public");
const distDir = path.join(__dirname, "dist");

function copyDirectory(source, target) {
  fs.mkdirSync(target, { recursive: true });

  for (const entry of fs.readdirSync(source, { withFileTypes: true })) {
    const sourcePath = path.join(source, entry.name);
    const targetPath = path.join(target, entry.name);

    if (entry.isDirectory()) {
      copyDirectory(sourcePath, targetPath);
      continue;
    }

    fs.copyFileSync(sourcePath, targetPath);
  }
}

if (!fs.existsSync(publicDir)) {
  throw new Error("public directory not found");
}

fs.rmSync(distDir, { recursive: true, force: true });
copyDirectory(publicDir, distDir);

console.log("Frontend build created in dist/");
