const { useEffect, useState } = React;

const apiUrl = window.APP_CONFIG?.apiUrl || "http://localhost:4000";
const portalMode =
  window.PORTAL_MODE === "admin"
    ? "admin"
    : window.PORTAL_MODE === "ifsc"
      ? "ifsc"
      : "customer";

async function request(path, options = {}) {
  const response = await fetch(`${apiUrl}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options
  });

  const rawText = await response.text();
  let data;

  try {
    data = rawText ? JSON.parse(rawText) : {};
  } catch (parseError) {
    const htmlResponse = rawText.trim().startsWith("<");
    const fallbackMessage = htmlResponse
      ? "The API returned an HTML page instead of JSON. Please restart the backend server."
      : "The API returned an invalid response.";

    throw new Error(fallbackMessage);
  }

  if (!response.ok) {
    throw new Error(data.message || "Request failed");
  }

  return data;
}

function formatCurrency(value) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 0
  }).format(Number(value || 0));
}

function maskCard(cardNumber) {
  return `**** ${String(cardNumber).slice(-4)}`;
}

function formatDate(value) {
  if (!value) {
    return "-";
  }

  return new Date(value).toLocaleString("en-IN", {
    dateStyle: "medium",
    timeStyle: "short"
  });
}

function formatPercent(value) {
  return `${Number(value || 0).toFixed(2)}%`;
}

function withEmailNotice(message, result) {
  return result?.emailMessage ? `${message}. ${result.emailMessage}` : message;
}

function calculateLoanPreview(principalAmount, annualInterestRate, tenureMonths) {
  const principal = Number(principalAmount || 0);
  const annualRate = Number(annualInterestRate || 0);
  const months = Number(tenureMonths || 0);

  if (!principal || !months) {
    return { emiAmount: 0, totalPayableAmount: 0 };
  }

  const monthlyRate = annualRate / 12 / 100;

  if (!monthlyRate) {
    const emiAmount = principal / months;
    return {
      emiAmount,
      totalPayableAmount: emiAmount * months
    };
  }

  const factor = Math.pow(1 + monthlyRate, months);
  const emiAmount = (principal * monthlyRate * factor) / (factor - 1);

  return {
    emiAmount,
    totalPayableAmount: emiAmount * months
  };
}

function getPasswordChecklist(password) {
  const value = String(password || "");

  return {
    length: value.length >= 8,
    uppercase: /[A-Z]/.test(value),
    lowercase: /[a-z]/.test(value),
    number: /\d/.test(value),
    special: /[^A-Za-z0-9]/.test(value)
  };
}

function getPasswordStrength(password) {
  const checks = getPasswordChecklist(password);
  const score = Object.values(checks).filter(Boolean).length;

  if (score <= 2) {
    return { score, label: "Weak" };
  }

  if (score <= 4) {
    return { score, label: "Medium" };
  }

  return { score, label: "Strong" };
}

function LoginView({
  authView,
  onAuthViewChange,
  onLogin,
  onRegister,
  onStatusCheck,
  loading,
  error,
  notice,
  statusResult,
  branches,
  branchLoading,
  branchLoadError,
  onRetryBranches
}) {
  const [loginForm, setLoginForm] = useState({
    email: "",
    password: "",
    accountNumber: "",
    phone: ""
  });
  const [registerForm, setRegisterForm] = useState({
    fullName: "",
    email: "",
    phone: "",
    city: "",
    password: "",
    confirmPassword: "",
    requestedAccountType: "savings",
    requestedBranch: "",
    employmentStatus: "",
    employerName: "",
    monthlyIncome: "",
    businessName: "",
    businessAddress: ""
  });
  const [verificationState, setVerificationState] = useState({
    emailOtp: "",
    emailMessage: "",
    emailVerified: false,
    emailVerificationToken: ""
  });
  const [verificationLoading, setVerificationLoading] = useState({
    emailSend: false,
    emailVerify: false
  });
  const [statusForm, setStatusForm] = useState({
    phone: "",
    email: "",
    password: "",
    city: "",
    requestedBranch: ""
  });

  useEffect(() => {
    setLoginForm({
      email: "",
      password: "",
      accountNumber: "",
      phone: ""
    });
    setStatusForm({
      phone: "",
      email: "",
      password: "",
      city: "",
      requestedBranch: ""
    });
  }, []);

  useEffect(() => {
    setRegisterForm((current) => ({
      ...current,
      city: current.city || "",
      requestedBranch: current.requestedBranch || ""
    }));
  }, [branches]);

  function submitLogin(event) {
    event.preventDefault();
    onLogin(loginForm);
  }

  function submitRegister(event) {
    event.preventDefault();
    onRegister({
      ...registerForm,
      emailVerificationToken: verificationState.emailVerificationToken
    });
  }

  function submitStatus(event) {
    event.preventDefault();
    onStatusCheck(statusForm);
  }

  const isAdminPortal = portalMode === "admin";
  const branchCities = Array.from(new Set(branches.map((branch) => branch.city))).sort((a, b) =>
    a.localeCompare(b)
  );
  const cityBranches = branches
    .filter((branch) => branch.city === registerForm.city)
    .sort((a, b) => a.branch_name.localeCompare(b.branch_name));
  const statusCityBranches = branches
    .filter((branch) => branch.city === statusForm.city)
    .sort((a, b) => a.branch_name.localeCompare(b.branch_name));
  const customerHeading =
    authView === "register"
      ? "Customer Registration"
      : authView === "status"
        ? "Account Status Check"
        : "Customer Login";

  const customerHelper =
    authView === "register"
      ? "Verify your Gmail address with OTP before submitting the account request."
      : authView === "status"
        ? "Use mobile number, email, password, city, and branch to track approval or rejection."
        : "Login with account number, mobile number, and password after approval.";
  const passwordChecklist = getPasswordChecklist(registerForm.password);
  const passwordStrength = getPasswordStrength(registerForm.password);
  const passwordsMatch =
    registerForm.confirmPassword &&
    registerForm.password === registerForm.confirmPassword;
  const isRegisterReady =
    verificationState.emailVerified && passwordStrength.score === 5 && passwordsMatch;

  async function handleSendOtp() {
    const value = registerForm.email;

    setVerificationLoading((current) => ({ ...current, emailSend: true }));

    try {
      const result = await request("/api/verification/send-otp", {
        method: "POST",
        body: JSON.stringify({
          channel: "email",
          value
        })
      });

      setVerificationState((current) => ({
        ...current,
        emailMessage: `${result.message}${result.previewOtp ? ` Demo OTP: ${result.previewOtp}` : ""}`,
        emailVerified: false,
        emailVerificationToken: ""
      }));
    } catch (sendError) {
      setVerificationState((current) => ({
        ...current,
        emailMessage: sendError.message,
        emailVerified: false,
        emailVerificationToken: ""
      }));
    } finally {
      setVerificationLoading((current) => ({ ...current, emailSend: false }));
    }
  }

  async function handleVerifyOtp() {
    const value = registerForm.email;
    const otp = verificationState.emailOtp;

    setVerificationLoading((current) => ({ ...current, emailVerify: true }));

    try {
      const result = await request("/api/verification/verify-otp", {
        method: "POST",
        body: JSON.stringify({
          channel: "email",
          value,
          otp
        })
      });

      setVerificationState((current) => ({
        ...current,
        emailMessage: result.message,
        emailVerified: true,
        emailVerificationToken: result.verificationToken
      }));
    } catch (verifyError) {
      setVerificationState((current) => ({
        ...current,
        emailMessage: verifyError.message,
        emailVerified: false,
        emailVerificationToken: ""
      }));
    } finally {
      setVerificationLoading((current) => ({ ...current, emailVerify: false }));
    }
  }

  return (
    <div className={`app-shell ${isAdminPortal ? "admin-shell" : ""}`}>
      <section className={`hero ${isAdminPortal ? "admin-hero" : ""}`}>
        <div className="topbar">
          <div>
            <div className="small">Veeraops Bank</div>
            <h1>{isAdminPortal ? "Admin Portal" : "Customer Portal"}</h1>
            <p className="subtext">
              {isAdminPortal
                ? "Premium control center for approvals, customer oversight, and branch-aware banking operations."
                : "Modern customer banking with clear account access, branch identity, transfer support, and full debit and credit visibility."}
            </p>
          </div>
          <a className="secondary-button portal-link" href="/">
            All Portals
          </a>
        </div>

        {!isAdminPortal ? (
          <div className="mode-switch">
            <button
              className={authView === "login" ? "active" : ""}
              onClick={() => onAuthViewChange("login")}
            >
              Customer Login
            </button>
            <button
              className={authView === "register" ? "active" : ""}
              onClick={() => onAuthViewChange("register")}
            >
              Create Account Request
            </button>
            <button
              className={authView === "status" ? "active" : ""}
              onClick={() => onAuthViewChange("status")}
            >
              Check Status
            </button>
          </div>
        ) : null}
      </section>

      <section className="login-card">
        <div className="panel-head">
          <div>
            <h2>{isAdminPortal ? "Admin Login" : customerHeading}</h2>
            <p className="helper">
              {isAdminPortal
                ? "Admins can review applications, approve customers, reject incomplete requests, and monitor branch-linked account activity."
                : customerHelper}
            </p>
          </div>
        </div>

        {isAdminPortal || authView === "login" ? (
          <form className="form-grid" onSubmit={submitLogin}>
            {isAdminPortal ? (
              <>
                <input
                  value={loginForm.email}
                  onChange={(event) => setLoginForm({ ...loginForm, email: event.target.value })}
                  placeholder="Admin Email"
                  type="email"
                />
                <input
                  value={loginForm.password}
                  onChange={(event) => setLoginForm({ ...loginForm, password: event.target.value })}
                  placeholder="Password"
                  type="password"
                />
              </>
            ) : (
              <>
                <input
                  value={loginForm.accountNumber}
                  onChange={(event) =>
                    setLoginForm({ ...loginForm, accountNumber: event.target.value })
                  }
                  placeholder="Account Number"
                />
                <input
                  value={loginForm.phone}
                  onChange={(event) => setLoginForm({ ...loginForm, phone: event.target.value })}
                  placeholder="Mobile Number"
                />
                <input
                  value={loginForm.password}
                  onChange={(event) => setLoginForm({ ...loginForm, password: event.target.value })}
                  placeholder="Password"
                  type="password"
                />
              </>
            )}
            <button className="primary-button" disabled={loading} type="submit">
              {loading ? "Please wait..." : "Login"}
            </button>
          </form>
        ) : null}

        {!isAdminPortal && authView === "register" ? (
          <form className="form-grid" onSubmit={submitRegister}>
            <div className="field-block">
              <label className="field-label">Full Name</label>
            <input
              value={registerForm.fullName}
              onChange={(event) =>
                setRegisterForm({ ...registerForm, fullName: event.target.value })
              }
              placeholder="Full Name"
            />
            </div>
            <div className="field-block">
              <label className="field-label">Email</label>
            <input
              value={registerForm.email}
              onChange={(event) => {
                setRegisterForm({ ...registerForm, email: event.target.value });
                setVerificationState((current) => ({
                  ...current,
                  emailOtp: "",
                  emailMessage: "",
                  emailVerified: false,
                  emailVerificationToken: ""
                }));
              }}
              placeholder="Email"
              type="email"
            />
            <div className="otp-row">
              <button
                className="secondary-button"
                disabled={!registerForm.email || verificationLoading.emailSend}
                onClick={() => handleSendOtp()}
                type="button"
              >
                {verificationLoading.emailSend
                  ? "Sending..."
                  : verificationState.emailMessage
                    ? "Resend OTP"
                    : "Send Email OTP"}
              </button>
              <input
                value={verificationState.emailOtp}
                onChange={(event) =>
                  setVerificationState({ ...verificationState, emailOtp: event.target.value })
                }
                placeholder="Enter Email OTP"
              />
              <button
                className="primary-button"
                disabled={!verificationState.emailOtp || verificationLoading.emailVerify}
                onClick={() => handleVerifyOtp()}
                type="button"
              >
                {verificationLoading.emailVerify ? "Verifying..." : "Verify Email"}
              </button>
            </div>
            {verificationState.emailMessage ? (
              <div className={verificationState.emailVerified ? "notice" : "notice notice-error"}>
                {verificationState.emailMessage}
              </div>
            ) : null}
            </div>
            <div className="field-block">
              <label className="field-label">Mobile Number</label>
            <input
              value={registerForm.phone}
              onChange={(event) => {
                setRegisterForm({ ...registerForm, phone: event.target.value });
              }}
              placeholder="Mobile Number"
            />
            </div>
            <div className="field-block">
              <label className="field-label">City</label>
            <select
              value={registerForm.city}
              onChange={(event) =>
                setRegisterForm({
                  ...registerForm,
                  city: event.target.value,
                  requestedBranch: ""
                })
              }
              disabled={branchLoading || (!branches.length && !branchLoadError)}
            >
              <option value="">
                {branchLoading
                  ? "Loading Cities..."
                  : branchLoadError
                    ? "Unable To Load Cities"
                    : branches.length
                      ? "Select City"
                      : "No Cities Available"}
              </option>
              {branchCities.map((city) => (
                <option key={city} value={city}>
                  {city}
                </option>
              ))}
            </select>
            {branchLoadError ? (
              <>
                <div className="notice notice-error">
                  {branchLoadError}
                </div>
                <button className="secondary-button inline-button" onClick={onRetryBranches} type="button">
                  Retry City Load
                </button>
              </>
            ) : null}
            </div>
            <div className="field-block">
              <label className="field-label">Password</label>
            <input
              value={registerForm.password}
              onChange={(event) =>
                setRegisterForm({ ...registerForm, password: event.target.value })
              }
              placeholder="Password"
              type="password"
            />
            <div className={`password-meter password-${passwordStrength.label.toLowerCase()}`}>
              Password Strength: {passwordStrength.label}
            </div>
            <div className="password-rules">
              <span className={`password-rule ${passwordChecklist.length ? "valid" : "invalid"}`}>
                8+ Characters
              </span>
              <span className={`password-rule ${passwordChecklist.uppercase ? "valid" : "invalid"}`}>
                Uppercase
              </span>
              <span className={`password-rule ${passwordChecklist.lowercase ? "valid" : "invalid"}`}>
                Lowercase
              </span>
              <span className={`password-rule ${passwordChecklist.number ? "valid" : "invalid"}`}>
                Number
              </span>
              <span className={`password-rule ${passwordChecklist.special ? "valid" : "invalid"}`}>
                Special Character
              </span>
            </div>
            </div>
            <div className="field-block">
              <label className="field-label">Confirm Password</label>
            <input
              value={registerForm.confirmPassword}
              onChange={(event) =>
                setRegisterForm({ ...registerForm, confirmPassword: event.target.value })
              }
              placeholder="Confirm Password"
              type="password"
            />
            {registerForm.confirmPassword ? (
              <div className={passwordsMatch ? "notice" : "notice notice-error"}>
                {passwordsMatch ? "Password confirmed." : "Password and confirm password must match."}
              </div>
            ) : null}
            </div>
            <div className="field-block">
              <label className="field-label">Account Type</label>
            <select
              value={registerForm.requestedAccountType}
              onChange={(event) =>
                setRegisterForm({
                  ...registerForm,
                  requestedAccountType: event.target.value,
                  employmentStatus: "",
                  employerName: "",
                  monthlyIncome: "",
                  businessName: "",
                  businessAddress: ""
                })
              }
            >
              <option value="savings">Savings</option>
              <option value="salary">Salary</option>
              <option value="current">Current</option>
            </select>
            </div>
            {registerForm.requestedAccountType === "salary" ? (
              <>
                <div className="field-block">
                  <label className="field-label">Employment Type</label>
                <select
                  value={registerForm.employmentStatus}
                  onChange={(event) =>
                    setRegisterForm({ ...registerForm, employmentStatus: event.target.value })
                  }
                >
                  <option value="">Select Employment Type</option>
                  <option value="salaried">Salaried</option>
                  <option value="contract">Contract Employee</option>
                  <option value="government">Government Employee</option>
                  <option value="private">Private Employee</option>
                </select>
                </div>
                <div className="field-block">
                  <label className="field-label">Company Name</label>
                <input
                  value={registerForm.employerName}
                  onChange={(event) =>
                    setRegisterForm({ ...registerForm, employerName: event.target.value })
                  }
                  placeholder="Company / Employer Name"
                />
                </div>
                <div className="field-block">
                  <label className="field-label">Monthly Salary</label>
                <input
                  value={registerForm.monthlyIncome}
                  onChange={(event) =>
                    setRegisterForm({ ...registerForm, monthlyIncome: event.target.value })
                  }
                  placeholder="Monthly Salary"
                  type="number"
                />
                </div>
              </>
            ) : null}
            {registerForm.requestedAccountType === "current" ? (
              <>
                <div className="field-block">
                  <label className="field-label">Employment Type</label>
                <select
                  value={registerForm.employmentStatus}
                  onChange={(event) =>
                    setRegisterForm({ ...registerForm, employmentStatus: event.target.value })
                  }
                >
                  <option value="">Select Employment Type</option>
                  <option value="salaried">Salaried</option>
                  <option value="self-employed">Self Employed</option>
                  <option value="business-owner">Business Owner</option>
                  <option value="professional">Professional</option>
                </select>
                </div>
                <div className="field-block">
                  <label className="field-label">Employer / Organization</label>
                <input
                  value={registerForm.employerName}
                  onChange={(event) =>
                    setRegisterForm({ ...registerForm, employerName: event.target.value })
                  }
                  placeholder="Employer / Organization Name"
                />
                </div>
                <div className="field-block">
                  <label className="field-label">Monthly Income</label>
                <input
                  value={registerForm.monthlyIncome}
                  onChange={(event) =>
                    setRegisterForm({ ...registerForm, monthlyIncome: event.target.value })
                  }
                  placeholder="Monthly Income"
                  type="number"
                />
                </div>
                <div className="field-block">
                  <label className="field-label">Business Name</label>
                <input
                  value={registerForm.businessName}
                  onChange={(event) =>
                    setRegisterForm({ ...registerForm, businessName: event.target.value })
                  }
                  placeholder="Business / Firm Name"
                />
                </div>
                <div className="field-block">
                  <label className="field-label">Business Address</label>
                <input
                  value={registerForm.businessAddress}
                  onChange={(event) =>
                    setRegisterForm({ ...registerForm, businessAddress: event.target.value })
                  }
                  placeholder="Business Address"
                />
                </div>
              </>
            ) : null}
            <div className="field-block">
              <label className="field-label">Branch</label>
            <select
              value={registerForm.requestedBranch}
              onChange={(event) =>
                setRegisterForm({ ...registerForm, requestedBranch: event.target.value })
              }
              disabled={!registerForm.city}
            >
              <option value="">{registerForm.city ? "Select Branch" : "Select City First"}</option>
              {cityBranches.map((branch) => (
                <option key={branch.ifsc_code} value={branch.branch_name}>
                  {branch.branch_name} | {branch.ifsc_code}
                </option>
              ))}
            </select>
            </div>
            <button className="primary-button" disabled={loading || !isRegisterReady} type="submit">
              {loading ? "Submitting..." : "Submit Request"}
            </button>
            {!isRegisterReady ? (
              <div className="notice notice-error">
                Complete email OTP, strong password, and confirm password before submitting.
              </div>
            ) : null}
          </form>
        ) : null}

        {!isAdminPortal && authView === "status" ? (
          <>
            <form className="form-grid" onSubmit={submitStatus}>
              <input
                value={statusForm.phone}
                onChange={(event) => setStatusForm({ ...statusForm, phone: event.target.value })}
                placeholder="Mobile Number"
              />
              <input
                value={statusForm.email}
                onChange={(event) => setStatusForm({ ...statusForm, email: event.target.value })}
                placeholder="Email"
                type="email"
              />
              <input
                value={statusForm.password}
                onChange={(event) =>
                  setStatusForm({ ...statusForm, password: event.target.value })
                }
                placeholder="Password"
                type="password"
              />
              <select
                value={statusForm.city}
                onChange={(event) =>
                  setStatusForm({
                    ...statusForm,
                    city: event.target.value,
                    requestedBranch: ""
                  })
                }
                disabled={branchLoading || (!branches.length && !branchLoadError)}
              >
                <option value="">
                  {branchLoading
                    ? "Loading Cities..."
                    : branchLoadError
                      ? "Unable To Load Cities"
                      : branches.length
                        ? "Select City"
                        : "No Cities Available"}
                </option>
                {branchCities.map((city) => (
                  <option key={city} value={city}>
                    {city}
                  </option>
                ))}
              </select>
              <select
                value={statusForm.requestedBranch}
                onChange={(event) =>
                  setStatusForm({ ...statusForm, requestedBranch: event.target.value })
                }
                disabled={!statusForm.city}
              >
                <option value="">{statusForm.city ? "Select Branch" : "Select City First"}</option>
                {statusCityBranches.map((branch) => (
                  <option key={branch.ifsc_code} value={branch.branch_name}>
                    {branch.branch_name}
                  </option>
                ))}
              </select>
              <button className="primary-button" disabled={loading} type="submit">
                {loading ? "Checking..." : "Check Account Status"}
              </button>
            </form>

            {statusResult ? (
              <div className="status-card">
                <div className={`status-badge status-${statusResult.status}`}>
                  {String(statusResult.status).toUpperCase()}
                </div>
                <h3>{statusResult.customer.fullName}</h3>
                <div className="status-detail-grid">
                  <div className="status-detail-item">
                    <div className="small">Mobile</div>
                    <strong>{statusResult.customer.phone}</strong>
                  </div>
                  <div className="status-detail-item">
                    <div className="small">Email</div>
                    <strong>{statusResult.customer.email}</strong>
                  </div>
                  <div className="status-detail-item">
                    <div className="small">City</div>
                    <strong>{statusResult.customer.city || "-"}</strong>
                  </div>
                  <div className="status-detail-item">
                    <div className="small">Requested Branch</div>
                    <strong>{statusResult.customer.requestedBranch || "-"}</strong>
                  </div>
                </div>
                <div className="helper">
                  Requested account type: {statusResult.customer.requestedAccountType}
                </div>
                {statusResult.status === "approved" ? (
                  <>
                    <div className="metric-value">{statusResult.accountNumber}</div>
                    <div className="status-detail-grid">
                      <div className="status-detail-item">
                        <div className="small">Approved Account Type</div>
                        <strong>{statusResult.accountType}</strong>
                      </div>
                      <div className="status-detail-item">
                        <div className="small">Approved Branch</div>
                        <strong>{statusResult.branch || "-"}</strong>
                      </div>
                    </div>
                    <div className="helper">IFSC: {statusResult.ifscCode || "-"}</div>
                  </>
                ) : null}
                {statusResult.status === "pending" ? (
                  <div className="notice">
                    Your request is still pending admin review. Please check again later.
                  </div>
                ) : null}
                {statusResult.status === "rejected" ? (
                  <div className="notice notice-error">{statusResult.rejectionReason}</div>
                ) : null}
              </div>
            ) : null}
          </>
        ) : null}

        {error ? <div className="notice notice-error">{error}</div> : null}
        {notice ? <div className="notice">{notice}</div> : null}
      </section>
    </div>
  );
}

function MetricCard({ label, value }) {
  return (
    <article className="metric-card">
      <h3>{label}</h3>
      <div className="metric-value">{value}</div>
    </article>
  );
}

function TransactionHistory({ transactions, title }) {
  return (
    <section className="panel" style={{ marginTop: "18px" }}>
      <div className="panel-head">
        <h2>{title}</h2>
      </div>
      <div className="tx-list">
        {transactions.length ? (
          transactions.map((tx) => (
            <div className={`tx-card ${tx.direction}`} key={tx.id}>
              <div className="tx-row">
                <strong>{tx.description}</strong>
                <span className={`amount ${tx.direction}`}>{formatCurrency(tx.amount)}</span>
              </div>
              <div className="tx-meta">
                {tx.transaction_type} | {tx.channel} | {tx.reference_code}
              </div>
              <div className="tx-meta">
                Mode: {tx.transfer_mode || "internal"} | Recipient:{" "}
                {tx.recipient_account_number || "-"}
              </div>
              <div className="tx-meta">
                Bank: {tx.recipient_bank_name || "Veeraops Bank"} | IFSC: {tx.recipient_ifsc || "-"}
              </div>
              {"running_balance" in tx ? (
                <div className="tx-meta">
                  Running balance {formatCurrency(tx.running_balance)}
                </div>
              ) : null}
              <div className="tx-meta">{formatDate(tx.created_at)}</div>
            </div>
          ))
        ) : (
          <div className="empty-state">No transactions available yet.</div>
        )}
      </div>
    </section>
  );
}

function IfscFinder({ branches }) {
  const [selectedCity, setSelectedCity] = useState("");
  const [selectedBranch, setSelectedBranch] = useState("");

  const cities = Array.from(new Set(branches.map((branch) => branch.city))).sort((a, b) =>
    a.localeCompare(b)
  );
  const cityBranches = branches
    .filter((branch) => branch.city === selectedCity)
    .sort((a, b) => a.branch_name.localeCompare(b.branch_name));
  const selectedBranchDetails = cityBranches.find(
    (branch) => branch.branch_name === selectedBranch
  );

  return (
    <div className="app-shell admin-shell">
      <section className="hero admin-hero">
        <div className="topbar">
          <div>
            <div className="small">Veeraops Bank</div>
            <h1>IFSC Finder</h1>
            <p className="subtext">
              Select the city first, then choose the branch to see the official Veeraops Bank IFSC code.
            </p>
          </div>
          <div className="mode-switch">
            <a className="secondary-button portal-link" href="/">
              All Portals
            </a>
            <a className="secondary-button portal-link" href="/customer">
              Customer Portal
            </a>
          </div>
        </div>
      </section>

      <section className="login-card ifsc-finder-card">
        <div className="panel-head">
          <div>
            <h2>Find Branch IFSC</h2>
            <p className="helper">
              Step 1: choose city. Step 2: choose branch. Step 3: view IFSC.
            </p>
          </div>
        </div>

        <div className="form-grid">
          <select
            value={selectedCity}
            onChange={(event) => {
              setSelectedCity(event.target.value);
              setSelectedBranch("");
            }}
          >
            <option value="">Select City</option>
            {cities.map((city) => (
              <option key={city} value={city}>
                {city}
              </option>
            ))}
          </select>

          <select
            value={selectedBranch}
            onChange={(event) => setSelectedBranch(event.target.value)}
            disabled={!selectedCity}
          >
            <option value="">Select Branch</option>
            {cityBranches.map((branch) => (
              <option key={branch.ifsc_code} value={branch.branch_name}>
                {branch.branch_name}
              </option>
            ))}
          </select>
        </div>

        {!branches.length ? (
          <div className="empty-state" style={{ marginTop: "18px" }}>
            Loading branch data. If it still does not appear, refresh the page once.
          </div>
        ) : selectedBranchDetails ? (
          <div className="status-card" style={{ marginTop: "18px" }}>
            <div className="status-badge status-approved">IFSC READY</div>
            <h3>{selectedBranchDetails.branch_name}</h3>
            <div className="helper">
              {selectedBranchDetails.city}, {selectedBranchDetails.state_name}
            </div>
            <div className="metric-value">{selectedBranchDetails.ifsc_code}</div>
          </div>
        ) : (
          <div className="empty-state" style={{ marginTop: "18px" }}>
            Choose city and branch to view IFSC code.
          </div>
        )}
      </section>
    </div>
  );
}

function AdminDashboard({
  dashboard,
  onApproveCustomer,
  onRejectCustomer,
  onApproveCard,
  onRejectCard,
  onApproveLoan,
  onRejectLoan,
  onSendLoanReminder,
  onAdminAdjustBalance,
  onAdminSetAccountStatus,
  onAdminResetPassword,
  onAdminUpdateCustomerProfile,
  onAdminSetCardStatus,
  onAdminUpdateChequeStatus,
  onLogout,
  notice,
  error
}) {
  const [adminSection, setAdminSection] = useState("requests");
  const [adminBalanceForm, setAdminBalanceForm] = useState({
    direction: "credit",
    amount: "",
    reason: ""
  });
  const [adminPasswordForm, setAdminPasswordForm] = useState({
    newPassword: ""
  });
  const [adminStatusReason, setAdminStatusReason] = useState("");
  const [adminProfileForm, setAdminProfileForm] = useState({
    fullName: "",
    email: "",
    phone: "",
    city: "",
    requestedBranch: ""
  });
  const accountCustomers = (dashboard.customers || []).filter((customer) => customer.account_number);
  const [selectedAccountId, setSelectedAccountId] = useState(accountCustomers[0]?.id || null);
  const selectedAccount =
    accountCustomers.find((customer) => customer.id === selectedAccountId) || accountCustomers[0] || null;
  const selectedAccountTransactions = (dashboard.allTransactions || []).filter(
    (transaction) => transaction.account_number === selectedAccount?.account_number
  );
  const selectedAccountLoans = (dashboard.allLoans || []).filter(
    (loan) => loan.customer_id === selectedAccount?.id
  );
  const selectedAccountCards = (dashboard.allCards || []).filter(
    (card) => card.customer_id === selectedAccount?.id
  );

  useEffect(() => {
    if (!selectedAccount) {
      return;
    }

    setAdminProfileForm({
      fullName: selectedAccount.full_name || "",
      email: selectedAccount.email || "",
      phone: selectedAccount.phone || "",
      city: selectedAccount.city || "",
      requestedBranch: selectedAccount.requested_branch || ""
    });
  }, [selectedAccount?.id]);

  return (
    <div className="app-shell admin-shell">
      <section className="hero admin-hero">
        <div className="topbar">
          <div>
            <div className="small">Admin Portal</div>
            <h1>{dashboard.employee.full_name}</h1>
            <p className="subtext">
              {dashboard.employee.role} at {dashboard.employee.branch}
            </p>
          </div>
          <div className="mode-switch">
            <a className="secondary-button portal-link" href="/">
              All Portals
            </a>
            <button className="secondary-button" onClick={onLogout}>
              Logout
            </button>
          </div>
        </div>
      </section>

      <div className="metric-grid admin-metric-grid">
        <MetricCard label="Customers" value={dashboard.summary.totalCustomers} />
        <MetricCard label="Pending Approvals" value={dashboard.summary.pendingApprovals} />
        <MetricCard label="Accounts" value={dashboard.summary.totalAccounts} />
        <MetricCard label="Cards" value={dashboard.summary.totalCards} />
        <MetricCard label="Loans" value={dashboard.summary.totalLoans} />
        <MetricCard
          label="Deposits Under Management"
          value={formatCurrency(dashboard.summary.depositsUnderManagement)}
        />
      </div>

      {error ? <div className="notice notice-error">{error}</div> : null}
      {notice ? <div className="notice">{notice}</div> : null}

      <div className="admin-section-switch admin-tabs">
        <button
          className={adminSection === "requests" ? "active" : ""}
          onClick={() => setAdminSection("requests")}
        >
          Requests Block
        </button>
        <button
          className={adminSection === "accounts" ? "active" : ""}
          onClick={() => setAdminSection("accounts")}
        >
          Accounts Block
        </button>
        <button
          className={adminSection === "operations" ? "active" : ""}
          onClick={() => setAdminSection("operations")}
        >
          Operations Block
        </button>
      </div>

      {adminSection === "requests" ? (
        <div className="grid main admin-workspace">
          <section className="panel admin-panel">
            <div className="panel-head">
              <h2>Pending Account Requests</h2>
              <div className="small">{dashboard.pendingApplications.length} waiting</div>
            </div>
            <div className="customer-list">
              {dashboard.pendingApplications.length ? (
                dashboard.pendingApplications.map((customer) => (
                  <div className="list-card admin-request-card" key={customer.id}>
                    <h3>{customer.full_name}</h3>
                    <div className="helper">{customer.customer_number}</div>
                    <div className="helper">{customer.phone}</div>
                    <div className="helper">{customer.email || "No email provided"}</div>
                    <div className="helper">{customer.city || "City not provided"}</div>
                    <div className="helper">
                      Requested {customer.requested_account_type} | {customer.requested_branch}
                    </div>
                    <div className="action-row">
                      <button
                        className="primary-button inline-button"
                        onClick={() => onApproveCustomer(customer.id)}
                      >
                        Approve
                      </button>
                      <button
                        className="secondary-button inline-button danger-button"
                        onClick={() => onRejectCustomer(customer.id)}
                      >
                        Reject
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="empty-state">No pending applications right now.</div>
              )}
            </div>
          </section>

          <section className="panel admin-panel">
            <div className="panel-head">
              <h2>Recent Transactions</h2>
            </div>
            <div className="tx-list">
              {dashboard.recentTransactions.map((tx) => (
                <div className={`tx-card ${tx.direction}`} key={tx.id}>
                  <div className="tx-row">
                    <strong>{tx.customer_name}</strong>
                    <span className={`amount ${tx.direction}`}>{formatCurrency(tx.amount)}</span>
                  </div>
                  <div className="tx-meta">{tx.transaction_type}</div>
                  <div className="tx-meta">
                    {tx.account_number} | {tx.channel}
                  </div>
                  <div className="tx-meta">{tx.description}</div>
                </div>
              ))}
            </div>
            <div className="panel-head" style={{ marginTop: "20px" }}>
              <h2>Pending Debit Card Requests</h2>
              <div className="small">{dashboard.pendingCardRequests?.length || 0} waiting</div>
            </div>
            <div className="customer-list">
              {dashboard.pendingCardRequests?.length ? (
                dashboard.pendingCardRequests.map((card) => (
                  <div className="list-card admin-request-card" key={card.id}>
                    <h3>{card.full_name}</h3>
                    <div className="helper">{card.account_number}</div>
                    <div className="helper">{card.phone}</div>
                    <div className="helper">{card.email || "No email provided"}</div>
                    <div className="helper">
                      Debit Card | {card.provider} | {card.branch}
                    </div>
                    <div className="action-row">
                      <button
                        className="primary-button inline-button"
                        onClick={() => onApproveCard(card.id)}
                      >
                        Approve Card
                      </button>
                      <button
                        className="secondary-button inline-button danger-button"
                        onClick={() => onRejectCard(card.id)}
                      >
                        Reject Card
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="empty-state">No pending debit card requests right now.</div>
              )}
            </div>
            <div className="panel-head" style={{ marginTop: "20px" }}>
              <h2>Pending Loan Requests</h2>
              <div className="small">{dashboard.pendingLoanRequests?.length || 0} waiting</div>
            </div>
            <div className="customer-list">
              {dashboard.pendingLoanRequests?.length ? (
                dashboard.pendingLoanRequests.map((loan) => (
                  <div className="list-card admin-request-card" key={loan.id}>
                    <h3>{loan.full_name}</h3>
                    <div className="helper">{loan.loan_type_label} Loan</div>
                    <div className="helper">{formatCurrency(loan.principal_amount)} requested</div>
                    <div className="helper">
                      {loan.tenure_months} months | {formatPercent(loan.annual_interest_rate)}
                    </div>
                    <div className="helper">{loan.purpose}</div>
                    <div className="action-row">
                      <button
                        className="primary-button inline-button"
                        onClick={() => onApproveLoan(loan.id)}
                      >
                        Approve Loan
                      </button>
                      <button
                        className="secondary-button inline-button danger-button"
                        onClick={() => onRejectLoan(loan.id)}
                      >
                        Reject Loan
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="empty-state">No pending loan requests right now.</div>
              )}
            </div>
          </section>
        </div>
      ) : adminSection === "operations" ? (
        <div className="grid main admin-workspace">
          <section className="panel admin-panel">
            <div className="panel-head">
              <h2>Cheque Book Operations</h2>
              <div className="small">{dashboard.chequeBookRequests?.length || 0} requests</div>
            </div>
            <div className="customer-list">
              {dashboard.chequeBookRequests?.length ? (
                dashboard.chequeBookRequests.map((request) => (
                  <div className="list-card admin-request-card" key={request.id}>
                    <div className="admin-account-row">
                      <div>
                        <h3>{request.customer_name}</h3>
                        <div className="helper">{request.request_number}</div>
                        <div className="helper">{request.account_number}</div>
                      </div>
                      <span className={`status-badge status-${request.status}`}>
                        {request.status.toUpperCase()}
                      </span>
                    </div>
                    <div className="helper">{request.leaf_count} leaves</div>
                    <div className="helper">{request.delivery_address}</div>
                    <div className="action-row">
                      <button
                        className="primary-button inline-button"
                        disabled={request.status === "approved"}
                        onClick={() => onAdminUpdateChequeStatus(request.id, "approved")}
                      >
                        Approve
                      </button>
                      <button
                        className="secondary-button inline-button"
                        disabled={request.status === "dispatched"}
                        onClick={() => onAdminUpdateChequeStatus(request.id, "dispatched")}
                      >
                        Dispatch
                      </button>
                      <button
                        className="primary-button inline-button"
                        disabled={request.status === "delivered"}
                        onClick={() => onAdminUpdateChequeStatus(request.id, "delivered")}
                      >
                        Delivered
                      </button>
                      <button
                        className="secondary-button inline-button danger-button"
                        disabled={request.status === "rejected"}
                        onClick={() => onAdminUpdateChequeStatus(request.id, "rejected")}
                      >
                        Reject
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <div className="empty-state">No cheque book requests yet.</div>
              )}
            </div>
          </section>

          <section className="panel admin-panel">
            <div className="panel-head">
              <h2>Payments And Deposits</h2>
              <div className="small">Operational view</div>
            </div>
            <div className="panel-head" style={{ marginTop: "4px" }}>
              <h2>Recent Bill Payments</h2>
              <div className="small">{dashboard.billPayments?.length || 0} records</div>
            </div>
            <div className="tx-list">
              {dashboard.billPayments?.length ? (
                dashboard.billPayments.map((payment) => (
                  <div className="tx-card debit" key={payment.id}>
                    <div className="tx-row">
                      <strong>{payment.customer_name}</strong>
                      <span className="amount debit">{formatCurrency(payment.amount)}</span>
                    </div>
                    <div className="tx-meta">{payment.bill_category} | {payment.biller_name}</div>
                    <div className="tx-meta">{payment.consumer_number}</div>
                    <div className="tx-meta">{payment.reference_code} | {payment.status}</div>
                  </div>
                ))
              ) : (
                <div className="empty-state">No bill payments yet.</div>
              )}
            </div>

            <div className="panel-head" style={{ marginTop: "20px" }}>
              <h2>Fixed Deposits</h2>
              <div className="small">{dashboard.fixedDeposits?.length || 0} records</div>
            </div>
            <div className="customer-list">
              {dashboard.fixedDeposits?.length ? (
                dashboard.fixedDeposits.map((deposit) => (
                  <div className="list-card admin-request-card" key={deposit.id}>
                    <h3>{deposit.customer_name}</h3>
                    <div className="helper">{deposit.deposit_number}</div>
                    <div className="helper">Principal {formatCurrency(deposit.principal_amount)}</div>
                    <div className="helper">
                      Maturity {formatCurrency(deposit.maturity_amount)} on{" "}
                      {formatDate(deposit.maturity_date)}
                    </div>
                    <div className="helper">
                      {deposit.tenure_months} months | {formatPercent(deposit.annual_interest_rate)} |{" "}
                      {deposit.status}
                    </div>
                  </div>
                ))
              ) : (
                <div className="empty-state">No fixed deposits yet.</div>
              )}
            </div>
          </section>
        </div>
      ) : (
        <div className="grid main admin-workspace admin-accounts-workspace">
          <section className="panel admin-panel admin-account-list-panel">
            <div className="panel-head">
              <h2>Accounts</h2>
              <div className="small">{accountCustomers.length} approved</div>
            </div>
            <div className="customer-list">
              {accountCustomers.length ? (
                accountCustomers.map((customer) => (
                  <button
                    className={`list-card admin-account-button ${
                      selectedAccount?.id === customer.id ? "selected" : ""
                    }`}
                    key={customer.id}
                    onClick={() => setSelectedAccountId(customer.id)}
                    type="button"
                  >
                    <div className="admin-account-row">
                      <div>
                        <h3>{customer.full_name}</h3>
                        <div className="helper">{customer.account_number}</div>
                        <div className="helper">{customer.phone}</div>
                      </div>
                      <span className={`status-badge status-${customer.account_status || "approved"}`}>
                        {(customer.account_status || "active").toUpperCase()}
                      </span>
                    </div>
                    <div className="admin-account-meta">
                      <span>{customer.account_type}</span>
                      <strong>{formatCurrency(customer.balance)}</strong>
                    </div>
                    <div className="helper">
                      {customer.requested_branch} | IFSC: {customer.ifsc_code || "-"}
                    </div>
                  </button>
                ))
              ) : (
                <div className="empty-state">No approved accounts available yet.</div>
              )}
            </div>
          </section>

          <section className="panel admin-panel admin-detail-panel">
            <div className="panel-head">
              <h2>Account Rights And Details</h2>
            </div>
            {selectedAccount ? (
              <>
                <div className="status-card admin-customer-summary">
                  <div className="admin-summary-top">
                    <div>
                      <span className={`status-badge status-${selectedAccount.account_status || "approved"}`}>
                        {(selectedAccount.account_status || "active").toUpperCase()}
                      </span>
                      <h3>{selectedAccount.full_name}</h3>
                    </div>
                    <strong>{formatCurrency(selectedAccount.balance)}</strong>
                  </div>
                  <div className="admin-detail-grid">
                    <div>
                      <span>Account</span>
                      <strong>{selectedAccount.account_number}</strong>
                    </div>
                    <div>
                      <span>Mobile</span>
                      <strong>{selectedAccount.phone}</strong>
                    </div>
                    <div>
                      <span>Email</span>
                      <strong>{selectedAccount.email || "No email provided"}</strong>
                    </div>
                    <div>
                      <span>Type</span>
                      <strong>{selectedAccount.account_type}</strong>
                    </div>
                    <div>
                      <span>Branch</span>
                      <strong>{selectedAccount.requested_branch}</strong>
                    </div>
                    <div>
                      <span>IFSC</span>
                      <strong>{selectedAccount.ifsc_code || "-"}</strong>
                    </div>
                  </div>
                  <div className="notice admin-note">
                    Admin rights available in this UI: review details, monitor debit and credit history,
                    hold accounts, close accounts, approve requests, reject requests, and inspect customer
                    account activity.
                  </div>
                </div>

                <TransactionHistory
                  transactions={selectedAccountTransactions}
                  title={`Customer Transactions For ${selectedAccount.account_number}`}
                />

                <section className="panel admin-power-panel" style={{ marginTop: "18px" }}>
                  <div className="panel-head">
                    <div>
                      <h2>Admin Power Actions</h2>
                      <p className="helper">Perform controlled account operations for this customer.</p>
                    </div>
                  </div>
                  <div className="card-grid">
                    <article className="account-card admin-action-card">
                      <h3>Adjust Balance</h3>
                      <div className="form-grid">
                        <select
                          value={adminBalanceForm.direction}
                          onChange={(event) =>
                            setAdminBalanceForm({
                              ...adminBalanceForm,
                              direction: event.target.value
                            })
                          }
                        >
                          <option value="credit">Credit Account</option>
                          <option value="debit">Debit Account</option>
                        </select>
                        <input
                          placeholder="Amount"
                          type="number"
                          value={adminBalanceForm.amount}
                          onChange={(event) =>
                            setAdminBalanceForm({
                              ...adminBalanceForm,
                              amount: event.target.value
                            })
                          }
                        />
                        <input
                          placeholder="Reason"
                          value={adminBalanceForm.reason}
                          onChange={(event) =>
                            setAdminBalanceForm({
                              ...adminBalanceForm,
                              reason: event.target.value
                            })
                          }
                        />
                      </div>
                      <button
                        className="primary-button inline-button"
                        disabled={!adminBalanceForm.amount}
                        onClick={() =>
                          onAdminAdjustBalance(selectedAccount.account_id, adminBalanceForm).then(() =>
                            setAdminBalanceForm({ direction: "credit", amount: "", reason: "" })
                          )
                        }
                      >
                        Apply Adjustment
                      </button>
                    </article>

                    <article className="account-card admin-action-card">
                      <h3>Hold / Activate / Close</h3>
                      <div className="form-grid">
                        <input
                          placeholder="Reason"
                          value={adminStatusReason}
                          onChange={(event) => setAdminStatusReason(event.target.value)}
                        />
                      </div>
                      <div className="action-row">
                        <button
                          className="secondary-button inline-button danger-button"
                          onClick={() =>
                            onAdminSetAccountStatus(selectedAccount.account_id, "hold", adminStatusReason)
                          }
                          disabled={selectedAccount.account_status === "hold"}
                        >
                          Hold
                        </button>
                        <button
                          className="primary-button inline-button"
                          onClick={() =>
                            onAdminSetAccountStatus(selectedAccount.account_id, "active", adminStatusReason)
                          }
                          disabled={selectedAccount.account_status === "active"}
                        >
                          Activate
                        </button>
                        <button
                          className="secondary-button inline-button danger-button"
                          onClick={() =>
                            onAdminSetAccountStatus(selectedAccount.account_id, "closed", adminStatusReason)
                          }
                          disabled={selectedAccount.account_status === "closed"}
                        >
                          Close
                        </button>
                      </div>
                    </article>

                    <article className="account-card admin-action-card">
                      <h3>Reset Customer Password</h3>
                      <div className="form-grid">
                        <input
                          placeholder="New strong password"
                          type="password"
                          value={adminPasswordForm.newPassword}
                          onChange={(event) =>
                            setAdminPasswordForm({ newPassword: event.target.value })
                          }
                        />
                      </div>
                      <button
                        className="primary-button inline-button"
                        disabled={!adminPasswordForm.newPassword}
                        onClick={() =>
                          onAdminResetPassword(selectedAccount.id, adminPasswordForm.newPassword).then(() =>
                            setAdminPasswordForm({ newPassword: "" })
                          )
                        }
                      >
                        Reset Password
                      </button>
                    </article>

                    <article className="account-card admin-action-card">
                      <h3>Edit Customer Profile</h3>
                      <div className="form-grid">
                        <input
                          placeholder="Full name"
                          value={adminProfileForm.fullName}
                          onChange={(event) =>
                            setAdminProfileForm({ ...adminProfileForm, fullName: event.target.value })
                          }
                        />
                        <input
                          placeholder="Email"
                          type="email"
                          value={adminProfileForm.email}
                          onChange={(event) =>
                            setAdminProfileForm({ ...adminProfileForm, email: event.target.value })
                          }
                        />
                        <input
                          placeholder="Phone"
                          value={adminProfileForm.phone}
                          onChange={(event) =>
                            setAdminProfileForm({ ...adminProfileForm, phone: event.target.value })
                          }
                        />
                        <input
                          placeholder="City"
                          value={adminProfileForm.city}
                          onChange={(event) =>
                            setAdminProfileForm({ ...adminProfileForm, city: event.target.value })
                          }
                        />
                        <input
                          placeholder="Branch"
                          value={adminProfileForm.requestedBranch}
                          onChange={(event) =>
                            setAdminProfileForm({
                              ...adminProfileForm,
                              requestedBranch: event.target.value
                            })
                          }
                        />
                      </div>
                      <button
                        className="primary-button inline-button"
                        onClick={() => onAdminUpdateCustomerProfile(selectedAccount.id, adminProfileForm)}
                      >
                        Save Profile
                      </button>
                    </article>
                  </div>
                </section>

                <section className="panel admin-power-panel" style={{ marginTop: "18px" }}>
                  <div className="panel-head">
                    <h2>Cards For {selectedAccount.full_name}</h2>
                    <div className="small">{selectedAccountCards.length} cards</div>
                  </div>
                  <div className="card-grid">
                    {selectedAccountCards.length ? (
                      selectedAccountCards.map((card) => (
                        <article className="account-card admin-action-card" key={card.id}>
                          <div className="admin-account-row">
                            <div>
                              <h3>{card.card_type} card</h3>
                              <div className="helper">
                                {card.provider} | {maskCard(card.card_number)}
                              </div>
                              <div className="helper">Approval {card.approval_status}</div>
                            </div>
                            <span className={`status-badge status-${card.status}`}>
                              {card.status.toUpperCase()}
                            </span>
                          </div>
                          <div className="action-row">
                            <button
                              className="primary-button inline-button"
                              disabled={card.status === "active"}
                              onClick={() => onAdminSetCardStatus(card.id, "active")}
                            >
                              Activate
                            </button>
                            <button
                              className="secondary-button inline-button danger-button"
                              disabled={card.status === "blocked"}
                              onClick={() => onAdminSetCardStatus(card.id, "blocked")}
                            >
                              Block
                            </button>
                          </div>
                        </article>
                      ))
                    ) : (
                      <div className="empty-state">No cards linked to this customer.</div>
                    )}
                  </div>
                </section>
                <section className="panel" style={{ marginTop: "18px" }}>
                  <div className="panel-head">
                    <h2>Loans For {selectedAccount.full_name}</h2>
                  </div>
                  <div className="card-grid">
                    {selectedAccountLoans.length ? (
                      selectedAccountLoans.map((loan) => (
                        <article className="loan-card" key={loan.id}>
                          <div
                            className={`status-badge status-${
                              loan.approval_status === "approved"
                                ? "approved"
                                : loan.approval_status === "pending"
                                  ? "pending"
                                  : "rejected"
                            }`}
                          >
                            {loan.approval_status.toUpperCase()}
                          </div>
                          <h3>{loan.loan_type_label} Loan</h3>
                          <div className="helper">Principal {formatCurrency(loan.principal_amount)}</div>
                          <div className="helper">Outstanding {formatCurrency(loan.outstanding_amount)}</div>
                          <div className="helper">EMI {formatCurrency(loan.emi_amount)}</div>
                          <div className="helper">{loan.due_label}</div>
                          <div className="action-row">
                            <button
                              className="secondary-button inline-button"
                              onClick={() => onSendLoanReminder(loan.id)}
                              disabled={loan.approval_status !== "approved" || loan.status !== "active"}
                            >
                              Send Reminder
                            </button>
                          </div>
                        </article>
                      ))
                    ) : (
                      <div className="empty-state">No loans linked to this customer yet.</div>
                    )}
                  </div>
                </section>
              </>
            ) : (
              <div className="empty-state">Choose an account to view customer details and transactions.</div>
            )}
          </section>
        </div>
      )}
    </div>
  );
}

function CustomerDashboard({
  dashboard,
  activeService,
  setActiveService,
  cashForm,
  setCashForm,
  loanForm,
  setLoanForm,
  loanPaymentForm,
  setLoanPaymentForm,
  transferForm,
  setTransferForm,
  cardPinForm,
  setCardPinForm,
  cardSpendForm,
  setCardSpendForm,
  billPaymentForm,
  setBillPaymentForm,
  fixedDepositForm,
  setFixedDepositForm,
  chequeBookForm,
  setChequeBookForm,
  onCashAction,
  onTransfer,
  onPayBill,
  onCreateFixedDeposit,
  onRequestChequeBook,
  onRequestLoan,
  onPayLoan,
  onRequestDebitCard,
  onSetCardPin,
  onCardSpend,
  onRefresh,
  onLogout,
  notice,
  error
}) {
  const primaryAccount = dashboard.accounts[0];
  const approvedDebitCards = dashboard.cards.filter(
    (card) => card.card_type === "debit" && card.approval_status === "approved"
  );
  const pendingDebitCard = dashboard.cards.find(
    (card) => card.card_type === "debit" && card.approval_status === "pending"
  );
  const loanPreview = calculateLoanPreview(
    loanForm.principalAmount,
    loanForm.annualInterestRate,
    loanForm.tenureMonths
  );
  const serviceItems = [
    {
      id: "accounts",
      label: "Accounts",
      detail: `${dashboard.accounts.length} account${dashboard.accounts.length === 1 ? "" : "s"}`
    },
    {
      id: "transfer",
      label: "Transfer",
      detail: "Send money safely"
    },
    {
      id: "credit",
      label: "Credit Amount",
      detail: "Add funds to your account"
    },
    {
      id: "cards",
      label: "Cards",
      detail: `${dashboard.cards.length} card${dashboard.cards.length === 1 ? "" : "s"}`
    },
    {
      id: "pin",
      label: "Set Card PIN",
      detail: approvedDebitCards.length ? "Secure your debit card" : "Available after approval"
    },
    {
      id: "payments",
      label: "Card Payment",
      detail: "Use approved debit card"
    },
    {
      id: "bills",
      label: "Bills & Recharge",
      detail: "Pay utilities and recharges"
    },
    {
      id: "fixedDeposit",
      label: "Fixed Deposit",
      detail: "Create FD from account balance"
    },
    {
      id: "chequeBook",
      label: "Cheque Book",
      detail: "Request cheque leaves"
    },
    {
      id: "loans",
      label: "Loans",
      detail: `${dashboard.loans.length} active view${dashboard.loans.length === 1 ? "" : "s"}`
    },
    {
      id: "history",
      label: "History",
      detail: "See debit and credit activity"
    }
  ];

  function renderActiveService() {
    switch (activeService) {
      case "credit":
        return (
          <section className="panel">
            <div className="panel-head">
              <h2>Credit Amount</h2>
            </div>
            <div className="form-grid">
              <input
                placeholder="Amount"
                type="number"
                value={cashForm.amount}
                onChange={(event) => setCashForm({ ...cashForm, amount: event.target.value })}
              />
              <input
                placeholder="Description"
                value={cashForm.description}
                onChange={(event) =>
                  setCashForm({ ...cashForm, description: event.target.value })
                }
              />
              <select
                value={cashForm.channel}
                onChange={(event) => setCashForm({ ...cashForm, channel: event.target.value })}
              >
                <option value="online">Online</option>
                <option value="cash">Cash</option>
                <option value="upi">UPI</option>
                <option value="atm">ATM</option>
              </select>
            </div>
            <div className="quick-actions">
              <button
                className="action-button"
                disabled={!primaryAccount || !cashForm.amount}
                onClick={() => onCashAction("credit")}
              >
                Credit Account
              </button>
            </div>
            {error ? <div className="notice notice-error">{error}</div> : null}
            {notice ? <div className="notice">{notice}</div> : null}
          </section>
        );
      case "transfer":
        return (
          <section className="panel">
            <div className="panel-head">
              <h2>Transfer Money</h2>
            </div>
            <div className="form-grid">
              <select
                value={transferForm.transferMode}
                onChange={(event) =>
                  setTransferForm({ ...transferForm, transferMode: event.target.value })
                }
              >
                <option value="same-bank">Same Bank Transfer</option>
                <option value="different-bank">Different Bank Transfer</option>
              </select>
              <input
                placeholder="Beneficiary Name"
                value={transferForm.beneficiaryName}
                onChange={(event) =>
                  setTransferForm({ ...transferForm, beneficiaryName: event.target.value })
                }
              />
              <input
                placeholder="Recipient Account Number"
                value={transferForm.recipientAccountNumber}
                onChange={(event) =>
                  setTransferForm({
                    ...transferForm,
                    recipientAccountNumber: event.target.value
                  })
                }
              />
              {transferForm.transferMode === "different-bank" ? (
                <>
                  <input
                    placeholder="Recipient Bank Name"
                    value={transferForm.recipientBankName}
                    onChange={(event) =>
                      setTransferForm({ ...transferForm, recipientBankName: event.target.value })
                    }
                  />
                  <input
                    placeholder="Recipient IFSC"
                    value={transferForm.recipientIfsc}
                    onChange={(event) =>
                      setTransferForm({ ...transferForm, recipientIfsc: event.target.value })
                    }
                  />
                </>
              ) : null}
              <input
                placeholder="Amount"
                type="number"
                value={transferForm.amount}
                onChange={(event) =>
                  setTransferForm({ ...transferForm, amount: event.target.value })
                }
              />
              <input
                placeholder="Description"
                value={transferForm.description}
                onChange={(event) =>
                  setTransferForm({ ...transferForm, description: event.target.value })
                }
              />
            </div>
            <button className="primary-button inline-button" onClick={onTransfer}>
              Transfer Money
            </button>
            {error ? <div className="notice notice-error">{error}</div> : null}
            {notice ? <div className="notice">{notice}</div> : null}
          </section>
        );
      case "cards":
        return (
          <section className="panel">
            <div className="panel-head">
              <h2>Cards</h2>
            </div>
            <div className="form-grid">
              <button
                className="primary-button"
                disabled={!primaryAccount || Boolean(approvedDebitCards.length || pendingDebitCard)}
                onClick={() => onRequestDebitCard(primaryAccount?.id)}
              >
                {pendingDebitCard ? "Debit Card Request Pending" : "Apply Debit Card"}
              </button>
            </div>
            <div className="card-grid">
              {dashboard.cards.map((card) => (
                <article className="credit-card" key={card.id}>
                  <div className="small">
                    {card.card_type.toUpperCase()} | {card.provider}
                  </div>
                  <h3>{maskCard(card.card_number)}</h3>
                  <div className="helper">Expiry {card.expiry_label}</div>
                  <div className="helper">Status {card.status}</div>
                  <div className="helper">Approval {card.approval_status}</div>
                  {card.card_type === "debit" ? (
                    <div className="helper">
                      PIN {card.pin_set_at ? "set and ready for transactions" : "not set"}
                    </div>
                  ) : null}
                  {card.card_type === "credit" ? (
                    <div className="helper">
                      Available limit {formatCurrency(card.available_limit)} of{" "}
                      {formatCurrency(card.credit_limit)}
                    </div>
                  ) : (
                    <div className="helper">Linked to primary account balance</div>
                  )}
                </article>
              ))}
            </div>
            {error ? <div className="notice notice-error">{error}</div> : null}
            {notice ? <div className="notice">{notice}</div> : null}
          </section>
        );
      case "pin":
        return (
          <section className="panel">
            <div className="panel-head">
              <h2>Set Debit Card PIN</h2>
            </div>
            <div className="form-grid">
              <select
                value={cardPinForm.cardId}
                onChange={(event) =>
                  setCardPinForm({ ...cardPinForm, cardId: event.target.value })
                }
                disabled={!approvedDebitCards.length}
              >
                <option value="">
                  {approvedDebitCards.length ? "Select Debit Card" : "No Approved Debit Card"}
                </option>
                {approvedDebitCards.map((card) => (
                  <option key={card.id} value={card.id}>
                    {maskCard(card.card_number)} | {card.pin_set_at ? "Update PIN" : "Set PIN"}
                  </option>
                ))}
              </select>
              <input
                placeholder="4-Digit PIN"
                type="password"
                inputMode="numeric"
                maxLength={4}
                value={cardPinForm.pin}
                onChange={(event) =>
                  setCardPinForm({
                    ...cardPinForm,
                    pin: event.target.value.replace(/\D/g, "").slice(0, 4)
                  })
                }
              />
              <input
                placeholder="Confirm 4-Digit PIN"
                type="password"
                inputMode="numeric"
                maxLength={4}
                value={cardPinForm.confirmPin}
                onChange={(event) =>
                  setCardPinForm({
                    ...cardPinForm,
                    confirmPin: event.target.value.replace(/\D/g, "").slice(0, 4)
                  })
                }
              />
            </div>
            <button
              className="primary-button inline-button"
              disabled={
                !cardPinForm.cardId ||
                cardPinForm.pin.length !== 4 ||
                cardPinForm.confirmPin.length !== 4
              }
              onClick={onSetCardPin}
            >
              Save Debit Card PIN
            </button>
            {error ? <div className="notice notice-error">{error}</div> : null}
            {notice ? <div className="notice">{notice}</div> : null}
          </section>
        );
      case "payments":
        return (
          <section className="panel">
            <div className="panel-head">
              <h2>Use Debit Card</h2>
            </div>
            <div className="form-grid">
              <select
                value={cardSpendForm.cardId}
                onChange={(event) =>
                  setCardSpendForm({ ...cardSpendForm, cardId: event.target.value })
                }
                disabled={!approvedDebitCards.length}
              >
                <option value="">
                  {approvedDebitCards.length ? "Select Debit Card" : "No Approved Debit Card"}
                </option>
                {approvedDebitCards.map((card) => (
                  <option key={card.id} value={card.id}>
                    {maskCard(card.card_number)} | {card.provider}
                  </option>
                ))}
              </select>
              <input
                placeholder="Purchase Amount"
                type="number"
                value={cardSpendForm.amount}
                onChange={(event) =>
                  setCardSpendForm({ ...cardSpendForm, amount: event.target.value })
                }
              />
              <input
                placeholder="4-Digit PIN"
                type="password"
                inputMode="numeric"
                maxLength={4}
                value={cardSpendForm.pin}
                onChange={(event) =>
                  setCardSpendForm({
                    ...cardSpendForm,
                    pin: event.target.value.replace(/\D/g, "").slice(0, 4)
                  })
                }
              />
              <input
                placeholder="Purchase Description"
                value={cardSpendForm.description}
                onChange={(event) =>
                  setCardSpendForm({ ...cardSpendForm, description: event.target.value })
                }
              />
            </div>
            <button
              className="primary-button inline-button"
              disabled={
                !cardSpendForm.cardId ||
                !cardSpendForm.amount ||
                cardSpendForm.pin.length !== 4
              }
              onClick={onCardSpend}
            >
              Pay With Debit Card
            </button>
            {error ? <div className="notice notice-error">{error}</div> : null}
            {notice ? <div className="notice">{notice}</div> : null}
          </section>
        );
      case "bills":
        return (
          <section className="panel">
            <div className="panel-head">
              <div>
                <h2>Bills & Recharge</h2>
                <p className="helper">Pay real bill-style transactions from your active account.</p>
              </div>
            </div>
            <div className="form-grid">
              <select
                value={billPaymentForm.billCategory}
                onChange={(event) =>
                  setBillPaymentForm({ ...billPaymentForm, billCategory: event.target.value })
                }
              >
                <option value="Electricity">Electricity</option>
                <option value="Mobile Recharge">Mobile Recharge</option>
                <option value="DTH Recharge">DTH Recharge</option>
                <option value="Broadband">Broadband</option>
                <option value="Gas">Gas</option>
                <option value="Water">Water</option>
                <option value="Insurance Premium">Insurance Premium</option>
                <option value="Education Fee">Education Fee</option>
                <option value="FASTag">FASTag</option>
              </select>
              <input
                placeholder="Biller Name"
                value={billPaymentForm.billerName}
                onChange={(event) =>
                  setBillPaymentForm({ ...billPaymentForm, billerName: event.target.value })
                }
              />
              <input
                placeholder="Consumer / Mobile / Policy Number"
                value={billPaymentForm.consumerNumber}
                onChange={(event) =>
                  setBillPaymentForm({ ...billPaymentForm, consumerNumber: event.target.value })
                }
              />
              <input
                placeholder="Amount"
                type="number"
                value={billPaymentForm.amount}
                onChange={(event) =>
                  setBillPaymentForm({ ...billPaymentForm, amount: event.target.value })
                }
              />
            </div>
            <button
              className="primary-button inline-button"
              disabled={
                !primaryAccount ||
                !billPaymentForm.billerName ||
                !billPaymentForm.consumerNumber ||
                !billPaymentForm.amount
              }
              onClick={onPayBill}
            >
              Pay Bill
            </button>
            {error ? <div className="notice notice-error">{error}</div> : null}
            {notice ? <div className="notice">{notice}</div> : null}
          </section>
        );
      case "fixedDeposit": {
        const fdPrincipal = Number(fixedDepositForm.principalAmount || 0);
        const fdTenure = Number(fixedDepositForm.tenureMonths || 0);
        const fdRate = Number(fixedDepositForm.annualInterestRate || 0);
        const fdMaturity =
          fdPrincipal && fdTenure
            ? fdPrincipal + fdPrincipal * (fdRate / 100) * (fdTenure / 12)
            : 0;

        return (
          <section className="panel">
            <div className="panel-head">
              <div>
                <h2>Fixed Deposit</h2>
                <p className="helper">Move money from your account into a new fixed deposit.</p>
              </div>
            </div>
            <div className="form-grid">
              <input
                placeholder="Deposit Amount"
                type="number"
                value={fixedDepositForm.principalAmount}
                onChange={(event) =>
                  setFixedDepositForm({
                    ...fixedDepositForm,
                    principalAmount: event.target.value
                  })
                }
              />
              <select
                value={fixedDepositForm.tenureMonths}
                onChange={(event) =>
                  setFixedDepositForm({ ...fixedDepositForm, tenureMonths: event.target.value })
                }
              >
                <option value="3">3 Months</option>
                <option value="6">6 Months</option>
                <option value="12">12 Months</option>
                <option value="24">24 Months</option>
                <option value="36">36 Months</option>
                <option value="60">60 Months</option>
              </select>
              <input
                placeholder="Interest Rate"
                type="number"
                value={fixedDepositForm.annualInterestRate}
                onChange={(event) =>
                  setFixedDepositForm({
                    ...fixedDepositForm,
                    annualInterestRate: event.target.value
                  })
                }
              />
            </div>
            <div className="status-card">
              <div className="status-detail-grid">
                <div className="status-detail-item">
                  Estimated Maturity
                  <strong>{formatCurrency(fdMaturity)}</strong>
                </div>
                <div className="status-detail-item">
                  Tenure
                  <strong>{fixedDepositForm.tenureMonths} months</strong>
                </div>
                <div className="status-detail-item">
                  Rate
                  <strong>{formatPercent(fixedDepositForm.annualInterestRate)}</strong>
                </div>
              </div>
            </div>
            <button
              className="primary-button inline-button"
              disabled={!primaryAccount || !fixedDepositForm.principalAmount}
              onClick={onCreateFixedDeposit}
            >
              Create Fixed Deposit
            </button>
            {error ? <div className="notice notice-error">{error}</div> : null}
            {notice ? <div className="notice">{notice}</div> : null}
          </section>
        );
      }
      case "chequeBook":
        return (
          <section className="panel">
            <div className="panel-head">
              <div>
                <h2>Cheque Book Request</h2>
                <p className="helper">Request a cheque book for your active account.</p>
              </div>
            </div>
            <div className="form-grid">
              <select
                value={chequeBookForm.leafCount}
                onChange={(event) =>
                  setChequeBookForm({ ...chequeBookForm, leafCount: event.target.value })
                }
              >
                <option value="25">25 Leaves</option>
                <option value="50">50 Leaves</option>
                <option value="100">100 Leaves</option>
              </select>
              <input
                placeholder="Delivery Address"
                value={chequeBookForm.deliveryAddress}
                onChange={(event) =>
                  setChequeBookForm({ ...chequeBookForm, deliveryAddress: event.target.value })
                }
              />
            </div>
            <button
              className="primary-button inline-button"
              disabled={!primaryAccount || chequeBookForm.deliveryAddress.trim().length < 10}
              onClick={onRequestChequeBook}
            >
              Submit Request
            </button>
            {error ? <div className="notice notice-error">{error}</div> : null}
            {notice ? <div className="notice">{notice}</div> : null}
          </section>
        );
      case "loans":
      case "loans":
        return (
          <section className="panel">
            <div className="panel-head">
              <h2>Loans</h2>
            </div>
            <div className="card-grid" style={{ marginBottom: "18px" }}>
              <article className="account-card">
                <div className="panel-head">
                  <h3>Apply For Loan</h3>
                </div>
                <div className="form-grid">
                  <select
                    value={loanForm.loanType}
                    onChange={(event) =>
                      setLoanForm({
                        ...loanForm,
                        loanType: event.target.value,
                        annualInterestRate: String(
                          {
                            personal: 13.5,
                            home: 8.75,
                            vehicle: 10.25,
                            education: 9.15,
                            business: 14.25,
                            gold: 11.5
                          }[event.target.value] || 12.5
                        )
                      })
                    }
                  >
                    <option value="personal">Personal Loan</option>
                    <option value="home">Home Loan</option>
                    <option value="vehicle">Vehicle Loan</option>
                    <option value="education">Education Loan</option>
                    <option value="business">Business Loan</option>
                    <option value="gold">Gold Loan</option>
                  </select>
                  <input
                    placeholder="Principal Amount"
                    type="number"
                    value={loanForm.principalAmount}
                    onChange={(event) =>
                      setLoanForm({ ...loanForm, principalAmount: event.target.value })
                    }
                  />
                  <input
                    placeholder="Tenure In Months"
                    type="number"
                    value={loanForm.tenureMonths}
                    onChange={(event) =>
                      setLoanForm({ ...loanForm, tenureMonths: event.target.value })
                    }
                  />
                  <input
                    placeholder="Purpose"
                    value={loanForm.purpose}
                    onChange={(event) => setLoanForm({ ...loanForm, purpose: event.target.value })}
                  />
                </div>
                <div className="status-card" style={{ marginTop: "16px" }}>
                  <div className="status-detail-grid">
                    <div className="status-detail-item">
                      Interest Rate
                      <strong>{formatPercent(loanForm.annualInterestRate)}</strong>
                    </div>
                    <div className="status-detail-item">
                      Estimated EMI
                      <strong>{formatCurrency(loanPreview.emiAmount)}</strong>
                    </div>
                    <div className="status-detail-item">
                      Total Payable
                      <strong>{formatCurrency(loanPreview.totalPayableAmount)}</strong>
                    </div>
                  </div>
                </div>
                <button
                  className="primary-button inline-button"
                  style={{ marginTop: "16px" }}
                  disabled={!loanForm.principalAmount || !loanForm.tenureMonths || !loanForm.purpose}
                  onClick={onRequestLoan}
                >
                  Submit Loan Request
                </button>
              </article>
              <article className="account-card">
                <div className="panel-head">
                  <h3>Pay Loan EMI</h3>
                </div>
                <div className="form-grid">
                  <select
                    value={loanPaymentForm.loanId}
                    onChange={(event) =>
                      setLoanPaymentForm({
                        ...loanPaymentForm,
                        loanId: event.target.value,
                        amount:
                          dashboard.loans.find((loan) => String(loan.id) === event.target.value)
                            ?.emi_amount || ""
                      })
                    }
                  >
                    <option value="">Select Active Loan</option>
                    {dashboard.loans
                      .filter((loan) => loan.approval_status === "approved" && loan.status === "active")
                      .map((loan) => (
                        <option key={loan.id} value={loan.id}>
                          {loan.loan_type_label} | EMI {formatCurrency(loan.emi_amount)}
                        </option>
                      ))}
                  </select>
                  <input
                    placeholder="Payment Amount"
                    type="number"
                    value={loanPaymentForm.amount}
                    onChange={(event) =>
                      setLoanPaymentForm({ ...loanPaymentForm, amount: event.target.value })
                    }
                  />
                </div>
                <button
                  className="primary-button inline-button"
                  style={{ marginTop: "16px" }}
                  disabled={!loanPaymentForm.loanId || !loanPaymentForm.amount}
                  onClick={onPayLoan}
                >
                  Pay EMI
                </button>
              </article>
            </div>
            <div className="card-grid">
              {dashboard.loans.map((loan) => (
                <article className="loan-card" key={loan.id}>
                  <div
                    className={`status-badge status-${
                      loan.approval_status === "approved"
                        ? "approved"
                        : loan.approval_status === "pending"
                          ? "pending"
                          : "rejected"
                    }`}
                  >
                    {loan.approval_status.toUpperCase()}
                  </div>
                  <div className="small">{loan.loan_type_label} LOAN</div>
                  <h3>{formatCurrency(loan.outstanding_amount)}</h3>
                  <div className="helper">Principal {formatCurrency(loan.principal_amount)}</div>
                  <div className="helper">
                    Rate {formatPercent(loan.annual_interest_rate)} | Tenure {loan.tenure_months} months
                  </div>
                  <div className="helper">EMI {formatCurrency(loan.emi_amount)}</div>
                  <div className="helper">Total Payable {formatCurrency(loan.total_payable_amount)}</div>
                  <div className="helper">{loan.due_label}</div>
                  <div className="helper">
                    Next Due {loan.next_due_date ? formatDate(loan.next_due_date) : "-"}
                  </div>
                  {loan.rejection_reason ? (
                    <div className="notice notice-error">{loan.rejection_reason}</div>
                  ) : null}
                </article>
              ))}
              {!dashboard.loans.length ? (
                <div className="empty-state">No loan requests yet. Apply for a loan from this section.</div>
              ) : null}
            </div>
            {error ? <div className="notice notice-error">{error}</div> : null}
            {notice ? <div className="notice">{notice}</div> : null}
          </section>
        );
      case "history":
        return (
          <TransactionHistory
            transactions={dashboard.transactions || []}
            title="Your Debit and Credit History"
          />
        );
      case "accounts":
      default:
        return (
          <section className="panel">
            <div className="panel-head">
              <h2>Accounts</h2>
            </div>
            <div className="card-grid">
              {dashboard.accounts.map((account) => (
                <article className="account-card" key={account.id}>
                  <div className="account-card-top">
                    <div>
                      <div className="small">{account.account_type}</div>
                      <h3>{account.account_number}</h3>
                    </div>
                    <div className="small">{account.status}</div>
                  </div>
                  <div className="metric-value">{formatCurrency(account.balance)}</div>
                  <div className="helper">{account.branch}</div>
                  <div className="helper">IFSC: {account.ifsc_code || "-"}</div>
                </article>
              ))}
            </div>
          </section>
        );
    }
  }

  return (
    <div className="app-shell">
      <section className="hero">
        <div className="topbar">
          <div>
            <div className="small">Customer Portal</div>
            <h1>{dashboard.customer.full_name}</h1>
            <p className="subtext">
              {dashboard.customer.customer_number} | {dashboard.customer.phone}
            </p>
          </div>
          <div className="mode-switch">
            <a className="secondary-button portal-link" href="/">
              All Portals
            </a>
            <button className="secondary-button" onClick={onRefresh}>
              Refresh
            </button>
            <button className="secondary-button" onClick={onLogout}>
              Logout
            </button>
          </div>
        </div>
      </section>

      <div className="metric-grid">
        <MetricCard label="Total Balance" value={formatCurrency(dashboard.summary.totalBalance)} />
        <MetricCard label="Active Cards" value={dashboard.summary.activeCards} />
        <MetricCard
          label="Outstanding Loans"
          value={formatCurrency(dashboard.summary.outstandingLoans)}
        />
        <MetricCard label="Primary Account" value={primaryAccount?.account_number || "-"} />
      </div>

      <section className="panel service-launcher">
        <div className="panel-head">
          <h2>Banking Services</h2>
          <div className="small">Select one service to open its workspace</div>
        </div>
        <div className="service-grid">
          {serviceItems.map((service) => (
            <button
              key={service.id}
              className={`service-tile ${activeService === service.id ? "active" : ""}`}
              onClick={() => setActiveService(service.id)}
              type="button"
            >
              <strong>{service.label}</strong>
              <span>{service.detail}</span>
            </button>
          ))}
        </div>
      </section>

      <div className="service-panel-shell">{renderActiveService()}</div>
    </div>
  );
}

function App() {
  const sessionStorageKey = `veeraops:${portalMode}:session`;
  const [authView, setAuthView] = useState("login");
  const [session, setSession] = useState(null);
  const [dashboard, setDashboard] = useState(null);
  const [branches, setBranches] = useState([]);
  const [branchLoading, setBranchLoading] = useState(false);
  const [branchLoadError, setBranchLoadError] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [notice, setNotice] = useState("");
  const [statusResult, setStatusResult] = useState(null);
  const [activeCustomerService, setActiveCustomerService] = useState("accounts");
  const [loanForm, setLoanForm] = useState({
    loanType: "personal",
    principalAmount: "",
    tenureMonths: "12",
    annualInterestRate: "13.5",
    purpose: ""
  });
  const [loanPaymentForm, setLoanPaymentForm] = useState({
    loanId: "",
    amount: ""
  });
  const [cashForm, setCashForm] = useState({
    amount: "",
    description: "",
    channel: "online"
  });
  const [transferForm, setTransferForm] = useState({
    transferMode: "same-bank",
    beneficiaryName: "",
    recipientAccountNumber: "",
    recipientBankName: "",
    recipientIfsc: "",
    amount: "",
    description: ""
  });
  const [cardPinForm, setCardPinForm] = useState({
    cardId: "",
    pin: "",
    confirmPin: ""
  });
  const [cardSpendForm, setCardSpendForm] = useState({
    cardId: "",
    amount: "",
    pin: "",
    description: ""
  });
  const [billPaymentForm, setBillPaymentForm] = useState({
    billCategory: "Electricity",
    billerName: "",
    consumerNumber: "",
    amount: ""
  });
  const [fixedDepositForm, setFixedDepositForm] = useState({
    principalAmount: "",
    tenureMonths: "12",
    annualInterestRate: "7.25"
  });
  const [chequeBookForm, setChequeBookForm] = useState({
    leafCount: "25",
    deliveryAddress: ""
  });

  useEffect(() => {
    if (portalMode === "customer" || portalMode === "ifsc") {
      loadBranches();
    }

  }, []);

  useEffect(() => {
    if (portalMode === "ifsc") {
      return;
    }

    const savedSession = window.sessionStorage.getItem(sessionStorageKey);
    if (!savedSession) {
      return;
    }

    let parsedSession = null;
    try {
      parsedSession = JSON.parse(savedSession);
    } catch (error) {
      window.sessionStorage.removeItem(sessionStorageKey);
      return;
    }

    if (!parsedSession?.user?.id) {
      window.sessionStorage.removeItem(sessionStorageKey);
      return;
    }

    setSession(parsedSession);

    const loadSavedDashboard =
      parsedSession.role === "employee"
        ? loadAdminDashboard(parsedSession.user)
        : loadCustomerDashboard(parsedSession.user);

    loadSavedDashboard.catch((loadError) => {
      window.sessionStorage.removeItem(sessionStorageKey);
      setSession(null);
      setDashboard(null);
      setError(loadError.message || "Your session expired. Please login again.");
    });
  }, []);

  async function loadBranches() {
    setBranchLoading(true);
    setBranchLoadError("");

    try {
      const data = await request("/api/branches");
      setBranches(Array.isArray(data) ? data : []);
    } catch (loadError) {
      setBranches([]);
      setBranchLoadError(
        loadError.message || "Unable to load city and branch list. Please check the backend server."
      );
    } finally {
      setBranchLoading(false);
    }
  }

  async function loadAdminDashboard(user) {
    const data = await request(`/api/admin/dashboard?employeeId=${user.id}`);
    setDashboard(data);
  }

  async function loadCustomerDashboard(user) {
    const data = await request(`/api/customer/dashboard?customerId=${user.id}`);
    setDashboard(data);
  }

  async function handleLogin(form) {
    setLoading(true);
    setError("");
    setNotice("");
    setStatusResult(null);

    try {
      const path = portalMode === "admin" ? "/api/auth/admin-login" : "/api/auth/customer-login";
      const payload =
        portalMode === "admin"
          ? { email: form.email, password: form.password }
          : {
              accountNumber: form.accountNumber,
              phone: form.phone,
              password: form.password
            };
      const result = await request(path, {
        method: "POST",
        body: JSON.stringify(payload)
      });

      setSession(result);
      window.sessionStorage.setItem(sessionStorageKey, JSON.stringify(result));
      if (portalMode === "customer") {
        setActiveCustomerService("accounts");
      }

      if (portalMode === "admin") {
        await loadAdminDashboard(result.user);
      } else {
        await loadCustomerDashboard(result.user);
      }
    } catch (loginError) {
      setError(loginError.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleRegister(form) {
    setLoading(true);
    setError("");
    setNotice("");
    setStatusResult(null);

    try {
      const result = await request("/api/customers/register", {
        method: "POST",
        body: JSON.stringify(form)
      });

      setAuthView("status");
      setNotice(
        `${result.message} Your request ID is ${result.customerNumber}. You can use Check Status to track approval.`
      );
    } catch (registrationError) {
      setError(registrationError.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleStatusCheck(form) {
    setLoading(true);
    setError("");
    setNotice("");
    setStatusResult(null);

    try {
      const result = await request("/api/customers/status", {
        method: "POST",
        body: JSON.stringify(form)
      });
      setStatusResult(result);
    } catch (statusError) {
      setStatusResult(null);
      setError(statusError.message);
    } finally {
      setLoading(false);
    }
  }

  async function handleApproveCustomer(customerId) {
    try {
      setError("");
      setNotice("");
      const result = await request(`/api/admin/customers/${customerId}/approve`, {
        method: "POST"
      });
      setNotice(`${result.message}. Account number: ${result.accountNumber || "not available"}`);
      await loadAdminDashboard(session.user);
    } catch (approvalError) {
      setError(approvalError.message);
      setNotice(approvalError.message);
    }
  }

  async function handleRejectCustomer(customerId) {
    const reason =
      window.prompt(
        "Enter rejection reason",
        "Sorry, account rejected because of invalid or insufficient details."
      ) || "Sorry, account rejected because of invalid or insufficient details.";

    try {
      setError("");
      setNotice("");
      const result = await request(`/api/admin/customers/${customerId}/reject`, {
        method: "POST",
        body: JSON.stringify({ reason })
      });
      setNotice(`${result.message}. Reason: ${result.reason}`);
      await loadAdminDashboard(session.user);
    } catch (rejectionError) {
      setError(rejectionError.message);
      setNotice(rejectionError.message);
    }
  }

  async function handleApproveCard(cardId) {
    try {
      setError("");
      setNotice("");
      const result = await request(`/api/admin/cards/${cardId}/approve`, {
        method: "POST"
      });
      setNotice(
        `${result.message}. Card number: ${result.cardNumber || "not available"}${
          result.emailMessage ? `. ${result.emailMessage}` : ""
        }`
      );
      await loadAdminDashboard(session.user);
    } catch (approvalError) {
      setError(approvalError.message);
      setNotice(approvalError.message);
    }
  }

  async function handleApproveLoan(loanId) {
    try {
      setError("");
      setNotice("");
      const result = await request(`/api/admin/loans/${loanId}/approve`, {
        method: "POST"
      });
      setNotice(
        `${result.message}. EMI: ${formatCurrency(result.emiAmount)}. Next due: ${result.nextDueDate}${
          result.emailMessage ? `. ${result.emailMessage}` : ""
        }`
      );
      await loadAdminDashboard(session.user);
    } catch (approvalError) {
      setError(approvalError.message);
      setNotice(approvalError.message);
    }
  }

  async function handleRejectLoan(loanId) {
    const reason =
      window.prompt("Enter loan rejection reason", "Loan request rejected by admin.") ||
      "Loan request rejected by admin.";

    try {
      setError("");
      setNotice("");
      const result = await request(`/api/admin/loans/${loanId}/reject`, {
        method: "POST",
        body: JSON.stringify({ reason })
      });
      setNotice(`${result.message}. Reason: ${result.reason}`);
      await loadAdminDashboard(session.user);
    } catch (rejectionError) {
      setError(rejectionError.message);
      setNotice(rejectionError.message);
    }
  }

  async function handleSendLoanReminder(loanId) {
    try {
      setError("");
      setNotice("");
      const result = await request(`/api/admin/loans/${loanId}/send-reminder`, {
        method: "POST"
      });
      setNotice(result.message);
      await loadAdminDashboard(session.user);
    } catch (reminderError) {
      setError(reminderError.message);
      setNotice(reminderError.message);
    }
  }

  async function handleRejectCard(cardId) {
    try {
      setError("");
      setNotice("");
      const result = await request(`/api/admin/cards/${cardId}/reject`, {
        method: "POST",
        body: JSON.stringify({ reason: "Debit card request rejected by admin." })
      });
      setNotice(result.message);
      await loadAdminDashboard(session.user);
    } catch (rejectionError) {
      setError(rejectionError.message);
      setNotice(rejectionError.message);
    }
  }

  async function handleAdminAdjustBalance(accountId, form) {
    try {
      setError("");
      setNotice("");
      if (!accountId) {
        throw new Error("This customer does not have an account id yet. Refresh the admin dashboard and try again.");
      }
      const result = await request(`/api/admin/accounts/${accountId}/adjust-balance`, {
        method: "POST",
        body: JSON.stringify({
          employeeId: session.user.id,
          ...form
        })
      });
      setNotice(
        withEmailNotice(
          `${result.message}. Reference: ${result.referenceCode}. New balance: ${formatCurrency(
            result.runningBalance
          )}`,
          result
        )
      );
      await loadAdminDashboard(session.user);
    } catch (adminError) {
      setError(adminError.message);
      setNotice(adminError.message);
    }
  }

  async function handleAdminSetAccountStatus(accountId, status, reason) {
    try {
      setError("");
      setNotice("");
      if (!accountId) {
        throw new Error("This customer does not have an account id yet. Refresh the admin dashboard and try again.");
      }
      const result = await request(`/api/admin/accounts/${accountId}/status`, {
        method: "POST",
        body: JSON.stringify({
          employeeId: session.user.id,
          status,
          reason
        })
      });
      setNotice(withEmailNotice(`${result.message}. Reference: ${result.referenceCode}`, result));
      await loadAdminDashboard(session.user);
    } catch (adminError) {
      setError(adminError.message);
      setNotice(adminError.message);
    }
  }

  async function handleAdminResetPassword(customerId, newPassword) {
    try {
      setError("");
      setNotice("");
      const result = await request(`/api/admin/customers/${customerId}/reset-password`, {
        method: "POST",
        body: JSON.stringify({
          employeeId: session.user.id,
          newPassword
        })
      });
      setNotice(withEmailNotice(result.message, result));
      await loadAdminDashboard(session.user);
    } catch (adminError) {
      setError(adminError.message);
      setNotice(adminError.message);
    }
  }

  async function handleAdminUpdateCustomerProfile(customerId, form) {
    try {
      setError("");
      setNotice("");
      const result = await request(`/api/admin/customers/${customerId}/update-profile`, {
        method: "POST",
        body: JSON.stringify({
          employeeId: session.user.id,
          ...form
        })
      });
      setNotice(withEmailNotice(result.message, result));
      await loadAdminDashboard(session.user);
    } catch (adminError) {
      setError(adminError.message);
      setNotice(adminError.message);
    }
  }

  async function handleAdminSetCardStatus(cardId, status) {
    const reason =
      window.prompt("Reason for card status update", `Marked ${status} by admin`) ||
      `Marked ${status} by admin`;

    try {
      setError("");
      setNotice("");
      const result = await request(`/api/admin/cards/${cardId}/status`, {
        method: "POST",
        body: JSON.stringify({
          employeeId: session.user.id,
          status,
          reason
        })
      });
      setNotice(withEmailNotice(result.message, result));
      await loadAdminDashboard(session.user);
    } catch (adminError) {
      setError(adminError.message);
      setNotice(adminError.message);
    }
  }

  async function handleAdminUpdateChequeStatus(requestId, status) {
    const reason =
      window.prompt("Reason or note for cheque book status update", `Marked as ${status} by admin`) ||
      `Marked as ${status} by admin`;

    try {
      setError("");
      setNotice("");
      const result = await request(`/api/admin/cheque-books/${requestId}/status`, {
        method: "POST",
        body: JSON.stringify({
          employeeId: session.user.id,
          status,
          reason
        })
      });
      setNotice(withEmailNotice(result.message, result));
      await loadAdminDashboard(session.user);
    } catch (adminError) {
      setError(adminError.message);
      setNotice(adminError.message);
    }
  }

  async function handleCashAction(direction) {
    if (!dashboard.accounts[0]?.id) {
      setError("No active account available for this customer");
      setNotice("No active account available for this customer");
      return;
    }

    if (!cashForm.amount) {
      setError("Please enter an amount");
      setNotice("Please enter an amount");
      return;
    }

    try {
      setError("");
      setNotice("");
      const path = direction === "credit" ? "/api/transactions/deposit" : "/api/transactions/withdraw";
      const result = await request(path, {
        method: "POST",
        body: JSON.stringify({
          accountId: dashboard.accounts[0]?.id,
          customerId: dashboard.customer.id,
          amount: cashForm.amount,
          description: cashForm.description,
          channel: cashForm.channel
        })
      });

      setCashForm({ amount: "", description: "", channel: "online" });
      setNotice(
        withEmailNotice(`${result.message}. New balance: ${formatCurrency(result.runningBalance)}`, result)
      );
      await loadCustomerDashboard(session.user);
    } catch (transactionError) {
      setError(transactionError.message);
      setNotice(transactionError.message);
    }
  }

  async function handleTransfer() {
    if (!transferForm.amount) {
      setError("Please enter transfer amount");
      setNotice("");
      return;
    }

    try {
      setError("");
      setNotice("");
      const result = await request("/api/transactions/transfer", {
        method: "POST",
        body: JSON.stringify({
          accountId: dashboard.accounts[0]?.id,
          customerId: dashboard.customer.id,
          ...transferForm
        })
      });

      setTransferForm({
        transferMode: "same-bank",
        beneficiaryName: "",
        recipientAccountNumber: "",
        recipientBankName: "",
        recipientIfsc: "",
        amount: "",
        description: ""
      });
      setNotice(
        withEmailNotice(`${result.message}. New balance: ${formatCurrency(result.runningBalance)}`, result)
      );
      await loadCustomerDashboard(session.user);
    } catch (transferError) {
      setError(
        transferError.message === "Insufficient balance"
          ? "Insufficient balance. Transfer amount is greater than current balance."
          : transferError.message
      );
      setNotice(transferError.message);
    }
  }

  async function handlePayBill() {
    if (!dashboard.accounts[0]?.id) {
      setError("No active account available for bill payment");
      setNotice("");
      return;
    }

    try {
      setError("");
      setNotice("");
      const result = await request("/api/bills/pay", {
        method: "POST",
        body: JSON.stringify({
          accountId: dashboard.accounts[0].id,
          customerId: dashboard.customer.id,
          ...billPaymentForm
        })
      });

      setBillPaymentForm({
        billCategory: "Electricity",
        billerName: "",
        consumerNumber: "",
        amount: ""
      });
      setNotice(
        withEmailNotice(
          `${result.message}. Reference: ${result.referenceCode}. New balance: ${formatCurrency(
            result.runningBalance
          )}`,
          result
        )
      );
      await loadCustomerDashboard(session.user);
    } catch (billError) {
      setError(
        billError.message === "Insufficient balance"
          ? "Insufficient balance. Bill amount is greater than current balance."
          : billError.message
      );
      setNotice(billError.message);
    }
  }

  async function handleCreateFixedDeposit() {
    if (!dashboard.accounts[0]?.id) {
      setError("No active account available for fixed deposit");
      setNotice("");
      return;
    }

    try {
      setError("");
      setNotice("");
      const result = await request("/api/deposits/fixed", {
        method: "POST",
        body: JSON.stringify({
          accountId: dashboard.accounts[0].id,
          customerId: dashboard.customer.id,
          ...fixedDepositForm
        })
      });

      setFixedDepositForm({
        principalAmount: "",
        tenureMonths: "12",
        annualInterestRate: "7.25"
      });
      setNotice(
        withEmailNotice(
          `${result.message}. Deposit: ${result.depositNumber}. Maturity: ${formatCurrency(
            result.maturityAmount
          )} on ${result.maturityDate}. New balance: ${formatCurrency(result.runningBalance)}`,
          result
        )
      );
      await loadCustomerDashboard(session.user);
    } catch (depositError) {
      setError(
        depositError.message === "Insufficient balance"
          ? "Insufficient balance. Deposit amount is greater than current balance."
          : depositError.message
      );
      setNotice(depositError.message);
    }
  }

  async function handleRequestChequeBook() {
    if (!dashboard.accounts[0]?.id) {
      setError("No active account available for cheque book request");
      setNotice("");
      return;
    }

    try {
      setError("");
      setNotice("");
      const result = await request("/api/cheque-books/request", {
        method: "POST",
        body: JSON.stringify({
          accountId: dashboard.accounts[0].id,
          customerId: dashboard.customer.id,
          ...chequeBookForm
        })
      });

      setChequeBookForm({ leafCount: "25", deliveryAddress: "" });
      setNotice(withEmailNotice(`${result.message}. Request number: ${result.requestNumber}`, result));
    } catch (requestError) {
      setError(requestError.message);
      setNotice(requestError.message);
    }
  }

  async function handleRequestDebitCard(accountId) {
    try {
      setError("");
      setNotice("");
      const result = await request("/api/cards/request-debit-card", {
        method: "POST",
        body: JSON.stringify({
          customerId: dashboard.customer.id,
          accountId,
          provider: "Visa"
        })
      });
      setNotice(withEmailNotice(result.message, result));
      await loadCustomerDashboard(session.user);
    } catch (requestError) {
      setError(requestError.message);
      setNotice(requestError.message);
    }
  }

  async function handleRequestLoan() {
    try {
      setError("");
      setNotice("");
      const result = await request("/api/loans/request", {
        method: "POST",
        body: JSON.stringify({
          customerId: dashboard.customer.id,
          loanType: loanForm.loanType,
          principalAmount: loanForm.principalAmount,
          tenureMonths: loanForm.tenureMonths,
          purpose: loanForm.purpose
        })
      });
      setLoanForm({
        loanType: "personal",
        principalAmount: "",
        tenureMonths: "12",
        annualInterestRate: "13.5",
        purpose: ""
      });
      setNotice(withEmailNotice(result.message, result));
      await loadCustomerDashboard(session.user);
    } catch (loanError) {
      setError(loanError.message);
      setNotice(loanError.message);
    }
  }

  async function handlePayLoan() {
    if (!dashboard.accounts[0]?.id) {
      setError("No active account available for loan payment");
      setNotice("");
      return;
    }

    try {
      setError("");
      setNotice("");
      const result = await request(`/api/loans/${loanPaymentForm.loanId}/pay`, {
        method: "POST",
        body: JSON.stringify({
          customerId: dashboard.customer.id,
          accountId: dashboard.accounts[0].id,
          amount: loanPaymentForm.amount
        })
      });
      setLoanPaymentForm({ loanId: "", amount: "" });
      setNotice(
        withEmailNotice(
          `${result.message}. Outstanding: ${formatCurrency(result.outstandingAmount)}${
            result.nextDueDate ? `. Next due: ${result.nextDueDate}` : ""
          }`,
          result
        )
      );
      await loadCustomerDashboard(session.user);
    } catch (loanError) {
      setError(
        loanError.message === "Insufficient balance"
          ? "Insufficient balance. EMI amount is greater than current balance."
          : loanError.message
      );
      setNotice(loanError.message);
    }
  }

  async function handleSetCardPin() {
    if (!cardPinForm.cardId || !cardPinForm.pin || !cardPinForm.confirmPin) {
      setError("Select a debit card and enter PIN details");
      setNotice("");
      return;
    }

    try {
      setError("");
      setNotice("");
      const result = await request("/api/cards/set-pin", {
        method: "POST",
        body: JSON.stringify({
          cardId: Number(cardPinForm.cardId),
          customerId: dashboard.customer.id,
          pin: cardPinForm.pin,
          confirmPin: cardPinForm.confirmPin
        })
      });
      setCardPinForm({ cardId: "", pin: "", confirmPin: "" });
      setNotice(withEmailNotice(result.message, result));
      await loadCustomerDashboard(session.user);
    } catch (pinError) {
      setError(pinError.message);
      setNotice(pinError.message);
    }
  }

  async function handleCardSpend() {
    try {
      setError("");
      setNotice("");
      const result = await request("/api/cards/spend", {
        method: "POST",
        body: JSON.stringify({
          cardId: Number(cardSpendForm.cardId),
          customerId: dashboard.customer.id,
          amount: cardSpendForm.amount,
          pin: cardSpendForm.pin,
          description: cardSpendForm.description
        })
      });
      setCardSpendForm({ cardId: "", amount: "", pin: "", description: "" });
      setNotice(
        withEmailNotice(`${result.message}. New balance: ${formatCurrency(result.runningBalance)}`, result)
      );
      await loadCustomerDashboard(session.user);
    } catch (cardError) {
      setError(cardError.message);
      setNotice(cardError.message);
    }
  }

  function handleLogout() {
    window.sessionStorage.removeItem(sessionStorageKey);
    setSession(null);
    setDashboard(null);
    setNotice("");
    setError("");
    setStatusResult(null);
    setActiveCustomerService("accounts");
    setLoanPaymentForm({ loanId: "", amount: "" });
  }

  if (portalMode === "ifsc") {
    return <IfscFinder branches={branches} />;
  }

  if (!session || !dashboard) {
    return (
      <LoginView
        authView={authView}
        onAuthViewChange={(nextView) => {
          setAuthView(nextView);
          setError("");
          setNotice("");
          setStatusResult(null);
        }}
        onLogin={handleLogin}
        onRegister={handleRegister}
        onStatusCheck={handleStatusCheck}
        loading={loading}
        error={error}
        notice={notice}
        statusResult={statusResult}
        branches={branches}
        branchLoading={branchLoading}
        branchLoadError={branchLoadError}
        onRetryBranches={loadBranches}
      />
    );
  }

  if (portalMode === "admin" && session.role === "employee") {
    return (
      <AdminDashboard
        dashboard={dashboard}
        onApproveCustomer={handleApproveCustomer}
        onRejectCustomer={handleRejectCustomer}
        onApproveCard={handleApproveCard}
        onRejectCard={handleRejectCard}
        onApproveLoan={handleApproveLoan}
        onRejectLoan={handleRejectLoan}
        onSendLoanReminder={handleSendLoanReminder}
        onAdminAdjustBalance={handleAdminAdjustBalance}
        onAdminSetAccountStatus={handleAdminSetAccountStatus}
        onAdminResetPassword={handleAdminResetPassword}
        onAdminUpdateCustomerProfile={handleAdminUpdateCustomerProfile}
        onAdminSetCardStatus={handleAdminSetCardStatus}
        onAdminUpdateChequeStatus={handleAdminUpdateChequeStatus}
        onLogout={handleLogout}
        notice={notice}
        error={error}
      />
    );
  }

  return (
    <CustomerDashboard
      dashboard={dashboard}
      activeService={activeCustomerService}
      setActiveService={setActiveCustomerService}
      cashForm={cashForm}
      setCashForm={setCashForm}
      loanForm={loanForm}
      setLoanForm={setLoanForm}
      loanPaymentForm={loanPaymentForm}
      setLoanPaymentForm={setLoanPaymentForm}
      transferForm={transferForm}
      setTransferForm={setTransferForm}
      cardPinForm={cardPinForm}
      setCardPinForm={setCardPinForm}
      cardSpendForm={cardSpendForm}
      setCardSpendForm={setCardSpendForm}
      billPaymentForm={billPaymentForm}
      setBillPaymentForm={setBillPaymentForm}
      fixedDepositForm={fixedDepositForm}
      setFixedDepositForm={setFixedDepositForm}
      chequeBookForm={chequeBookForm}
      setChequeBookForm={setChequeBookForm}
      onCashAction={handleCashAction}
      onTransfer={handleTransfer}
      onPayBill={handlePayBill}
      onCreateFixedDeposit={handleCreateFixedDeposit}
      onRequestChequeBook={handleRequestChequeBook}
      onRequestLoan={handleRequestLoan}
      onPayLoan={handlePayLoan}
      onRequestDebitCard={handleRequestDebitCard}
      onSetCardPin={handleSetCardPin}
      onCardSpend={handleCardSpend}
      onRefresh={() => loadCustomerDashboard(session.user)}
      onLogout={handleLogout}
      notice={notice}
      error={error}
    />
  );
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
