const path = require("path");
const dotenv = require("dotenv");

dotenv.config({ path: path.resolve(__dirname, ".env") });
dotenv.config({ path: path.resolve(__dirname, "../.env"), override: false });

const express = require("express");

const app = express();
const port = Number(process.env.FRONTEND_PORT || 3000);
const publicDir = path.join(__dirname, "public");
const distDir = path.join(__dirname, "dist");
const staticDir = process.env.NODE_ENV === "production" && require("fs").existsSync(distDir)
  ? distDir
  : publicDir;

app.use(express.static(staticDir));

app.get("/", (req, res) => {
  res.sendFile(path.join(staticDir, "index.html"));
});

app.get("/admin", (req, res) => {
  res.sendFile(path.join(staticDir, "admin.html"));
});

app.get("/customer", (req, res) => {
  res.sendFile(path.join(staticDir, "customer.html"));
});

app.get("/ifsc", (req, res) => {
  res.sendFile(path.join(staticDir, "ifsc.html"));
});

app.get("/config.js", (req, res) => {
  res.type("application/javascript");
  res.send(`window.APP_CONFIG = ${JSON.stringify({
    apiUrl: process.env.API_URL || "http://localhost:4000"
  })};`);
});

app.listen(port, () => {
  console.log(`Frontend running on port ${port}`);
});
