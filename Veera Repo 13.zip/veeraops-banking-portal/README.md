# Multicloud Devops By Veera Sir Banking Portal

Simple deployment guide for running this banking portal on **two AWS EC2 Amazon Linux 2 servers** with **Amazon RDS MySQL**.

<img src="bank.png" width="2500"/>

## Setup

- EC2 Server 1: Backend API
- EC2 Server 2: Frontend
- Database: Amazon RDS MySQL

## Ports

- Backend runs on port `4000`
- Frontend runs on port `3000`
- RDS MySQL runs on port `3306`

## 1. Create RDS MySQL

Create an Amazon RDS MySQL database.

Recommended database name:

```text
banking_portal
```

Save these values:

```text
RDS endpoint
RDS username
RDS password
Database name
```

## 2. Backend EC2 Deployment

- SSH into backend EC2:


Install packages:

```bash
sudo yum update -y
sudo yum install -y git mariadb105-server
sudo dnf install -y nodejs 
```

Clone project:

```bash
git clone YOUR_REPOSITORY_URL banking-portal
cd banking-portal/backend
```

Install dependencies:

```bash
npm install
```

Create backend `.env`:

```bash
vi .env
```

Add: change the detils 

```env
API_PORT=4000

MYSQL_HOST=YOUR_RDS_ENDPOINT
MYSQL_PORT=3306
MYSQL_USER=YOUR_RDS_USER
MYSQL_PASSWORD=YOUR_RDS_PASSWORD
MYSQL_DATABASE=banking_portal

OTP_MODE=live

MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=true
MAIL_USERNAME=YOUR_EMAIL@gmail.com
MAIL_PASSWORD=YOUR_GOOGLE_APP_PASSWORD
MAIL_DEFAULT_SENDER=YOUR_EMAIL@gmail.com
```

Test RDS connection: and run the schema.sql on backend 

```bash
mysql -h YOUR_RDS_ENDPOINT -u YOUR_RDS_USER -pPassoword < test.sql
```

Start backend:

```bash
npm start
```

Expected output:

```text
Banking API running on port 4000
```

Backend URL:

```text
http://BACKEND_EC2_PUBLIC_IP:4000
```

## 3. Frontend EC2 Deployment

- SSH into frontend EC2:

Install packages:

```bash
sudo yum update -y
sudo yum install -y git 
sudo dnf install -y nodejs 
```

Clone project:

```bash
git clone YOUR_REPOSITORY_URL banking-portal
cd banking-portal/frontend
```

Install dependencies:

```bash
npm install
```

Create frontend `.env`:

```bash
vi .env
```

Add backend API URL:

```env
FRONTEND_PORT=3000
API_URL=http://BACKEND_EC2_PUBLIC_IP:4000
```

Start frontend:

```bash
npm start
```

Expected output:

```text
Frontend running on port 3000
```

Frontend URL:

```text
http://FRONTEND_EC2_PUBLIC_IP:3000
```

## App URLs

Open these in browser:

```text
Main page:       http://FRONTEND_EC2_PUBLIC_IP:3000
Customer portal: http://FRONTEND_EC2_PUBLIC_IP:3000/customer
Admin portal:    http://FRONTEND_EC2_PUBLIC_IP:3000/admin
Backend API:     http://BACKEND_EC2_PUBLIC_IP:4000
```

## Restart Commands

Backend:

```bash
cd ~/banking-portal/backend
npm start
```

Frontend:

```bash
cd ~/banking-portal/frontend
npm start
```

## Notes

- Backend automatically creates required database tables from `backend/schema.sql`.
- Admin portal is not linked from the main page. Open `/admin` directly.
- Use a Gmail App Password for email notifications.
