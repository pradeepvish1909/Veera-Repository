const path = require("path");
const dotenv = require("dotenv");

dotenv.config({ path: path.resolve(__dirname, ".env") });
dotenv.config({ path: path.resolve(__dirname, "../.env"), override: false });

const express = require("express");
const cors = require("cors");
const { getPool, testConnection } = require("./shared/db");
const {
  sendAccountActivityEmail,
  sendApprovalEmail,
  sendDebitCardApprovalEmail,
  sendLoanApprovalEmail,
  sendLoanReminderEmail,
  sendOtpMessage
} = require("./shared/messaging");
const {
  ensureTables,
  getDefaultBankServices,
  getDefaultBranches,
  seedAccounts,
  seedBankServices,
  seedBranches,
  seedCards,
  seedCustomers,
  seedEmployees,
  seedLoans,
  seedTransactions
} = require("./shared/bootstrap");

const app = express();
const port = Number(process.env.API_PORT || 4000);
const otpStore = new Map();
const OTP_EXPIRY_MS = 10 * 60 * 1000;
const corsOptions = {
  origin: "*",
  methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"]
};

app.use(cors(corsOptions));
app.options("*", cors(corsOptions));
app.use(express.json());

app.get("/", (req, res) => {
  res.json({
    name: "banking-api",
    modules: ["auth", "admin", "customers", "accounts", "transactions", "cards", "loans", "services"],
    routes: {
      adminLogin: "/api/auth/admin-login",
      customerLogin: "/api/auth/customer-login",
      customerRegistration: "/api/customers/register",
      sendOtp: "/api/verification/send-otp",
      verifyOtp: "/api/verification/verify-otp",
      customerStatus: "/api/customers/status",
      adminDashboard: "/api/admin/dashboard?employeeId=1",
      approveCustomer: "/api/admin/customers/:customerId/approve",
      rejectCustomer: "/api/admin/customers/:customerId/reject",
      customerDashboard: "/api/customer/dashboard?customerId=1",
      requestDebitCard: "/api/cards/request-debit-card",
      requestLoan: "/api/loans/request",
      setCardPin: "/api/cards/set-pin",
      approveDebitCard: "/api/admin/cards/:cardId/approve",
      approveLoan: "/api/admin/loans/:loanId/approve",
      branches: "/api/branches",
      loanPayment: "/api/loans/:loanId/pay",
      billPayment: "/api/bills/pay",
      fixedDeposit: "/api/deposits/fixed",
      chequeBookRequest: "/api/cheque-books/request",
      services: "/api/services",
      transfer: "/api/transactions/transfer",
      deposit: "/api/transactions/deposit",
      withdraw: "/api/transactions/withdraw",
      debitCardSpend: "/api/cards/spend"
    }
  });
});

app.get("/api/services", async (req, res, next) => {
  try {
    await ensureTables();
    await seedBankServices();

    const [services] = await getPool().query(
      `
        SELECT
          id,
          service_code,
          category,
          service_name,
          short_description,
          detail,
          eligibility,
          required_documents,
          fee_label,
          processing_time,
          channels,
          status,
          sort_order
        FROM bank_services
        WHERE status = 'available'
        ORDER BY sort_order ASC, category ASC, service_name ASC
      `
    );

    res.json(groupBankServices(services));
  } catch (error) {
    try {
      res.json(groupBankServices(getDefaultBankServices()));
    } catch (fallbackError) {
      next(error);
    }
  }
});

app.get("/health", async (req, res, next) => {
  try {
    const pool = getPool();
    const [[counts]] = await pool.query(
      `
        SELECT
          (SELECT COUNT(*) FROM employees) AS employees,
          (SELECT COUNT(*) FROM customers) AS customers,
          (SELECT COUNT(*) FROM accounts) AS accounts,
          (SELECT COUNT(*) FROM transactions) AS transactions,
          (SELECT COUNT(*) FROM cards) AS cards
      `
    );

    res.json({ service: "banking-api", status: "ok", counts });
  } catch (error) {
    next(error);
  }
});

app.get("/api/branches", async (req, res, next) => {
  try {
    await ensureTables();
    await seedBranches();

    const [branches] = await getPool().query(
      `
        SELECT branch_name, city, state_name, ifsc_code
        FROM branches
        ORDER BY branch_name ASC
      `
    );

    res.json(branches);
  } catch (error) {
    try {
      const fallbackBranches = getDefaultBranches()
        .slice()
        .sort((left, right) => left.branch_name.localeCompare(right.branch_name));

      res.json(fallbackBranches);
    } catch (fallbackError) {
      next(error);
    }
  }
});

app.post("/api/verification/send-otp", async (req, res, next) => {
  try {
    const { channel, value } = req.body;

    if (channel !== "email") {
      return res.status(400).json({ message: "Only email verification is enabled" });
    }

    const normalizedValue = normalizeVerificationValue(channel, value);

    if (!normalizedValue) {
      return res.status(400).json({ message: `Valid ${channel || "verification"} value is required` });
    }

    const otp = generateOtpCode();
    const recordKey = getVerificationKey(channel, normalizedValue);

    otpStore.set(recordKey, {
      otp,
      verified: false,
      token: null,
      expiresAt: Date.now() + OTP_EXPIRY_MS
    });

    const delivery = await sendOtpMessage({
      channel,
      destination: normalizedValue,
      otp
    });

    res.json({
      message: delivery.message,
      channel,
      expiresInMinutes: 10,
      deliveryMode: delivery.deliveryMode,
      previewOtp: delivery.previewOtp || null
    });
  } catch (error) {
    next(error);
  }
});

app.post("/api/verification/verify-otp", async (req, res, next) => {
  try {
    const { channel, value, otp } = req.body;
    const normalizedValue = normalizeVerificationValue(channel, value);

    if (!normalizedValue || !otp) {
      return res.status(400).json({ message: "channel, value, and otp are required" });
    }

    const recordKey = getVerificationKey(channel, normalizedValue);
    const record = otpStore.get(recordKey);

    if (!record) {
      return res.status(404).json({ message: "OTP not found. Please request a new OTP." });
    }

    if (record.expiresAt < Date.now()) {
      otpStore.delete(recordKey);
      return res.status(410).json({ message: "OTP expired. Please request a new OTP." });
    }

    if (record.otp !== String(otp).trim()) {
      return res.status(400).json({ message: "Invalid OTP entered" });
    }

    record.verified = true;
    record.token = createVerificationToken(channel);
    otpStore.set(recordKey, record);

    res.json({
      message: `${channel === "email" ? "Email" : "Mobile number"} verified successfully.`,
      verificationToken: record.token
    });
  } catch (error) {
    next(error);
  }
});

app.post("/api/auth/admin-login", async (req, res, next) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: "email and password are required" });
    }

    await ensureTables();
    await seedEmployees();

    const normalizedEmail = String(email).trim().toLowerCase();
    const normalizedPassword = String(password).trim();

    const [[employee]] = await getPool().query(
      `
        SELECT id, employee_code, full_name, email, role, branch
        FROM employees
        WHERE email = ? AND password = ?
        LIMIT 1
      `,
      [normalizedEmail, normalizedPassword]
    );

    if (!employee) {
      return res.status(401).json({ message: "Invalid admin credentials" });
    }

    res.json({ role: "employee", user: employee });
  } catch (error) {
    next(error);
  }
});

app.post("/api/customers/register", async (req, res, next) => {
  try {
    const {
      fullName,
      email,
      phone,
      city,
      password,
      confirmPassword,
      emailVerificationToken,
      requestedAccountType = "savings",
      requestedBranch = "Bengaluru Central",
      employmentStatus,
      employerName,
      monthlyIncome,
      businessName,
      businessAddress
    } = req.body;

    if (!fullName || !email || !phone || !password || !confirmPassword) {
      return res
        .status(400)
        .json({ message: "fullName, email, phone, password, and confirmPassword are required" });
    }

    if (!city || !requestedBranch) {
      return res.status(400).json({ message: "city and requestedBranch are required" });
    }

    const normalizedEmail = normalizeVerificationValue("email", email);
    const normalizedPhone = normalizeVerificationValue("mobile", phone);

    if (!normalizedEmail) {
      return res.status(400).json({ message: "Valid email is required" });
    }

    if (!normalizedPhone) {
      return res.status(400).json({ message: "Valid mobile number is required" });
    }

    if (password !== confirmPassword) {
      return res.status(400).json({ message: "Password and confirm password must match" });
    }

    const passwordValidation = validateStrongPassword(password);

    if (!passwordValidation.valid) {
      return res.status(400).json({ message: passwordValidation.message });
    }

    const emailVerification = verifyStoredToken("email", normalizedEmail, emailVerificationToken);
    if (!emailVerification.valid) {
      return res.status(emailVerification.statusCode).json({ message: emailVerification.message });
    }

    if (requestedAccountType === "salary") {
      if (!employmentStatus || !employerName || !monthlyIncome) {
        return res.status(400).json({
          message:
            "employmentStatus, employerName, and monthlyIncome are required for salary account"
        });
      }
    }

    if (requestedAccountType === "current") {
      if (!employmentStatus || !employerName || !monthlyIncome || !businessName || !businessAddress) {
        return res.status(400).json({
          message:
            "employmentStatus, employerName, monthlyIncome, businessName, and businessAddress are required for current account"
        });
      }
    }

    const pool = getPool();
    const [[existingByPhone]] = await pool.query(
      "SELECT id FROM customers WHERE phone = ? LIMIT 1",
      [normalizedPhone]
    );

    if (existingByPhone) {
      return res.status(409).json({ message: "A customer with this mobile number already exists" });
    }

    if (email) {
      const [[existingByEmail]] = await pool.query(
        "SELECT id FROM customers WHERE email = ? LIMIT 1",
        [normalizedEmail]
      );

      if (existingByEmail) {
        return res.status(409).json({ message: "A customer with this email already exists" });
      }
    }

    const customerNumber = await generateCustomerNumber();
    const [result] = await pool.query(
      `
        INSERT INTO customers
          (
            customer_number,
            full_name,
            email,
            password,
            phone,
            city,
            approval_status,
            requested_account_type,
            requested_branch,
            employment_status,
            employer_name,
            monthly_income,
            business_name,
            business_address
          )
        VALUES (?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        customerNumber,
        fullName,
        normalizedEmail,
        password,
        normalizedPhone,
        city || null,
        requestedAccountType,
        requestedBranch,
        employmentStatus || null,
        employerName || null,
        monthlyIncome ? Number(monthlyIncome) : null,
        businessName || null,
        businessAddress || null
      ]
    );

    res.status(201).json({
      message: "Registration submitted. Admin approval is required before login.",
      customerId: result.insertId,
      customerNumber,
      approvalStatus: "pending"
    });

    clearVerificationRecord("email", normalizedEmail);
  } catch (error) {
    next(error);
  }
});

app.post("/api/auth/customer-login", async (req, res, next) => {
  try {
    const { accountNumber, phone, password } = req.body;

    if (!accountNumber || !phone || !password) {
      return res
        .status(400)
        .json({ message: "accountNumber, phone, and password are required" });
    }

    const pool = getPool();
    const [[customer]] = await pool.query(
      `
        SELECT
          c.id,
          c.customer_number,
          c.full_name,
          c.email,
          c.phone,
          c.city,
          c.approval_status,
          a.id AS primary_account_id,
          a.account_number,
          a.account_type,
          a.balance,
          a.status,
          a.branch,
          a.ifsc_code
        FROM customers c
        INNER JOIN accounts a ON a.customer_id = c.id
        WHERE a.account_number = ?
          AND c.phone = ?
          AND c.password = ?
        LIMIT 1
      `,
      [accountNumber, phone, password]
    );

    if (!customer) {
      return res.status(401).json({ message: "Invalid customer credentials" });
    }

    if (customer.approval_status === "rejected") {
      return res.status(403).json({
        message:
          "Your account request was rejected. Please check your status page for more details."
      });
    }

    if (customer.approval_status !== "approved") {
      return res.status(403).json({ message: "Your registration is pending admin approval" });
    }

    res.json({
      role: "customer",
      user: {
        id: customer.id,
        customer_number: customer.customer_number,
        full_name: customer.full_name,
        email: customer.email,
        phone: customer.phone,
        city: customer.city
      },
      primaryAccount: {
        id: customer.primary_account_id,
        account_number: customer.account_number,
        account_type: customer.account_type,
        balance: customer.balance,
        status: customer.status,
        branch: customer.branch,
        ifsc_code: customer.ifsc_code
      }
    });
  } catch (error) {
    next(error);
  }
});

app.post("/api/customers/status", async (req, res, next) => {
  try {
    const { phone, email, password, city, requestedBranch } = req.body;

    if (!phone || !email || !password || !city || !requestedBranch) {
      return res
        .status(400)
        .json({ message: "phone, email, password, city, and requestedBranch are required" });
    }

    const pool = getPool();
    const [[customer]] = await pool.query(
      `
        SELECT
          c.id,
          c.customer_number,
          c.full_name,
          c.email,
          c.phone,
          c.city,
          c.approval_status,
          c.requested_account_type,
          c.requested_branch,
          c.rejection_reason,
          c.approved_at,
          a.account_number,
          a.account_type,
          a.branch,
          a.ifsc_code
        FROM customers c
        LEFT JOIN accounts a ON a.customer_id = c.id
        WHERE c.phone = ?
          AND c.email = ?
          AND c.password = ?
        ORDER BY a.id ASC
        LIMIT 1
      `,
      [phone, email, password]
    );

    if (!customer) {
      return res.status(404).json({ message: "No customer request found with these details" });
    }

    if (customer.city !== city || customer.requested_branch !== requestedBranch) {
      return res.status(403).json({
        message: "City or branch does not match the original account request details"
      });
    }

    res.json({
      customer: {
        id: customer.id,
        customerNumber: customer.customer_number,
        fullName: customer.full_name,
        email: customer.email,
        phone: customer.phone,
        city: customer.city,
        requestedAccountType: customer.requested_account_type,
        requestedBranch: customer.requested_branch
      },
      status: customer.approval_status,
      accountNumber: customer.account_number || null,
      accountType: customer.account_type || customer.requested_account_type,
      branch: customer.branch || customer.requested_branch,
      ifscCode: customer.ifsc_code || null,
      approvedAt: customer.approved_at,
      rejectionReason:
        customer.rejection_reason || "Sorry, account rejected because of invalid or insufficient details."
    });
  } catch (error) {
    next(error);
  }
});

app.get("/api/admin/dashboard", async (req, res, next) => {
  try {
    const employeeId = Number(req.query.employeeId);

    if (!employeeId) {
      return res.status(400).json({ message: "employeeId is required" });
    }

    const pool = getPool();
    const [[employee]] = await pool.query(
      "SELECT id, employee_code, full_name, email, role, branch FROM employees WHERE id = ? LIMIT 1",
      [employeeId]
    );

    if (!employee) {
      return res.status(404).json({ message: "Employee not found" });
    }

    const [[summary]] = await pool.query(
      `
        SELECT
          (SELECT COUNT(*) FROM customers) AS totalCustomers,
          (SELECT COUNT(*) FROM customers WHERE approval_status = 'pending') AS pendingApprovals,
          (SELECT COUNT(*) FROM accounts) AS totalAccounts,
          (SELECT COUNT(*) FROM cards) AS totalCards,
          (SELECT COUNT(*) FROM loans) AS totalLoans,
          (SELECT COALESCE(SUM(balance), 0) FROM accounts) AS depositsUnderManagement
      `
    );

    const [customers] = await pool.query(
      `
        SELECT
          c.id,
          c.customer_number,
          c.full_name,
          c.email,
          c.phone,
          c.city,
          c.approval_status,
          c.requested_account_type,
          c.requested_branch,
          c.rejection_reason,
          a.id AS account_id,
          a.account_number,
          a.account_type,
          a.balance,
          a.status AS account_status,
          a.branch,
          a.ifsc_code
        FROM customers c
        LEFT JOIN accounts a ON a.customer_id = c.id
        ORDER BY c.id DESC
      `
    );

    const [pendingApplications] = await pool.query(
      `
        SELECT
          id,
          customer_number,
          full_name,
          email,
          phone,
          city,
          requested_account_type,
          requested_branch,
          rejection_reason,
          created_at
        FROM customers
        WHERE approval_status = 'pending'
        ORDER BY id DESC
      `
    );

    const [pendingCardRequests] = await pool.query(
      `
        SELECT
          cd.id,
          cd.card_type,
          cd.provider,
          cd.status,
          cd.approval_status,
          cd.created_at,
          c.full_name,
          c.email,
          c.phone,
          a.account_number,
          a.branch,
          a.ifsc_code
        FROM cards cd
        INNER JOIN customers c ON c.id = cd.customer_id
        INNER JOIN accounts a ON a.id = cd.account_id
        WHERE cd.card_type = 'debit' AND cd.approval_status = 'pending'
        ORDER BY cd.id DESC
      `
    );

    const [pendingLoanRequests] = await pool.query(
      `
        SELECT
          l.id,
          l.loan_type,
          l.purpose,
          l.principal_amount,
          l.tenure_months,
          l.annual_interest_rate,
          l.total_payable_amount,
          l.outstanding_amount,
          l.emi_amount,
          l.approval_status,
          l.rejection_reason,
          l.approved_at,
          l.next_due_date,
          l.last_payment_at,
          l.reminder_sent_at,
          l.status,
          l.created_at,
          c.id AS customer_id,
          c.full_name,
          c.email,
          c.phone
        FROM loans l
        INNER JOIN customers c ON c.id = l.customer_id
        WHERE l.approval_status = 'pending'
        ORDER BY l.id DESC
      `
    );

    const [recentTransactions] = await pool.query(
      `
        SELECT
          t.id,
          t.reference_code,
          t.transaction_type,
          t.channel,
          t.amount,
          t.direction,
          t.description,
          t.running_balance,
          t.created_at,
          c.full_name AS customer_name,
          a.account_number
        FROM transactions t
        INNER JOIN customers c ON c.id = t.customer_id
        INNER JOIN accounts a ON a.id = t.account_id
        ORDER BY t.id DESC
        LIMIT 8
      `
    );
    const [allTransactions] = await pool.query(
      `
        SELECT
          t.id,
          t.reference_code,
          t.transaction_type,
          t.channel,
          t.amount,
          t.direction,
          t.description,
          t.recipient_account_number,
          t.recipient_bank_name,
          t.recipient_ifsc,
          t.transfer_mode,
          t.running_balance,
          t.created_at,
          c.full_name AS customer_name,
          a.account_number
        FROM transactions t
        INNER JOIN customers c ON c.id = t.customer_id
        INNER JOIN accounts a ON a.id = t.account_id
        ORDER BY t.id DESC
        LIMIT 500
      `
    );

    const [allLoansRaw] = await pool.query(
      `
        SELECT
          l.id,
          l.customer_id,
          l.loan_type,
          l.purpose,
          l.principal_amount,
          l.tenure_months,
          l.annual_interest_rate,
          l.total_payable_amount,
          l.outstanding_amount,
          l.emi_amount,
          l.approval_status,
          l.rejection_reason,
          l.approved_at,
          l.next_due_date,
          l.last_payment_at,
          l.reminder_sent_at,
          l.status,
          l.created_at,
          c.full_name AS customer_name
        FROM loans l
        INNER JOIN customers c ON c.id = l.customer_id
        ORDER BY l.id DESC
      `
    );

    const [allCards] = await pool.query(
      `
        SELECT
          cd.id,
          cd.customer_id,
          cd.account_id,
          cd.card_type,
          cd.provider,
          cd.card_number,
          cd.status,
          cd.approval_status,
          cd.rejection_reason,
          cd.approved_at,
          cd.pin_set_at,
          cd.credit_limit,
          cd.available_limit,
          cd.expiry_label,
          cd.created_at,
          c.full_name AS customer_name,
          a.account_number
        FROM cards cd
        INNER JOIN customers c ON c.id = cd.customer_id
        INNER JOIN accounts a ON a.id = cd.account_id
        ORDER BY cd.id DESC
      `
    );

    const [billPayments] = await pool.query(
      `
        SELECT
          bp.id,
          bp.bill_category,
          bp.biller_name,
          bp.consumer_number,
          bp.amount,
          bp.status,
          bp.reference_code,
          bp.paid_at,
          c.full_name AS customer_name,
          a.account_number
        FROM bill_payments bp
        INNER JOIN customers c ON c.id = bp.customer_id
        INNER JOIN accounts a ON a.id = bp.account_id
        ORDER BY bp.id DESC
        LIMIT 50
      `
    );

    const [fixedDeposits] = await pool.query(
      `
        SELECT
          fd.id,
          fd.deposit_number,
          fd.principal_amount,
          fd.tenure_months,
          fd.annual_interest_rate,
          fd.maturity_amount,
          fd.maturity_date,
          fd.status,
          fd.created_at,
          c.full_name AS customer_name,
          a.account_number
        FROM fixed_deposits fd
        INNER JOIN customers c ON c.id = fd.customer_id
        INNER JOIN accounts a ON a.id = fd.account_id
        ORDER BY fd.id DESC
        LIMIT 50
      `
    );

    const [chequeBookRequests] = await pool.query(
      `
        SELECT
          cb.id,
          cb.request_number,
          cb.leaf_count,
          cb.delivery_address,
          cb.status,
          cb.created_at,
          c.full_name AS customer_name,
          c.email,
          c.phone,
          a.account_number
        FROM cheque_book_requests cb
        INNER JOIN customers c ON c.id = cb.customer_id
        INNER JOIN accounts a ON a.id = cb.account_id
        ORDER BY cb.id DESC
        LIMIT 50
      `
    );

    res.json({
      employee,
      summary,
      customers,
      pendingApplications,
      pendingCardRequests,
      pendingLoanRequests: decorateLoans(pendingLoanRequests),
      recentTransactions,
      allTransactions,
      allLoans: decorateLoans(allLoansRaw),
      allCards,
      billPayments,
      fixedDeposits,
      chequeBookRequests
    });
  } catch (error) {
    next(error);
  }
});

app.post("/api/admin/customers/:customerId/approve", async (req, res, next) => {
  try {
    const customerId = Number(req.params.customerId);

    if (!customerId) {
      return res.status(400).json({ message: "customerId is required" });
    }

    const result = await approveCustomer(customerId);
    res.json(result);
  } catch (error) {
    next(error);
  }
});

app.post("/api/admin/customers/:customerId/reject", async (req, res, next) => {
  try {
    const customerId = Number(req.params.customerId);
    const {
      reason = "Sorry, account rejected because of invalid or insufficient details."
    } = req.body || {};

    if (!customerId) {
      return res.status(400).json({ message: "customerId is required" });
    }

    const result = await rejectCustomer(customerId, reason);
    res.json(result);
  } catch (error) {
    next(error);
  }
});

app.post("/api/admin/accounts/:accountId/adjust-balance", async (req, res, next) => {
  try {
    const result = await adminAdjustBalance({
      accountId: Number(req.params.accountId),
      employeeId: Number(req.body.employeeId),
      direction: req.body.direction,
      amount: req.body.amount,
      reason: req.body.reason
    });
    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
});

app.post("/api/admin/accounts/:accountId/status", async (req, res, next) => {
  try {
    const result = await adminSetAccountStatus({
      accountId: Number(req.params.accountId),
      employeeId: Number(req.body.employeeId),
      status: req.body.status,
      reason: req.body.reason
    });
    res.json(result);
  } catch (error) {
    next(error);
  }
});

app.post("/api/admin/customers/:customerId/reset-password", async (req, res, next) => {
  try {
    const result = await adminResetCustomerPassword({
      customerId: Number(req.params.customerId),
      employeeId: Number(req.body.employeeId),
      newPassword: req.body.newPassword
    });
    res.json(result);
  } catch (error) {
    next(error);
  }
});

app.post("/api/admin/customers/:customerId/update-profile", async (req, res, next) => {
  try {
    const result = await adminUpdateCustomerProfile({
      customerId: Number(req.params.customerId),
      employeeId: Number(req.body.employeeId),
      fullName: req.body.fullName,
      email: req.body.email,
      phone: req.body.phone,
      city: req.body.city,
      requestedBranch: req.body.requestedBranch
    });
    res.json(result);
  } catch (error) {
    next(error);
  }
});

app.post("/api/admin/cards/:cardId/status", async (req, res, next) => {
  try {
    const result = await adminSetCardStatus({
      cardId: Number(req.params.cardId),
      employeeId: Number(req.body.employeeId),
      status: req.body.status,
      reason: req.body.reason
    });
    res.json(result);
  } catch (error) {
    next(error);
  }
});

app.post("/api/admin/cheque-books/:requestId/status", async (req, res, next) => {
  try {
    const result = await adminUpdateChequeBookStatus({
      requestId: Number(req.params.requestId),
      employeeId: Number(req.body.employeeId),
      status: req.body.status,
      reason: req.body.reason
    });
    res.json(result);
  } catch (error) {
    next(error);
  }
});

app.post("/api/cards/request-debit-card", async (req, res, next) => {
  try {
    const result = await requestDebitCard(req.body);
    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
});

app.post("/api/admin/cards/:cardId/approve", async (req, res, next) => {
  try {
    const cardId = Number(req.params.cardId);

    if (!cardId) {
      return res.status(400).json({ message: "cardId is required" });
    }

    const result = await approveDebitCard(cardId);
    res.json(result);
  } catch (error) {
    next(error);
  }
});

app.post("/api/admin/cards/:cardId/reject", async (req, res, next) => {
  try {
    const cardId = Number(req.params.cardId);
    const { reason = "Debit card request rejected by admin." } = req.body || {};

    if (!cardId) {
      return res.status(400).json({ message: "cardId is required" });
    }

    const result = await rejectDebitCard(cardId, reason);
    res.json(result);
  } catch (error) {
    next(error);
  }
});

app.post("/api/loans/request", async (req, res, next) => {
  try {
    const result = await requestLoan(req.body);
    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
});

app.post("/api/admin/loans/:loanId/approve", async (req, res, next) => {
  try {
    const loanId = Number(req.params.loanId);

    if (!loanId) {
      return res.status(400).json({ message: "loanId is required" });
    }

    const result = await approveLoan(loanId);
    res.json(result);
  } catch (error) {
    next(error);
  }
});

app.post("/api/admin/loans/:loanId/reject", async (req, res, next) => {
  try {
    const loanId = Number(req.params.loanId);
    const { reason = "Loan request rejected by admin." } = req.body || {};

    if (!loanId) {
      return res.status(400).json({ message: "loanId is required" });
    }

    const result = await rejectLoan(loanId, reason);
    res.json(result);
  } catch (error) {
    next(error);
  }
});

app.post("/api/admin/loans/:loanId/send-reminder", async (req, res, next) => {
  try {
    const loanId = Number(req.params.loanId);

    if (!loanId) {
      return res.status(400).json({ message: "loanId is required" });
    }

    const result = await sendLoanReminder(loanId);
    res.json(result);
  } catch (error) {
    next(error);
  }
});

app.get("/api/customer/dashboard", async (req, res, next) => {
  try {
    const customerId = Number(req.query.customerId);

    if (!customerId) {
      return res.status(400).json({ message: "customerId is required" });
    }

    const pool = getPool();
    const [[customer]] = await pool.query(
      `
        SELECT id, customer_number, full_name, email, phone, city, approval_status
        FROM customers
        WHERE id = ?
        LIMIT 1
      `,
      [customerId]
    );

    if (!customer) {
      return res.status(404).json({ message: "Customer not found" });
    }

    if (customer.approval_status !== "approved") {
      return res.status(403).json({ message: "Customer account is not approved yet" });
    }

    const [accounts, cards, loans, transactions] = await Promise.all([
      listAccounts(customerId),
      listCards(customerId),
      listLoans(customerId),
      listTransactions(customerId, 8)
    ]);

    const totalBalance = accounts.reduce((sum, account) => sum + Number(account.balance), 0);
    const activeCards = cards.filter((card) => card.status === "active").length;
    const approvedLoans = loans.filter((loan) => loan.approval_status === "approved");

    res.json({
      customer,
      summary: {
        totalBalance,
        activeCards,
        outstandingLoans: approvedLoans.reduce(
          (sum, loan) => sum + Number(loan.outstanding_amount || 0),
          0
        ),
        lastTransactionAt: transactions[0]?.created_at || null
      },
      accounts,
      cards,
      loans,
      transactions
    });
  } catch (error) {
    next(error);
  }
});

app.get("/api/customers/:customerId/accounts", async (req, res, next) => {
  try {
    res.json(await listAccounts(Number(req.params.customerId)));
  } catch (error) {
    next(error);
  }
});

app.get("/api/customers/:customerId/transactions", async (req, res, next) => {
  try {
    res.json(await listTransactions(Number(req.params.customerId), 50));
  } catch (error) {
    next(error);
  }
});

app.get("/api/customers/:customerId/cards", async (req, res, next) => {
  try {
    res.json(await listCards(Number(req.params.customerId)));
  } catch (error) {
    next(error);
  }
});

app.get("/api/customers/:customerId/loans", async (req, res, next) => {
  try {
    res.json(await listLoans(Number(req.params.customerId)));
  } catch (error) {
    next(error);
  }
});

app.post("/api/transactions/deposit", async (req, res, next) => {
  try {
    const result = await createTransaction({
      ...req.body,
      direction: "credit",
      transactionType: req.body.transactionType || "cash-deposit"
    });

    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
});

app.post("/api/transactions/withdraw", async (req, res, next) => {
  try {
    const result = await createTransaction({
      ...req.body,
      direction: "debit",
      transactionType: req.body.transactionType || "cash-withdrawal"
    });

    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
});

app.post("/api/transactions/transfer", async (req, res, next) => {
  try {
    const result = await transferFunds(req.body);
    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
});

app.post("/api/bills/pay", async (req, res, next) => {
  try {
    const result = await payBill(req.body);
    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
});

app.post("/api/deposits/fixed", async (req, res, next) => {
  try {
    const result = await createFixedDeposit(req.body);
    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
});

app.post("/api/cheque-books/request", async (req, res, next) => {
  try {
    const result = await requestChequeBook(req.body);
    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
});

app.post("/api/loans/:loanId/pay", async (req, res, next) => {
  try {
    const loanId = Number(req.params.loanId);

    if (!loanId) {
      return res.status(400).json({ message: "loanId is required" });
    }

    const result = await payLoanEmi({ ...req.body, loanId });
    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
});

app.post("/api/cards/spend", async (req, res, next) => {
  try {
    const result = await spendWithDebitCard(req.body);
    res.status(201).json(result);
  } catch (error) {
    next(error);
  }
});

app.post("/api/cards/set-pin", async (req, res, next) => {
  try {
    const result = await setDebitCardPin(req.body);
    res.status(200).json(result);
  } catch (error) {
    next(error);
  }
});

app.use("/api", (req, res) => {
  res.status(404).json({ message: `API route not found: ${req.method} ${req.originalUrl}` });
});

app.use((error, req, res, next) => {
  console.error("Request failed", error);
  res.status(500).json({ message: error.message || "Internal server error" });
});

async function listAccounts(customerId) {
  const [accounts] = await getPool().query(
    `
      SELECT id, account_number, account_type, balance, status, branch, ifsc_code, created_at
      FROM accounts
      WHERE customer_id = ?
      ORDER BY id ASC
    `,
    [customerId]
  );

  return accounts;
}

async function listCards(customerId) {
  const [cards] = await getPool().query(
    `
      SELECT
        id,
        account_id,
        card_type,
        provider,
        card_number,
        status,
        approval_status,
        rejection_reason,
        approved_at,
        pin_set_at,
        credit_limit,
        available_limit,
        expiry_label,
        created_at
      FROM cards
      WHERE customer_id = ?
      ORDER BY id ASC
    `,
    [customerId]
  );

  return cards;
}

async function listLoans(customerId) {
  const [loans] = await getPool().query(
    `
      SELECT
        id,
        loan_type,
        purpose,
        principal_amount,
        tenure_months,
        annual_interest_rate,
        total_payable_amount,
        outstanding_amount,
        emi_amount,
        approval_status,
        rejection_reason,
        approved_at,
        next_due_date,
        last_payment_at,
        reminder_sent_at,
        status,
        created_at
      FROM loans
      WHERE customer_id = ?
      ORDER BY id ASC
    `,
    [customerId]
  );

  return decorateLoans(loans);
}

async function listTransactions(customerId, limit) {
  const [transactions] = await getPool().query(
    `
      SELECT
        id,
        reference_code,
        transaction_type,
        channel,
        amount,
        direction,
        description,
        recipient_account_number,
        recipient_bank_name,
        recipient_ifsc,
        transfer_mode,
        running_balance,
        created_at
      FROM transactions
      WHERE customer_id = ?
      ORDER BY id DESC
      LIMIT ?
    `,
    [customerId, limit]
  );

  return transactions;
}

async function createTransaction({
  accountId,
  amount,
  description,
  channel = "online",
  customerId,
  direction,
  transactionType
}) {
  if (!accountId || !customerId || !amount) {
    throw new Error("accountId, customerId, and amount are required");
  }

  const numericAmount = Number(amount);
  const safeDescription =
    String(description || "").trim() ||
    (direction === "credit" ? "Cash deposit by customer" : "Cash withdrawal by customer");

  if (numericAmount <= 0) {
    throw new Error("Amount must be greater than zero");
  }

  const pool = getPool();
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [[account]] = await connection.query(
      `
        SELECT id, customer_id, balance, status
        FROM accounts
        WHERE id = ? AND customer_id = ?
        LIMIT 1
      `,
      [Number(accountId), Number(customerId)]
    );

    if (!account) {
      throw new Error("Account not found for this customer");
    }

    if (account.status !== "active") {
      throw new Error("Account is not active for transactions");
    }

    let nextBalance = Number(account.balance);

    if (direction === "credit") {
      nextBalance += numericAmount;
    } else {
      if (nextBalance < numericAmount) {
        throw new Error("Insufficient balance");
      }

      nextBalance -= numericAmount;
    }

    await connection.query("UPDATE accounts SET balance = ? WHERE id = ?", [nextBalance, account.id]);

    const referenceCode = `TXN-${Date.now()}`;
    const [result] = await connection.query(
      `
        INSERT INTO transactions
          (
            account_id,
            customer_id,
            reference_code,
            transaction_type,
            channel,
            amount,
            direction,
            description,
            recipient_account_number,
            recipient_bank_name,
            recipient_ifsc,
            transfer_mode,
            running_balance
          )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        account.id,
        Number(customerId),
        referenceCode,
        transactionType,
        channel,
        numericAmount,
        direction,
        safeDescription,
        null,
        null,
        null,
        "internal",
        nextBalance
      ]
    );

    await connection.commit();

    const emailMessage = await sendCustomerActivityNotification({
      customerId: Number(customerId),
      accountId: account.id,
      activityTitle: direction === "credit" ? "Account Credit Alert" : "Account Debit Alert",
      amount: numericAmount,
      direction,
      referenceCode,
      description: safeDescription,
      runningBalance: nextBalance
    });

    return {
      message: direction === "credit" ? "Deposit recorded" : "Withdrawal recorded",
      transactionId: result.insertId,
      referenceCode,
      runningBalance: nextBalance,
      emailMessage
    };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function payBill({
  accountId,
  customerId,
  billCategory,
  billerName,
  consumerNumber,
  amount
}) {
  if (!accountId || !customerId || !billCategory || !billerName || !consumerNumber || !amount) {
    throw new Error("accountId, customerId, billCategory, billerName, consumerNumber, and amount are required");
  }

  const numericAmount = Number(amount);
  const safeBillCategory = String(billCategory).trim();
  const safeBillerName = String(billerName).trim();
  const safeConsumerNumber = String(consumerNumber).trim();

  if (!numericAmount || numericAmount <= 0) {
    throw new Error("Bill amount must be greater than zero");
  }

  if (!safeBillCategory || !safeBillerName || !safeConsumerNumber) {
    throw new Error("Bill category, biller name, and consumer number are required");
  }

  const pool = getPool();
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [[account]] = await connection.query(
      `
        SELECT id, customer_id, balance
        FROM accounts
        WHERE id = ? AND customer_id = ? AND status = 'active'
        LIMIT 1
      `,
      [Number(accountId), Number(customerId)]
    );

    if (!account) {
      throw new Error("Active account not found for this customer");
    }

    const nextBalance = Number(account.balance) - numericAmount;

    if (nextBalance < 0) {
      throw new Error("Insufficient balance");
    }

    await connection.query("UPDATE accounts SET balance = ? WHERE id = ?", [nextBalance, account.id]);

    const transactionReference = `TXN-${Date.now()}`;
    const billReference = `BILL-${Date.now()}`;
    const description = `${safeBillCategory} bill paid to ${safeBillerName} for ${safeConsumerNumber}`;
    const [transactionResult] = await connection.query(
      `
        INSERT INTO transactions
          (
            account_id,
            customer_id,
            reference_code,
            transaction_type,
            channel,
            amount,
            direction,
            description,
            recipient_account_number,
            recipient_bank_name,
            recipient_ifsc,
            transfer_mode,
            running_balance
          )
        VALUES (?, ?, ?, 'bill-payment', 'online', ?, 'debit', ?, ?, ?, NULL, 'bill', ?)
      `,
      [
        account.id,
        Number(customerId),
        transactionReference,
        numericAmount,
        description,
        safeConsumerNumber,
        safeBillerName,
        nextBalance
      ]
    );

    await connection.query(
      `
        INSERT INTO bill_payments
          (
            customer_id,
            account_id,
            transaction_id,
            bill_category,
            biller_name,
            consumer_number,
            amount,
            status,
            reference_code
          )
        VALUES (?, ?, ?, ?, ?, ?, ?, 'paid', ?)
      `,
      [
        Number(customerId),
        account.id,
        transactionResult.insertId,
        safeBillCategory,
        safeBillerName,
        safeConsumerNumber,
        numericAmount,
        billReference
      ]
    );

    await connection.commit();

    const emailMessage = await sendCustomerActivityNotification({
      customerId: Number(customerId),
      accountId: account.id,
      activityTitle: "Bill Payment Alert",
      amount: numericAmount,
      direction: "debit",
      referenceCode: billReference,
      description,
      runningBalance: nextBalance
    });

    return {
      message: "Bill payment completed",
      transactionId: transactionResult.insertId,
      referenceCode: billReference,
      transactionReference,
      runningBalance: nextBalance,
      emailMessage
    };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function createFixedDeposit({
  accountId,
  customerId,
  principalAmount,
  tenureMonths,
  annualInterestRate = 7.25
}) {
  if (!accountId || !customerId || !principalAmount || !tenureMonths) {
    throw new Error("accountId, customerId, principalAmount, and tenureMonths are required");
  }

  const numericPrincipal = Number(principalAmount);
  const numericTenure = Number(tenureMonths);
  const numericRate = Number(annualInterestRate);

  if (!numericPrincipal || numericPrincipal < 1000) {
    throw new Error("Fixed deposit amount must be at least 1000");
  }

  if (!Number.isInteger(numericTenure) || numericTenure < 3 || numericTenure > 120) {
    throw new Error("Fixed deposit tenure must be between 3 and 120 months");
  }

  const pool = getPool();
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [[account]] = await connection.query(
      `
        SELECT id, customer_id, balance
        FROM accounts
        WHERE id = ? AND customer_id = ? AND status = 'active'
        LIMIT 1
      `,
      [Number(accountId), Number(customerId)]
    );

    if (!account) {
      throw new Error("Active account not found for this customer");
    }

    const nextBalance = Number(account.balance) - numericPrincipal;

    if (nextBalance < 0) {
      throw new Error("Insufficient balance");
    }

    const maturityAmount = Number(
      (numericPrincipal + numericPrincipal * (numericRate / 100) * (numericTenure / 12)).toFixed(2)
    );
    const maturityDate = new Date();
    maturityDate.setMonth(maturityDate.getMonth() + numericTenure);

    await connection.query("UPDATE accounts SET balance = ? WHERE id = ?", [nextBalance, account.id]);

    const transactionReference = `TXN-${Date.now()}`;
    const depositNumber = `FD-${Date.now()}`;
    const [transactionResult] = await connection.query(
      `
        INSERT INTO transactions
          (
            account_id,
            customer_id,
            reference_code,
            transaction_type,
            channel,
            amount,
            direction,
            description,
            recipient_account_number,
            recipient_bank_name,
            recipient_ifsc,
            transfer_mode,
            running_balance
          )
        VALUES (?, ?, ?, 'fixed-deposit', 'online', ?, 'debit', ?, NULL, 'Veeraops Fixed Deposit', NULL, 'deposit', ?)
      `,
      [
        account.id,
        Number(customerId),
        transactionReference,
        numericPrincipal,
        `Fixed deposit created for ${numericTenure} months`,
        nextBalance
      ]
    );

    await connection.query(
      `
        INSERT INTO fixed_deposits
          (
            customer_id,
            account_id,
            transaction_id,
            deposit_number,
            principal_amount,
            tenure_months,
            annual_interest_rate,
            maturity_amount,
            maturity_date,
            status
          )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
      `,
      [
        Number(customerId),
        account.id,
        transactionResult.insertId,
        depositNumber,
        numericPrincipal,
        numericTenure,
        numericRate,
        maturityAmount,
        maturityDate.toISOString().slice(0, 10)
      ]
    );

    await connection.commit();

    const emailMessage = await sendCustomerActivityNotification({
      customerId: Number(customerId),
      accountId: account.id,
      activityTitle: "Fixed Deposit Created",
      amount: numericPrincipal,
      direction: "debit",
      referenceCode: depositNumber,
      description: `Fixed deposit created for ${numericTenure} months. Maturity amount ${formatMoneyForEmail(
        maturityAmount
      )} on ${maturityDate.toISOString().slice(0, 10)}`,
      runningBalance: nextBalance
    });

    return {
      message: "Fixed deposit created",
      depositNumber,
      transactionReference,
      maturityAmount,
      maturityDate: maturityDate.toISOString().slice(0, 10),
      runningBalance: nextBalance,
      emailMessage
    };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function requestChequeBook({
  accountId,
  customerId,
  leafCount = 25,
  deliveryAddress
}) {
  if (!accountId || !customerId || !deliveryAddress) {
    throw new Error("accountId, customerId, and deliveryAddress are required");
  }

  const numericLeafCount = Number(leafCount);
  const safeDeliveryAddress = String(deliveryAddress).trim();

  if (![25, 50, 100].includes(numericLeafCount)) {
    throw new Error("leafCount must be 25, 50, or 100");
  }

  if (safeDeliveryAddress.length < 10) {
    throw new Error("Delivery address must be at least 10 characters");
  }

  const pool = getPool();
  const [[account]] = await pool.query(
    `
      SELECT id
      FROM accounts
      WHERE id = ? AND customer_id = ? AND status = 'active'
      LIMIT 1
    `,
    [Number(accountId), Number(customerId)]
  );

  if (!account) {
    throw new Error("Active account not found for this customer");
  }

  const requestNumber = `CHQ-${Date.now()}`;
  const [result] = await pool.query(
    `
      INSERT INTO cheque_book_requests
        (
          customer_id,
          account_id,
          request_number,
          leaf_count,
          delivery_address,
          status
        )
      VALUES (?, ?, ?, ?, ?, 'requested')
    `,
    [Number(customerId), account.id, requestNumber, numericLeafCount, safeDeliveryAddress]
  );

  const emailMessage = await sendCustomerActivityNotification({
    customerId: Number(customerId),
    accountId: account.id,
    activityTitle: "Cheque Book Request",
    amount: null,
    direction: "service",
    referenceCode: requestNumber,
    description: `${numericLeafCount} leaves requested for delivery to ${safeDeliveryAddress}`,
    runningBalance: undefined
  });

  return {
    message: "Cheque book request submitted",
    requestId: result.insertId,
    requestNumber,
    status: "requested",
    emailMessage
  };
}

async function approveCustomer(customerId) {
  const pool = getPool();
  const connection = await pool.getConnection();
  let approvalEmailPayload = null;

  try {
    await connection.beginTransaction();

    const [[customer]] = await connection.query(
      `
        SELECT id, full_name, email, phone, approval_status, requested_account_type, requested_branch
        FROM customers
        WHERE id = ?
        LIMIT 1
      `,
      [customerId]
    );

    if (!customer) {
      throw new Error("Customer not found");
    }

    if (customer.approval_status === "approved") {
      const [[existingAccount]] = await connection.query(
        "SELECT account_number FROM accounts WHERE customer_id = ? ORDER BY id ASC LIMIT 1",
        [customerId]
      );

      return {
        message: "Customer is already approved",
        accountNumber: existingAccount?.account_number || null
      };
    }

    const accountNumber = await generateAccountNumber(connection);
    const ifscCode = await getIfscForBranch(customer.requested_branch, connection);
    await connection.query(
      `
        INSERT INTO accounts (customer_id, account_number, account_type, balance, status, branch, ifsc_code)
        VALUES (?, ?, ?, 0, 'active', ?, ?)
      `,
      [
        customerId,
        accountNumber,
        customer.requested_account_type,
        customer.requested_branch,
        ifscCode
      ]
    );

    await connection.query(
      `
        UPDATE customers
        SET approval_status = 'approved', approved_at = NOW(), rejection_reason = NULL
        WHERE id = ?
      `,
      [customerId]
    );

    await connection.commit();

    approvalEmailPayload = {
      destination: customer.email,
      customerName: customer.full_name,
      accountNumber,
      accountType: customer.requested_account_type,
      branch: customer.requested_branch,
      ifscCode,
      phone: customer.phone
    };

    let emailMessage = null;
    if (approvalEmailPayload.destination) {
      try {
        const delivery = await sendApprovalEmail(approvalEmailPayload);
        emailMessage = delivery.message;
      } catch (emailError) {
        emailMessage = `Account approved, but approval email could not be sent: ${emailError.message}`;
      }
    }

    return {
      message: `Customer approved. Account number generated for ${customer.full_name}`,
      accountNumber,
      ifscCode,
      emailMessage
    };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function requestDebitCard({ customerId, accountId, provider = "Visa" }) {
  if (!customerId || !accountId) {
    throw new Error("customerId and accountId are required");
  }

  const pool = getPool();
  const [[account]] = await pool.query(
    `
      SELECT a.id, a.customer_id, a.account_number
      FROM accounts a
      WHERE a.id = ? AND a.customer_id = ?
      LIMIT 1
    `,
    [Number(accountId), Number(customerId)]
  );

  if (!account) {
    throw new Error("Account not found for this customer");
  }

  const [[existingRequest]] = await pool.query(
    `
      SELECT id
      FROM cards
      WHERE account_id = ?
        AND customer_id = ?
        AND card_type = 'debit'
        AND approval_status IN ('pending', 'approved')
      LIMIT 1
    `,
    [Number(accountId), Number(customerId)]
  );

  if (existingRequest) {
    throw new Error("A debit card request or approved debit card already exists for this account");
  }

  const requestCardNumber = `REQ${Date.now()}${Math.floor(100 + Math.random() * 900)}`;
  const [result] = await pool.query(
    `
      INSERT INTO cards
        (customer_id, account_id, card_type, provider, card_number, status, approval_status, credit_limit, available_limit, expiry_label)
      VALUES (?, ?, 'debit', ?, ?, 'inactive', 'pending', 0, 0, '12/29')
    `,
    [Number(customerId), Number(accountId), provider, requestCardNumber]
  );

  const emailMessage = await sendCustomerActivityNotification({
    customerId: Number(customerId),
    accountId: account.id,
    activityTitle: "Debit Card Request",
    amount: null,
    direction: "service",
    referenceCode: requestCardNumber,
    description: `${provider} debit card request submitted for admin approval`,
    runningBalance: undefined
  });

  return {
    message: "Debit card request submitted for admin approval",
    cardRequestId: result.insertId,
    emailMessage
  };
}

async function approveDebitCard(cardId) {
  const pool = getPool();
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [[card]] = await connection.query(
      `
        SELECT
          cd.id,
          cd.customer_id,
          cd.account_id,
          cd.card_type,
          cd.provider,
          cd.approval_status,
          c.full_name,
          c.email,
          c.phone,
          a.account_number,
          a.branch,
          a.ifsc_code
        FROM cards cd
        INNER JOIN customers c ON c.id = cd.customer_id
        INNER JOIN accounts a ON a.id = cd.account_id
        WHERE cd.id = ?
        LIMIT 1
      `,
      [cardId]
    );

    if (!card) {
      throw new Error("Debit card request not found");
    }

    if (card.card_type !== "debit") {
      throw new Error("Only debit card requests can be approved here");
    }

    if (card.approval_status === "approved") {
      return { message: "Debit card already approved", cardNumber: null };
    }

    const cardNumber = await generateCardNumber(connection);
    const expiryLabel = generateExpiryLabel();

    await connection.query(
      `
        UPDATE cards
        SET card_number = ?, status = 'active', approval_status = 'approved', rejection_reason = NULL, approved_at = NOW(), expiry_label = ?
        WHERE id = ?
      `,
      [cardNumber, expiryLabel, cardId]
    );

    await connection.commit();

    let emailMessage = null;
    if (card.email) {
      try {
        const delivery = await sendDebitCardApprovalEmail({
          destination: card.email,
          customerName: card.full_name,
          branch: card.branch,
          ifscCode: card.ifsc_code,
          cardNumber,
          provider: card.provider,
          expiryLabel,
          accountNumber: card.account_number,
          phone: card.phone
        });
        emailMessage = delivery.message;
      } catch (emailError) {
        emailMessage = `Debit card approved, but email could not be sent: ${emailError.message}`;
      }
    }

    return {
      message: `Debit card approved for ${card.full_name}`,
      cardNumber,
      expiryLabel,
      emailMessage
    };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function rejectDebitCard(cardId, reason) {
  const pool = getPool();
  const [result] = await pool.query(
    `
      UPDATE cards
      SET approval_status = 'rejected', status = 'inactive', rejection_reason = ?, approved_at = NULL
      WHERE id = ? AND approval_status <> 'approved'
    `,
    [reason, cardId]
  );

  if (!result.affectedRows) {
    throw new Error("Debit card request could not be rejected");
  }

  return { message: "Debit card request rejected", reason };
}

async function setDebitCardPin({ cardId, customerId, pin, confirmPin }) {
  if (!cardId || !customerId || !pin || !confirmPin) {
    throw new Error("cardId, customerId, pin, and confirmPin are required");
  }

  const normalizedPin = String(pin).trim();
  const normalizedConfirmPin = String(confirmPin).trim();

  if (!/^\d{4}$/.test(normalizedPin)) {
    throw new Error("Debit card PIN must be exactly 4 digits");
  }

  if (normalizedPin !== normalizedConfirmPin) {
    throw new Error("PIN and confirm PIN do not match");
  }

  const pool = getPool();
  const [[card]] = await pool.query(
    `
      SELECT id, account_id, card_type, status, approval_status
      FROM cards
      WHERE id = ? AND customer_id = ?
      LIMIT 1
    `,
    [Number(cardId), Number(customerId)]
  );

  if (!card) {
    throw new Error("Debit card not found for this customer");
  }

  if (card.card_type !== "debit") {
    throw new Error("PIN can only be set for debit cards");
  }

  if (card.approval_status !== "approved" || card.status !== "active") {
    throw new Error("Only approved active debit cards can have a PIN");
  }

  await pool.query(
    `
      UPDATE cards
      SET pin_code = ?, pin_set_at = NOW()
      WHERE id = ?
    `,
    [normalizedPin, Number(cardId)]
  );

  const emailMessage = await sendCustomerActivityNotification({
    customerId: Number(customerId),
    accountId: card.account_id,
    activityTitle: "Debit Card PIN Updated",
    amount: null,
    direction: "security",
    referenceCode: `PIN-${Date.now()}`,
    description: "Debit card PIN was set or updated from customer portal",
    runningBalance: undefined
  });

  return { message: "Debit card PIN set successfully", emailMessage };
}

async function spendWithDebitCard({ cardId, customerId, amount, pin, description }) {
  if (!cardId || !customerId || !amount) {
    throw new Error("cardId, customerId, and amount are required");
  }

  const pool = getPool();
  const [[card]] = await pool.query(
    `
      SELECT id, account_id, customer_id, status, approval_status, card_type, pin_code
      FROM cards
      WHERE id = ? AND customer_id = ?
      LIMIT 1
    `,
    [Number(cardId), Number(customerId)]
  );

  if (!card) {
    throw new Error("Debit card not found for this customer");
  }

  if (card.card_type !== "debit" || card.approval_status !== "approved" || card.status !== "active") {
    throw new Error("Debit card is not active for transactions");
  }

  const normalizedPin = String(pin || "").trim();

  if (!card.pin_code) {
    throw new Error("Set debit card PIN before using this card");
  }

  if (!/^\d{4}$/.test(normalizedPin)) {
    throw new Error("Enter the 4-digit debit card PIN");
  }

  if (card.pin_code !== normalizedPin) {
    throw new Error("Invalid debit card PIN");
  }

  return createTransaction({
    accountId: card.account_id,
    customerId: Number(customerId),
    amount,
    description: String(description || "").trim() || "Debit card purchase",
    channel: "card",
    direction: "debit",
    transactionType: "debit-card-purchase"
  });
}

async function requestLoan({ customerId, loanType, principalAmount, tenureMonths, purpose }) {
  if (!customerId || !loanType || !principalAmount || !tenureMonths || !purpose) {
    throw new Error("customerId, loanType, principalAmount, tenureMonths, and purpose are required");
  }

  const normalizedLoanType = String(loanType).trim().toLowerCase();
  const numericPrincipalAmount = Number(principalAmount);
  const numericTenureMonths = Number(tenureMonths);
  const annualInterestRate = getLoanInterestRate(normalizedLoanType);

  if (!numericPrincipalAmount || numericPrincipalAmount <= 0) {
    throw new Error("Principal amount must be greater than zero");
  }

  if (!Number.isInteger(numericTenureMonths) || numericTenureMonths < 6 || numericTenureMonths > 360) {
    throw new Error("Tenure months must be between 6 and 360");
  }

  const pool = getPool();
  const [[customer]] = await pool.query(
    `
      SELECT c.id, c.approval_status, a.id AS account_id
      FROM customers c
      LEFT JOIN accounts a ON a.customer_id = c.id AND a.status = 'active'
      WHERE c.id = ?
      ORDER BY a.id ASC
      LIMIT 1
    `,
    [Number(customerId)]
  );

  if (!customer) {
    throw new Error("Customer not found");
  }

  if (customer.approval_status !== "approved") {
    throw new Error("Only approved customers can request loans");
  }

  const [result] = await pool.query(
    `
      INSERT INTO loans
        (
          customer_id,
          loan_type,
          purpose,
          principal_amount,
          tenure_months,
          annual_interest_rate,
          total_payable_amount,
          outstanding_amount,
          emi_amount,
          approval_status,
          status
        )
      VALUES (?, ?, ?, ?, ?, ?, 0, 0, 0, 'pending', 'pending')
    `,
    [
      Number(customerId),
      normalizedLoanType,
      String(purpose).trim(),
      numericPrincipalAmount,
      numericTenureMonths,
      annualInterestRate
    ]
  );

  const emailMessage = customer.account_id
    ? await sendCustomerActivityNotification({
        customerId: Number(customerId),
        accountId: customer.account_id,
        activityTitle: "Loan Request Submitted",
        amount: numericPrincipalAmount,
        direction: "service",
        referenceCode: `LOAN-${result.insertId}`,
        description: `${toTitleCase(normalizedLoanType)} loan request submitted for ${numericTenureMonths} months. Purpose: ${String(
          purpose
        ).trim()}`,
        runningBalance: undefined
      })
    : null;

  return {
    message: "Loan request submitted for admin approval",
    loanRequestId: result.insertId,
    annualInterestRate,
    emailMessage
  };
}

async function approveLoan(loanId) {
  const pool = getPool();
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [[loan]] = await connection.query(
      `
        SELECT
          l.id,
          l.customer_id,
          l.loan_type,
          l.purpose,
          l.principal_amount,
          l.tenure_months,
          l.annual_interest_rate,
          l.approval_status,
          c.full_name,
          c.email
        FROM loans l
        INNER JOIN customers c ON c.id = l.customer_id
        WHERE l.id = ?
        LIMIT 1
      `,
      [Number(loanId)]
    );

    if (!loan) {
      throw new Error("Loan request not found");
    }

    if (loan.approval_status === "approved") {
      return { message: "Loan already approved", emiAmount: null };
    }

    const emiAmount = calculateLoanEmi(
      Number(loan.principal_amount),
      Number(loan.annual_interest_rate),
      Number(loan.tenure_months)
    );
    const totalPayableAmount = roundMoney(emiAmount * Number(loan.tenure_months));
    const nextDueDate = addMonths(new Date(), 1);

    await connection.query(
      `
        UPDATE loans
        SET
          emi_amount = ?,
          total_payable_amount = ?,
          outstanding_amount = ?,
          approval_status = 'approved',
          rejection_reason = NULL,
          approved_at = NOW(),
          next_due_date = ?,
          status = 'active'
        WHERE id = ?
      `,
      [emiAmount, totalPayableAmount, totalPayableAmount, nextDueDate, Number(loanId)]
    );

    await connection.commit();

    let emailMessage = null;
    if (loan.email) {
      try {
        const delivery = await sendLoanApprovalEmail({
          destination: loan.email,
          customerName: loan.full_name,
          loanType: toTitleCase(loan.loan_type),
          principalAmount: formatMoneyForEmail(loan.principal_amount),
          tenureMonths: String(loan.tenure_months),
          annualInterestRate: String(loan.annual_interest_rate),
          emiAmount: formatMoneyForEmail(emiAmount),
          totalPayableAmount: formatMoneyForEmail(totalPayableAmount),
          nextDueDate: formatDateLabel(nextDueDate)
        });
        emailMessage = delivery.message;
      } catch (emailError) {
        emailMessage = `Loan approved, but email could not be sent: ${emailError.message}`;
      }
    }

    return {
      message: `Loan approved for ${loan.full_name}`,
      emiAmount,
      totalPayableAmount,
      nextDueDate: formatDateLabel(nextDueDate),
      emailMessage
    };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function rejectLoan(loanId, reason) {
  const pool = getPool();
  const [result] = await pool.query(
    `
      UPDATE loans
      SET approval_status = 'rejected', rejection_reason = ?, approved_at = NULL, status = 'rejected'
      WHERE id = ? AND approval_status <> 'approved'
    `,
    [reason, Number(loanId)]
  );

  if (!result.affectedRows) {
    throw new Error("Loan request could not be rejected");
  }

  return { message: "Loan request rejected", reason };
}

async function payLoanEmi({ loanId, customerId, accountId, amount }) {
  if (!loanId || !customerId || !accountId) {
    throw new Error("loanId, customerId, and accountId are required");
  }

  const pool = getPool();
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [[loan]] = await connection.query(
      `
        SELECT
          id,
          customer_id,
          loan_type,
          outstanding_amount,
          emi_amount,
          approval_status,
          status,
          next_due_date
        FROM loans
        WHERE id = ? AND customer_id = ?
        LIMIT 1
      `,
      [Number(loanId), Number(customerId)]
    );

    if (!loan) {
      throw new Error("Loan not found for this customer");
    }

    if (loan.approval_status !== "approved" || loan.status !== "active") {
      throw new Error("Only approved active loans can receive EMI payments");
    }

    const paymentAmount = roundMoney(Number(amount || loan.emi_amount));

    if (!paymentAmount || paymentAmount <= 0) {
      throw new Error("Loan payment amount must be greater than zero");
    }

    const [[account]] = await connection.query(
      `
        SELECT id, balance, status
        FROM accounts
        WHERE id = ? AND customer_id = ?
        LIMIT 1
      `,
      [Number(accountId), Number(customerId)]
    );

    if (!account) {
      throw new Error("Account not found for this customer");
    }

    if (account.status !== "active") {
      throw new Error("Account is not active for loan payments");
    }

    if (Number(account.balance) < paymentAmount) {
      throw new Error("Insufficient balance");
    }

    const actualPaymentAmount = Math.min(paymentAmount, Number(loan.outstanding_amount));
    const nextBalance = roundMoney(Number(account.balance) - actualPaymentAmount);
    const nextOutstandingAmount = roundMoney(Number(loan.outstanding_amount) - actualPaymentAmount);
    const nextDueDate = nextOutstandingAmount > 0 ? addMonths(loan.next_due_date || new Date(), 1) : null;
    const nextStatus = nextOutstandingAmount <= 0 ? "closed" : "active";
    const referenceCode = `LNPMT-${Date.now()}`;

    await connection.query("UPDATE accounts SET balance = ? WHERE id = ?", [nextBalance, account.id]);
    await connection.query(
      `
        UPDATE loans
        SET
          outstanding_amount = ?,
          last_payment_at = NOW(),
          next_due_date = ?,
          status = ?
        WHERE id = ?
      `,
      [nextOutstandingAmount, nextDueDate, nextStatus, Number(loanId)]
    );
    await connection.query(
      `
        INSERT INTO transactions
          (
            account_id,
            customer_id,
            reference_code,
            transaction_type,
            channel,
            amount,
            direction,
            description,
            recipient_account_number,
            recipient_bank_name,
            recipient_ifsc,
            transfer_mode,
            running_balance
          )
        VALUES (?, ?, ?, 'loan-emi-payment', 'loan', ?, 'debit', ?, NULL, NULL, NULL, 'internal', ?)
      `,
      [
        account.id,
        Number(customerId),
        referenceCode,
        actualPaymentAmount,
        `${toTitleCase(loan.loan_type)} loan EMI payment`,
        nextBalance
      ]
    );

    await connection.commit();

    const emailMessage = await sendCustomerActivityNotification({
      customerId: Number(customerId),
      accountId: account.id,
      activityTitle: "Loan EMI Payment Alert",
      amount: actualPaymentAmount,
      direction: "debit",
      referenceCode,
      description: `${toTitleCase(loan.loan_type)} loan EMI payment. Outstanding ${formatMoneyForEmail(
        nextOutstandingAmount
      )}`,
      runningBalance: nextBalance
    });

    return {
      message: nextStatus === "closed" ? "Loan closed successfully" : "Loan EMI payment recorded",
      referenceCode,
      runningBalance: nextBalance,
      outstandingAmount: nextOutstandingAmount,
      nextDueDate: nextDueDate ? formatDateLabel(nextDueDate) : null,
      emailMessage
    };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function sendLoanReminder(loanId) {
  const pool = getPool();
  const [[loan]] = await pool.query(
    `
      SELECT
        l.id,
        l.loan_type,
        l.emi_amount,
        l.outstanding_amount,
        l.next_due_date,
        l.approval_status,
        l.status,
        c.full_name,
        c.email
      FROM loans l
      INNER JOIN customers c ON c.id = l.customer_id
      WHERE l.id = ?
      LIMIT 1
    `,
    [Number(loanId)]
  );

  if (!loan) {
    throw new Error("Loan not found");
  }

  if (loan.approval_status !== "approved" || loan.status !== "active") {
    throw new Error("Reminders can be sent only for approved active loans");
  }

  if (!loan.email) {
    throw new Error("Customer email is required to send loan reminder");
  }

  const delivery = await sendLoanReminderEmail({
    destination: loan.email,
    customerName: loan.full_name,
    loanType: toTitleCase(loan.loan_type),
    emiAmount: formatMoneyForEmail(loan.emi_amount),
    outstandingAmount: formatMoneyForEmail(loan.outstanding_amount),
    nextDueDate: formatDateLabel(loan.next_due_date)
  });

  await pool.query("UPDATE loans SET reminder_sent_at = NOW() WHERE id = ?", [Number(loanId)]);

  return {
    message: delivery.message
  };
}

function decorateLoans(loans) {
  return (loans || []).map((loan) => {
    const nextDueDate = loan.next_due_date ? new Date(loan.next_due_date) : null;
    const dueInfo = getLoanDueInfo(nextDueDate, loan.status, loan.approval_status);

    return {
      ...loan,
      loan_type_label: toTitleCase(loan.loan_type),
      due_label: dueInfo.label,
      due_state: dueInfo.state,
      days_until_due: dueInfo.daysUntilDue
    };
  });
}

function groupBankServices(services) {
  const groups = [];
  const groupMap = new Map();

  for (const service of services || []) {
    const category = service.category || "Other";

    if (!groupMap.has(category)) {
      const group = { title: category, items: [] };
      groupMap.set(category, group);
      groups.push(group);
    }

    groupMap.get(category).items.push({
      id: service.id,
      code: service.service_code,
      name: service.service_name,
      title: service.service_name,
      category,
      shortDescription: service.short_description,
      detail: service.detail,
      eligibility: service.eligibility,
      requiredDocuments: service.required_documents,
      feeLabel: service.fee_label,
      processingTime: service.processing_time,
      channels: service.channels,
      status: service.status,
      sortOrder: service.sort_order
    });
  }

  return {
    totalServices: services.length,
    groups
  };
}

async function sendCustomerActivityNotification({
  customerId,
  accountId,
  activityTitle,
  amount,
  direction,
  referenceCode,
  description,
  runningBalance
}) {
  try {
    const [[customer]] = await getPool().query(
      `
        SELECT
          c.full_name,
          c.email,
          a.account_number
        FROM customers c
        LEFT JOIN accounts a ON a.customer_id = c.id AND a.id = ?
        WHERE c.id = ?
        LIMIT 1
      `,
      [Number(accountId), Number(customerId)]
    );

    if (!customer?.email) {
      return "Activity recorded, but customer email is not available.";
    }

    const delivery = await sendAccountActivityEmail({
      destination: customer.email,
      customerName: customer.full_name,
      activityTitle,
      accountNumber: customer.account_number || "-",
      amount: amount ? formatMoneyForEmail(amount) : null,
      direction,
      referenceCode,
      description,
      runningBalance: runningBalance !== undefined ? formatMoneyForEmail(runningBalance) : null,
      activityTime: new Date().toLocaleString("en-IN")
    });

    return delivery.message;
  } catch (emailError) {
    return `Activity recorded, but email could not be sent: ${emailError.message}`;
  }
}

function getLoanDueInfo(nextDueDate, status, approvalStatus) {
  if (approvalStatus === "pending") {
    return { label: "Awaiting admin approval", state: "pending", daysUntilDue: null };
  }

  if (approvalStatus === "rejected") {
    return { label: "Loan request rejected", state: "rejected", daysUntilDue: null };
  }

  if (status === "closed") {
    return { label: "Loan fully paid", state: "approved", daysUntilDue: null };
  }

  if (!nextDueDate) {
    return { label: "Due date will be assigned after approval", state: "pending", daysUntilDue: null };
  }

  const today = new Date();
  const dueDateOnly = new Date(nextDueDate);
  dueDateOnly.setHours(0, 0, 0, 0);
  today.setHours(0, 0, 0, 0);
  const daysUntilDue = Math.round((dueDateOnly - today) / (1000 * 60 * 60 * 24));

  if (daysUntilDue < 0) {
    return { label: `Overdue by ${Math.abs(daysUntilDue)} day(s)`, state: "rejected", daysUntilDue };
  }

  if (daysUntilDue <= 5) {
    return { label: `EMI due in ${daysUntilDue} day(s)`, state: "pending", daysUntilDue };
  }

  return { label: `Next EMI due on ${formatDateLabel(nextDueDate)}`, state: "approved", daysUntilDue };
}

function getLoanInterestRate(loanType) {
  const loanRates = {
    personal: 13.5,
    home: 8.75,
    vehicle: 10.25,
    education: 9.15,
    business: 14.25,
    gold: 11.5
  };

  return loanRates[String(loanType || "").trim().toLowerCase()] || 12.5;
}

function calculateLoanEmi(principalAmount, annualInterestRate, tenureMonths) {
  const monthlyInterestRate = annualInterestRate / 12 / 100;

  if (!monthlyInterestRate) {
    return roundMoney(principalAmount / tenureMonths);
  }

  const factor = Math.pow(1 + monthlyInterestRate, tenureMonths);
  const emiAmount =
    (principalAmount * monthlyInterestRate * factor) / (factor - 1);

  return roundMoney(emiAmount);
}

function roundMoney(amount) {
  return Math.round(Number(amount) * 100) / 100;
}

function addMonths(dateValue, months) {
  const date = new Date(dateValue);
  date.setHours(0, 0, 0, 0);
  date.setMonth(date.getMonth() + Number(months || 0));
  return date;
}

function formatDateLabel(dateValue) {
  if (!dateValue) {
    return "-";
  }

  return new Date(dateValue).toLocaleDateString("en-IN", {
    year: "numeric",
    month: "short",
    day: "numeric"
  });
}

function toTitleCase(value) {
  return String(value || "")
    .split(/[\s-]+/)
    .filter(Boolean)
    .map((segment) => segment.charAt(0).toUpperCase() + segment.slice(1).toLowerCase())
    .join(" ");
}

function formatMoneyForEmail(amount) {
  return `INR ${roundMoney(amount).toFixed(2)}`;
}

async function rejectCustomer(customerId, reason) {
  const pool = getPool();
  const [result] = await pool.query(
    `
      UPDATE customers
      SET approval_status = 'rejected', rejection_reason = ?, approved_at = NULL
      WHERE id = ? AND approval_status <> 'approved'
    `,
    [reason, customerId]
  );

  if (result.affectedRows === 0) {
    const [[customer]] = await pool.query(
      "SELECT approval_status FROM customers WHERE id = ? LIMIT 1",
      [customerId]
    );

    if (!customer) {
      throw new Error("Customer not found");
    }

    if (customer.approval_status === "approved") {
      throw new Error("Approved customers cannot be rejected from this screen");
    }
  }

  return {
    message: "Customer request rejected",
    reason
  };
}

async function requireEmployee(employeeId) {
  if (!employeeId) {
    throw new Error("employeeId is required");
  }

  const [[employee]] = await getPool().query(
    "SELECT id, full_name, role FROM employees WHERE id = ? LIMIT 1",
    [Number(employeeId)]
  );

  if (!employee) {
    throw new Error("Admin employee not found");
  }

  return employee;
}

async function adminAdjustBalance({ accountId, employeeId, direction, amount, reason }) {
  const employee = await requireEmployee(employeeId);

  if (!accountId || !direction || !amount) {
    throw new Error("accountId, direction, and amount are required");
  }

  if (!["credit", "debit"].includes(direction)) {
    throw new Error("direction must be credit or debit");
  }

  const numericAmount = Number(amount);
  const safeReason = String(reason || "").trim() || "Admin account adjustment";

  if (!numericAmount || numericAmount <= 0) {
    throw new Error("Amount must be greater than zero");
  }

  const pool = getPool();
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [[account]] = await connection.query(
      `
        SELECT a.id, a.customer_id, a.balance, a.status, a.account_number, c.full_name
        FROM accounts a
        INNER JOIN customers c ON c.id = a.customer_id
        WHERE a.id = ?
        LIMIT 1
      `,
      [Number(accountId)]
    );

    if (!account) {
      throw new Error("Account not found");
    }

    const nextBalance =
      direction === "credit"
        ? Number(account.balance) + numericAmount
        : Number(account.balance) - numericAmount;

    if (nextBalance < 0) {
      throw new Error("Insufficient balance for admin debit");
    }

    await connection.query("UPDATE accounts SET balance = ? WHERE id = ?", [nextBalance, account.id]);

    const referenceCode = `ADM-${Date.now()}`;
    const [transactionResult] = await connection.query(
      `
        INSERT INTO transactions
          (
            account_id,
            customer_id,
            reference_code,
            transaction_type,
            channel,
            amount,
            direction,
            description,
            recipient_account_number,
            recipient_bank_name,
            recipient_ifsc,
            transfer_mode,
            running_balance
          )
        VALUES (?, ?, ?, 'admin-adjustment', 'admin', ?, ?, ?, NULL, 'Veeraops Bank Admin', NULL, 'admin', ?)
      `,
      [
        account.id,
        account.customer_id,
        referenceCode,
        numericAmount,
        direction,
        `${safeReason} by ${employee.full_name}`,
        nextBalance
      ]
    );

    await connection.commit();

    const emailMessage = await sendCustomerActivityNotification({
      customerId: account.customer_id,
      accountId: account.id,
      activityTitle: direction === "credit" ? "Admin Credit Adjustment" : "Admin Debit Adjustment",
      amount: numericAmount,
      direction,
      referenceCode,
      description: `${safeReason} by ${employee.full_name}`,
      runningBalance: nextBalance
    });

    return {
      message: `Account ${direction} adjustment completed`,
      transactionId: transactionResult.insertId,
      referenceCode,
      runningBalance: nextBalance,
      emailMessage
    };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function adminSetAccountStatus({ accountId, employeeId, status, reason }) {
  const employee = await requireEmployee(employeeId);
  const normalizedStatus = String(status || "").trim().toLowerCase();

  if (!accountId || !normalizedStatus) {
    throw new Error("accountId and status are required");
  }

  if (!["active", "hold", "frozen", "closed"].includes(normalizedStatus)) {
    throw new Error("status must be active, hold, frozen, or closed");
  }

  const pool = getPool();
  const [[account]] = await pool.query(
    `
      SELECT id, customer_id, status, balance
      FROM accounts
      WHERE id = ?
      LIMIT 1
    `,
    [Number(accountId)]
  );

  if (!account) {
    throw new Error("Account not found");
  }

  await pool.query("UPDATE accounts SET status = ? WHERE id = ?", [normalizedStatus, Number(accountId)]);

  const referenceCode = `ACCT-${Date.now()}`;
  const statusDescription = `Account status changed from ${account.status} to ${normalizedStatus} by ${
    employee.full_name
  }. ${reason || "No reason provided."}`;

  await pool.query(
    `
      INSERT INTO transactions
        (
          account_id,
          customer_id,
          reference_code,
          transaction_type,
          channel,
          amount,
          direction,
          description,
          recipient_account_number,
          recipient_bank_name,
          recipient_ifsc,
          transfer_mode,
          running_balance
        )
      VALUES (?, ?, ?, 'account-status', 'admin', 0, 'service', ?, NULL, 'Veeraops Bank Admin', NULL, 'admin', ?)
    `,
    [account.id, account.customer_id, referenceCode, statusDescription, Number(account.balance || 0)]
  );

  const emailMessage = await sendCustomerActivityNotification({
    customerId: account.customer_id,
    accountId: account.id,
    activityTitle: "Account Status Updated",
    amount: null,
    direction: "service",
    referenceCode,
    description: statusDescription,
    runningBalance: Number(account.balance || 0)
  });

  return {
    message: `Account status updated to ${normalizedStatus}`,
    status: normalizedStatus,
    previousStatus: account.status,
    referenceCode,
    emailMessage
  };
}

async function adminResetCustomerPassword({ customerId, employeeId, newPassword }) {
  const employee = await requireEmployee(employeeId);

  if (!customerId || !newPassword) {
    throw new Error("customerId and newPassword are required");
  }

  const passwordValidation = validateStrongPassword(newPassword);

  if (!passwordValidation.valid) {
    throw new Error(passwordValidation.message);
  }

  const pool = getPool();
  const [[customer]] = await pool.query(
    `
      SELECT c.id, a.id AS account_id
      FROM customers c
      LEFT JOIN accounts a ON a.customer_id = c.id
      WHERE c.id = ?
      ORDER BY a.id ASC
      LIMIT 1
    `,
    [Number(customerId)]
  );

  if (!customer) {
    throw new Error("Customer not found");
  }

  await pool.query("UPDATE customers SET password = ? WHERE id = ?", [String(newPassword), Number(customerId)]);

  let emailMessage = null;
  if (customer.account_id) {
    emailMessage = await sendCustomerActivityNotification({
      customerId: Number(customerId),
      accountId: customer.account_id,
      activityTitle: "Customer Password Reset",
      amount: null,
      direction: "security",
      referenceCode: `PWD-${Date.now()}`,
      description: `Your customer portal password was reset by ${employee.full_name}`,
      runningBalance: undefined
    });
  }

  return {
    message: "Customer password reset successfully",
    emailMessage
  };
}

async function adminUpdateCustomerProfile({
  customerId,
  employeeId,
  fullName,
  email,
  phone,
  city,
  requestedBranch
}) {
  const employee = await requireEmployee(employeeId);

  if (!customerId || !fullName || !phone) {
    throw new Error("customerId, fullName, and phone are required");
  }

  const safeEmail = String(email || "").trim().toLowerCase() || null;

  if (safeEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(safeEmail)) {
    throw new Error("Valid email is required");
  }

  const pool = getPool();
  const [[customer]] = await pool.query(
    `
      SELECT c.id, a.id AS account_id
      FROM customers c
      LEFT JOIN accounts a ON a.customer_id = c.id
      WHERE c.id = ?
      ORDER BY a.id ASC
      LIMIT 1
    `,
    [Number(customerId)]
  );

  if (!customer) {
    throw new Error("Customer not found");
  }

  await pool.query(
    `
      UPDATE customers
      SET full_name = ?, email = ?, phone = ?, city = ?, requested_branch = ?
      WHERE id = ?
    `,
    [
      String(fullName).trim(),
      safeEmail,
      String(phone).trim(),
      String(city || "").trim() || null,
      String(requestedBranch || "").trim() || "Bengaluru Central",
      Number(customerId)
    ]
  );

  let emailMessage = null;
  if (customer.account_id) {
    emailMessage = await sendCustomerActivityNotification({
      customerId: Number(customerId),
      accountId: customer.account_id,
      activityTitle: "Customer Profile Updated",
      amount: null,
      direction: "service",
      referenceCode: `PROFILE-${Date.now()}`,
      description: `Customer profile updated by ${employee.full_name}`,
      runningBalance: undefined
    });
  }

  return {
    message: "Customer profile updated",
    emailMessage
  };
}

async function adminSetCardStatus({ cardId, employeeId, status, reason }) {
  const employee = await requireEmployee(employeeId);

  if (!cardId || !status) {
    throw new Error("cardId and status are required");
  }

  if (!["active", "blocked", "inactive"].includes(status)) {
    throw new Error("status must be active, blocked, or inactive");
  }

  const pool = getPool();
  const [[card]] = await pool.query(
    `
      SELECT id, customer_id, account_id, status, card_type, provider, card_number
      FROM cards
      WHERE id = ?
      LIMIT 1
    `,
    [Number(cardId)]
  );

  if (!card) {
    throw new Error("Card not found");
  }

  await pool.query("UPDATE cards SET status = ? WHERE id = ?", [status, Number(cardId)]);

  const emailMessage = await sendCustomerActivityNotification({
    customerId: card.customer_id,
    accountId: card.account_id,
    activityTitle: "Card Status Updated",
    amount: null,
    direction: "security",
    referenceCode: `CARD-${Date.now()}`,
    description: `${toTitleCase(card.card_type)} card ${card.provider} ending ${String(
      card.card_number
    ).slice(-4)} changed from ${card.status} to ${status} by ${employee.full_name}. ${
      reason || "No reason provided."
    }`,
    runningBalance: undefined
  });

  return {
    message: `Card status updated to ${status}`,
    status,
    emailMessage
  };
}

async function adminUpdateChequeBookStatus({ requestId, employeeId, status, reason }) {
  const employee = await requireEmployee(employeeId);

  if (!requestId || !status) {
    throw new Error("requestId and status are required");
  }

  if (!["approved", "dispatched", "delivered", "rejected"].includes(status)) {
    throw new Error("status must be approved, dispatched, delivered, or rejected");
  }

  const pool = getPool();
  const [[requestRow]] = await pool.query(
    `
      SELECT id, customer_id, account_id, request_number, leaf_count, delivery_address, status
      FROM cheque_book_requests
      WHERE id = ?
      LIMIT 1
    `,
    [Number(requestId)]
  );

  if (!requestRow) {
    throw new Error("Cheque book request not found");
  }

  await pool.query("UPDATE cheque_book_requests SET status = ? WHERE id = ?", [
    status,
    Number(requestId)
  ]);

  const emailMessage = await sendCustomerActivityNotification({
    customerId: requestRow.customer_id,
    accountId: requestRow.account_id,
    activityTitle: "Cheque Book Status Updated",
    amount: null,
    direction: "service",
    referenceCode: requestRow.request_number,
    description: `Cheque book request changed from ${requestRow.status} to ${status} by ${
      employee.full_name
    }. ${reason || "No reason provided."}`,
    runningBalance: undefined
  });

  return {
    message: `Cheque book request marked ${status}`,
    status,
    emailMessage
  };
}

async function transferFunds({
  accountId,
  customerId,
  amount,
  beneficiaryName,
  description,
  recipientAccountNumber,
  recipientBankName = "Veeraops Bank",
  recipientIfsc,
  transferMode = "same-bank",
  channel = "online"
}) {
  if (!accountId || !customerId || !amount || !beneficiaryName || !recipientAccountNumber) {
    throw new Error(
      "accountId, customerId, amount, beneficiaryName, and recipientAccountNumber are required"
    );
  }

  if (transferMode === "different-bank" && !recipientIfsc) {
    throw new Error("recipientIfsc is required for different-bank transfer");
  }

  const numericAmount = Number(amount);

  if (numericAmount <= 0) {
    throw new Error("Amount must be greater than zero");
  }

  const pool = getPool();
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [[senderAccount]] = await connection.query(
      `
        SELECT id, customer_id, account_number, balance, ifsc_code, status
        FROM accounts
        WHERE id = ? AND customer_id = ?
        LIMIT 1
      `,
      [Number(accountId), Number(customerId)]
    );

    if (!senderAccount) {
      throw new Error("Account not found for this customer");
    }

    if (senderAccount.status !== "active") {
      throw new Error("Account is not active for transfers");
    }

    if (Number(senderAccount.balance) < numericAmount) {
      throw new Error("Insufficient balance");
    }

    const nextBalance = Number(senderAccount.balance) - numericAmount;
    await connection.query("UPDATE accounts SET balance = ? WHERE id = ?", [
      nextBalance,
      senderAccount.id
    ]);

    const referenceCode = `TRF-${Date.now()}`;
    await connection.query(
      `
        INSERT INTO transactions
          (
            account_id,
            customer_id,
            reference_code,
            transaction_type,
            channel,
            amount,
            direction,
            description,
            recipient_account_number,
            recipient_bank_name,
            recipient_ifsc,
            transfer_mode,
            running_balance
          )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `,
      [
        senderAccount.id,
        Number(customerId),
        referenceCode,
        transferMode === "same-bank" ? "bank-transfer" : "interbank-transfer",
        channel,
        numericAmount,
        "debit",
        description || `Transfer to ${beneficiaryName}`,
        recipientAccountNumber,
        transferMode === "same-bank" ? "Veeraops Bank" : recipientBankName,
        transferMode === "same-bank" ? senderAccount.ifsc_code : recipientIfsc,
        transferMode,
        nextBalance
      ]
    );

    let beneficiaryNotification = null;

    if (transferMode === "same-bank") {
      const [[beneficiaryAccount]] = await connection.query(
        `
          SELECT id, customer_id, balance
          FROM accounts
          WHERE account_number = ?
          LIMIT 1
        `,
        [recipientAccountNumber]
      );

      if (!beneficiaryAccount) {
        throw new Error(
          "Recipient account number was not found in Veeraops Bank. Please check the account number or use Different Bank transfer."
        );
      }

      if (beneficiaryAccount.id === senderAccount.id) {
        throw new Error("You cannot transfer money to the same account");
      }

      const beneficiaryBalance = Number(beneficiaryAccount.balance) + numericAmount;
      await connection.query("UPDATE accounts SET balance = ? WHERE id = ?", [
        beneficiaryBalance,
        beneficiaryAccount.id
      ]);

      await connection.query(
        `
          INSERT INTO transactions
            (
              account_id,
              customer_id,
              reference_code,
              transaction_type,
              channel,
              amount,
              direction,
              description,
              recipient_account_number,
              recipient_bank_name,
              recipient_ifsc,
              transfer_mode,
              running_balance
            )
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `,
        [
          beneficiaryAccount.id,
          beneficiaryAccount.customer_id,
          `${referenceCode}-CR`,
          "bank-transfer-received",
          channel,
          numericAmount,
          "credit",
          `Transfer received from ${senderAccount.account_number}`,
          senderAccount.account_number,
          "Veeraops Bank",
          senderAccount.ifsc_code,
          transferMode,
          beneficiaryBalance
        ]
      );

      beneficiaryNotification = {
        customerId: beneficiaryAccount.customer_id,
        accountId: beneficiaryAccount.id,
        runningBalance: beneficiaryBalance
      };
    }

    await connection.commit();

    const senderEmailMessage = await sendCustomerActivityNotification({
      customerId: Number(customerId),
      accountId: senderAccount.id,
      activityTitle: "Transfer Debit Alert",
      amount: numericAmount,
      direction: "debit",
      referenceCode,
      description: description || `Transfer to ${beneficiaryName}`,
      runningBalance: nextBalance
    });
    let beneficiaryEmailMessage = null;

    if (beneficiaryNotification) {
      beneficiaryEmailMessage = await sendCustomerActivityNotification({
        ...beneficiaryNotification,
        activityTitle: "Transfer Credit Alert",
        amount: numericAmount,
        direction: "credit",
        referenceCode: `${referenceCode}-CR`,
        description: `Transfer received from ${senderAccount.account_number}`
      });
    }

    return {
      message:
        transferMode === "same-bank"
          ? "Transfer completed to Veeraops Bank account"
          : "Transfer initiated to other bank account",
      referenceCode,
      runningBalance: nextBalance,
      emailMessage: senderEmailMessage,
      beneficiaryEmailMessage
    };
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function generateCustomerNumber() {
  const pool = getPool();

  while (true) {
    const candidate = `CUST${Math.floor(100000 + Math.random() * 900000)}`;
    const [[existing]] = await pool.query(
      "SELECT id FROM customers WHERE customer_number = ? LIMIT 1",
      [candidate]
    );

    if (!existing) {
      return candidate;
    }
  }
}

async function generateAccountNumber(connection = getPool()) {
  while (true) {
    const candidate = `501${Math.floor(100000000 + Math.random() * 900000000)}`;
    const [[existing]] = await connection.query(
      "SELECT id FROM accounts WHERE account_number = ? LIMIT 1",
      [candidate]
    );

    if (!existing) {
      return candidate;
    }
  }
}

async function generateCardNumber(connection = getPool()) {
  while (true) {
    const candidate = `4${Math.floor(100000000000000 + Math.random() * 900000000000000)}`;
    const [[existing]] = await connection.query(
      "SELECT id FROM cards WHERE card_number = ? LIMIT 1",
      [candidate]
    );

    if (!existing) {
      return candidate;
    }
  }
}

function generateExpiryLabel() {
  const now = new Date();
  const year = String((now.getFullYear() + 4) % 100).padStart(2, "0");
  const month = String(now.getMonth() + 1).padStart(2, "0");
  return `${month}/${year}`;
}

async function getIfscForBranch(branchName, connection = getPool()) {
  const [[branch]] = await connection.query(
    "SELECT ifsc_code FROM branches WHERE branch_name = ? LIMIT 1",
    [branchName]
  );

  return branch?.ifsc_code || null;
}

function generateOtpCode() {
  return String(Math.floor(100000 + Math.random() * 900000));
}

function createVerificationToken(channel) {
  return `${channel.toUpperCase()}-${Math.random().toString(36).slice(2, 10)}${Date.now()}`;
}

function getVerificationKey(channel, value) {
  return `${channel}:${value}`;
}

function clearVerificationRecord(channel, value) {
  otpStore.delete(getVerificationKey(channel, value));
}

function normalizeVerificationValue(channel, value) {
  const input = String(value || "").trim();

  if (channel === "email") {
    const normalized = input.toLowerCase();
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalized) ? normalized : "";
  }

  if (channel === "mobile") {
    const digitsOnly = input.replace(/\D/g, "");
    return digitsOnly.length === 10 ? digitsOnly : "";
  }

  return "";
}

function validateStrongPassword(password) {
  const input = String(password || "");

  if (input.length < 8) {
    return { valid: false, message: "Password must be at least 8 characters long" };
  }

  if (!/[A-Z]/.test(input) || !/[a-z]/.test(input) || !/\d/.test(input) || !/[^A-Za-z0-9]/.test(input)) {
    return {
      valid: false,
      message: "Password must include uppercase, lowercase, number, and special character"
    };
  }

  return { valid: true };
}

function verifyStoredToken(channel, value, token) {
  const record = otpStore.get(getVerificationKey(channel, value));

  if (!record) {
    return {
      valid: false,
      statusCode: 400,
      message: `${channel === "email" ? "Email" : "Mobile"} verification is required`
    };
  }

  if (record.expiresAt < Date.now()) {
    otpStore.delete(getVerificationKey(channel, value));
    return {
      valid: false,
      statusCode: 410,
      message: `${channel === "email" ? "Email" : "Mobile"} OTP expired. Please verify again.`
    };
  }

  if (!record.verified || record.token !== token) {
    return {
      valid: false,
      statusCode: 400,
      message: `${channel === "email" ? "Email" : "Mobile"} verification is incomplete`
    };
  }

  return { valid: true };
}

async function start() {
  try {
    await testConnection();
    await ensureTables();
    await seedEmployees();
    await seedBranches();
    await seedCustomers();
    await seedAccounts();
    await seedCards();
    await seedLoans();
    await seedTransactions();

    app.listen(port, () => {
      console.log(`Banking API running on port ${port}`);
    });
  } catch (error) {
    console.error("Banking API failed to start", error.message);
    process.exit(1);
  }
}

start();
