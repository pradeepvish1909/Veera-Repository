const fs = require("fs/promises");
const path = require("path");
const { getPool } = require("./db");

async function ensureTables() {
  const pool = getPool();
  const schemaPath = path.resolve(__dirname, "../schema.sql");
  const schemaSql = await fs.readFile(schemaPath, "utf8");
  const statements = schemaSql
    .split(";")
    .map((statement) => statement.trim())
    .filter(Boolean);

  for (const statement of statements) {
    try {
      await pool.query(statement);
    } catch (error) {
      if (error.code !== "ER_DUP_KEYNAME") {
        throw error;
      }
    }
  }

  await ensureLoanColumns();
  await ensureBankServiceColumns();
}

async function ensureLoanColumns() {
  const columns = [
    ["principal_amount", "DECIMAL(12, 2) NOT NULL DEFAULT 0", "loan_type"],
    ["tenure_months", "INT NOT NULL DEFAULT 12", "principal_amount"],
    ["purpose", "VARCHAR(255) DEFAULT NULL", "loan_type"],
    ["annual_interest_rate", "DECIMAL(6, 2) NOT NULL DEFAULT 12.50", "tenure_months"],
    ["total_payable_amount", "DECIMAL(12, 2) NOT NULL DEFAULT 0", "annual_interest_rate"],
    ["outstanding_amount", "DECIMAL(12, 2) NOT NULL DEFAULT 0", "total_payable_amount"],
    ["emi_amount", "DECIMAL(12, 2) NOT NULL DEFAULT 0", "outstanding_amount"],
    ["approval_status", "VARCHAR(20) NOT NULL DEFAULT 'pending'", "emi_amount"],
    ["rejection_reason", "VARCHAR(255) DEFAULT NULL", "approval_status"],
    ["approved_at", "TIMESTAMP NULL DEFAULT NULL", "rejection_reason"],
    ["next_due_date", "DATE DEFAULT NULL", "approved_at"],
    ["last_payment_at", "TIMESTAMP NULL DEFAULT NULL", "next_due_date"],
    ["reminder_sent_at", "TIMESTAMP NULL DEFAULT NULL", "last_payment_at"],
    ["status", "VARCHAR(30) NOT NULL DEFAULT 'pending'", "reminder_sent_at"]
  ];

  for (const [name, definition, afterColumn] of columns) {
    await ensureColumn("loans", name, definition, afterColumn);
  }
}

async function ensureBankServiceColumns() {
  const columns = [
    ["short_description", "VARCHAR(255) NOT NULL DEFAULT ''", "service_name"],
    ["detail", "TEXT NOT NULL", "short_description"],
    ["eligibility", "VARCHAR(255) DEFAULT NULL", "detail"],
    ["required_documents", "VARCHAR(255) DEFAULT NULL", "eligibility"],
    ["fee_label", "VARCHAR(120) DEFAULT 'As per bank policy'", "required_documents"],
    ["processing_time", "VARCHAR(80) DEFAULT 'Instant to 2 working days'", "fee_label"],
    ["channels", "VARCHAR(160) DEFAULT 'Online, branch, mobile banking'", "processing_time"],
    ["status", "VARCHAR(30) NOT NULL DEFAULT 'available'", "channels"],
    ["sort_order", "INT NOT NULL DEFAULT 0", "status"]
  ];

  for (const [name, definition, afterColumn] of columns) {
    await ensureColumn("bank_services", name, definition, afterColumn);
  }
}

async function ensureColumn(tableName, columnName, definition, afterColumn) {
  const pool = getPool();
  const [[column]] = await pool.query(
    `
      SELECT COLUMN_NAME
      FROM INFORMATION_SCHEMA.COLUMNS
      WHERE TABLE_SCHEMA = DATABASE()
        AND TABLE_NAME = ?
        AND COLUMN_NAME = ?
      LIMIT 1
    `,
    [tableName, columnName]
  );

  if (column) {
    return;
  }

  const afterClause = afterColumn ? ` AFTER \`${afterColumn}\`` : "";
  await pool.query(`ALTER TABLE \`${tableName}\` ADD COLUMN \`${columnName}\` ${definition}${afterClause}`);
}

async function seedEmployees() {
  const pool = getPool();
  await pool.query(
    `
      INSERT INTO employees (employee_code, full_name, email, password, role, branch)
      VALUES
        (?, ?, ?, ?, ?, ?),
        (?, ?, ?, ?, ?, ?)
      ON DUPLICATE KEY UPDATE
        full_name = VALUES(full_name),
        email = VALUES(email),
        password = VALUES(password),
        role = VALUES(role),
        branch = VALUES(branch)
    `,
    [
      "EMP1001",
      "veeraops",
      "awscloud1211@gmail.com",
      "multicloud1211",
      "branch-admin",
      "Bengaluru Central",
      "EMP1002",
      "vardhan",
      "ops@bank.local",
      "ops123",
      "operations",
      "Mumbai West"
    ]
  );
}

async function seedBranches() {
  const pool = getPool();
  const [rows] = await pool.query("SELECT COUNT(*) AS count FROM branches");

  if (rows[0].count >= 50) {
    return;
  }

  const branches = getDefaultBranches();
  const values = branches.map(() => "(?, ?, ?, ?)").join(",\n        ");
  const params = branches.flatMap((branch) => [
    branch.branch_name,
    branch.city,
    branch.state_name,
    branch.ifsc_code
  ]);

  await pool.query(
    `
      INSERT INTO branches (branch_name, city, state_name, ifsc_code)
      VALUES
        ${values}
      ON DUPLICATE KEY UPDATE
        city = VALUES(city),
        state_name = VALUES(state_name),
        ifsc_code = VALUES(ifsc_code)
    `,
    params
  );
}

async function seedCustomers() {
  return;
}

async function seedAccounts() {
  return;
}

async function seedCards() {
  return;
}

async function seedLoans() {
  return;
}

async function seedTransactions() {
  return;
}

async function seedBankServices() {
  const pool = getPool();
  const services = getDefaultBankServices();
  const values = services.map(() => "(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)").join(",\n        ");
  const params = services.flatMap((service, index) => [
    service.service_code,
    service.category,
    service.service_name,
    service.short_description,
    service.detail,
    service.eligibility,
    service.required_documents,
    service.fee_label,
    service.processing_time,
    service.channels,
    service.status,
    index + 1
  ]);

  await pool.query(
    `
      INSERT INTO bank_services
        (
          service_code,
          category,
          service_name,
          short_description,
          detail,
          eligibility,
          required_documents,
          fee_label,
          processing_time,
          channels,
          status,
          sort_order
        )
      VALUES
        ${values}
      ON DUPLICATE KEY UPDATE
        category = VALUES(category),
        service_name = VALUES(service_name),
        short_description = VALUES(short_description),
        detail = VALUES(detail),
        eligibility = VALUES(eligibility),
        required_documents = VALUES(required_documents),
        fee_label = VALUES(fee_label),
        processing_time = VALUES(processing_time),
        channels = VALUES(channels),
        status = VALUES(status),
        sort_order = VALUES(sort_order)
    `,
    params
  );
}

function getDefaultBankServices() {
  const groups = [
    ["Accounts", ["Savings account", "Current account", "Salary account", "Joint account", "Minor account", "Senior citizen account", "NRI account", "Dormant account reactivation", "Account nickname", "Account closure request", "Nominee registration", "Overdraft account"]],
    ["Payments", ["Same-bank transfer", "Other-bank transfer", "NEFT transfer", "RTGS transfer", "IMPS transfer", "UPI payment", "QR payment", "Scheduled transfer", "Recurring transfer", "Beneficiary management", "Bulk transfer", "Standing instruction"]],
    ["Cards", ["Debit card request", "Credit card request", "Card PIN setup", "Card spend", "Card block", "Card unblock", "Card limit control", "International usage", "Contactless usage", "Replacement card", "Virtual card", "Card reward points"]],
    ["Loans", ["Personal loan", "Home loan", "Vehicle loan", "Education loan", "Business loan", "Gold loan", "Loan EMI payment", "Loan prepayment", "Loan statement", "Loan reminder", "Top-up loan", "Loan foreclosure"]],
    ["Deposits", ["Fixed deposit", "Recurring deposit", "Tax saver deposit", "Sweep-in deposit", "Deposit renewal", "Deposit closure", "Interest certificate", "Maturity instruction", "Nominee update", "Deposit calculator", "Senior citizen FD", "Auto-renewal setup"]],
    ["Bills", ["Electricity bill", "Water bill", "Gas bill", "Broadband bill", "Mobile recharge", "DTH recharge", "Credit card bill", "Insurance premium", "Rent payment", "Education fee", "FASTag recharge", "Municipal tax"]],
    ["Investments", ["Mutual funds", "SIP setup", "Sovereign gold bonds", "Government bonds", "Demat account", "Trading account", "Portfolio view", "Risk profile", "Goal planning", "Capital gains report", "IPO application", "Retirement planning"]],
    ["Insurance", ["Life insurance", "Health insurance", "Vehicle insurance", "Travel insurance", "Home insurance", "Personal accident cover", "Policy renewal", "Claim intimation", "Premium certificate", "Nominee details", "Policy comparison", "Insurance renewal alert"]],
    ["Security", ["Login password change", "Transaction PIN", "Two-factor authentication", "Device management", "Session logout", "Security alerts", "Fraud report", "Account freeze", "Transaction limits", "Trusted beneficiaries", "Login alert history", "Biometric login"]],
    ["Statements", ["Mini statement", "Detailed statement", "Monthly statement", "Email statement", "Passbook view", "Tax statement", "TDS certificate", "Balance certificate", "Transaction search", "Download receipts", "GST invoice", "Spending report"]],
    ["Branch Services", ["IFSC finder", "Branch locator", "ATM locator", "Locker request", "Cheque book request", "Demand draft", "Cash pickup", "Branch appointment", "KYC update", "Address change", "Locker rent payment", "Relationship manager"]],
    ["Support", ["Service requests", "Complaint tracking", "Dispute transaction", "Chargeback request", "Callback request", "Chat support", "Email support", "FAQ center", "Document upload", "Feedback", "Service ticket history", "Emergency helpline"]],
    ["Business Banking", ["Business current account", "Corporate user roles", "Maker checker approval", "Vendor payments", "Payroll upload", "GST payment", "Tax challan payment", "Trade finance request", "Letter of credit", "Bank guarantee", "POS settlement", "Merchant QR"]],
    ["Digital Services", ["Mobile banking activation", "Internet banking activation", "Device binding", "Profile update", "Email update", "Mobile update", "PAN update", "Aadhaar update", "E-mandate setup", "Auto debit setup", "Notification preferences", "Dark mode preference"]]
  ];

  return groups.flatMap(([category, items]) =>
    items.map((serviceName) => {
      const code = `${category}-${serviceName}`
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-|-$/g, "");

      return {
        service_code: code,
        category,
        service_name: serviceName,
        short_description: getServiceSummary(category, serviceName),
        detail: getServiceDetail(category, serviceName),
        eligibility: getServiceEligibility(category),
        required_documents: getServiceDocuments(category),
        fee_label: getServiceFee(category),
        processing_time: getServiceProcessingTime(category),
        channels: getServiceChannels(category),
        status: "available"
      };
    })
  );
}

function getServiceSummary(category, serviceName) {
  return `${serviceName} service for ${category.toLowerCase()} customers through Veeraops Bank digital and branch channels.`;
}

function getServiceDetail(category, serviceName) {
  const categoryDetail = {
    Accounts: "Open, manage, update, or close bank accounts with branch-linked account identity and nominee support.",
    Payments: "Move money securely using supported transfer rails, beneficiary controls, schedules, and payment receipts.",
    Cards: "Apply for cards, manage PINs, control usage limits, review card activity, and protect cards quickly.",
    Loans: "Apply, track, repay, close, and manage consumer or business loans with EMI and reminder support.",
    Deposits: "Create and manage fixed or recurring deposits with maturity instructions, certificates, and renewal options.",
    Bills: "Pay everyday utility, recharge, tax, rent, insurance, and education bills from a bank account.",
    Investments: "Discover and manage investment services such as funds, bonds, demat, SIPs, goals, and reports.",
    Insurance: "Browse, renew, compare, and manage insurance policies and claim-related service requests.",
    Security: "Protect login, devices, beneficiaries, cards, account access, limits, and suspicious transactions.",
    Statements: "View, search, export, and download statements, certificates, receipts, and account reports.",
    "Branch Services": "Request branch-assisted services such as lockers, cheques, drafts, appointments, and KYC updates.",
    Support: "Raise, track, and resolve service requests, complaints, disputes, documents, and feedback.",
    "Business Banking": "Manage business users, approvals, vendor payments, payroll, tax, trade finance, and merchant services.",
    "Digital Services": "Control online and mobile banking access, profile details, mandates, alerts, and digital preferences."
  };

  return `${serviceName}: ${categoryDetail[category] || "A standard banking service available to eligible customers."}`;
}

function getServiceEligibility(category) {
  const map = {
    Accounts: "Resident or eligible non-resident customers with valid KYC.",
    Payments: "Active customer with a funded account and transaction permissions.",
    Cards: "Approved customer with an eligible active account.",
    Loans: "Approved customer subject to income, credit, and bank policy checks.",
    Deposits: "Customer with an active account and valid KYC.",
    Bills: "Customer with active account balance or approved payment instrument.",
    Investments: "Customer with KYC and suitability or risk profile where required.",
    Insurance: "Customer subject to insurer eligibility and policy terms.",
    Security: "Registered digital banking customer.",
    Statements: "Customer, authorized user, or admin with account access.",
    "Branch Services": "Customer with valid ID and applicable account relationship.",
    Support: "Customer, applicant, or authorized representative.",
    "Business Banking": "Registered business customer with authorized users.",
    "Digital Services": "Customer with verified mobile or email access."
  };

  return map[category] || "Eligible Veeraops Bank customers.";
}

function getServiceDocuments(category) {
  const map = {
    Accounts: "PAN, Aadhaar or ID proof, address proof, photograph.",
    Payments: "Beneficiary details, account number, IFSC where applicable.",
    Cards: "Account details, identity verification, income proof for credit card where required.",
    Loans: "KYC, income proof, bank statement, collateral documents where applicable.",
    Deposits: "KYC and debit account details.",
    Bills: "Biller number, consumer ID, invoice, or recharge details.",
    Investments: "PAN, KYC, demat details, FATCA declaration where applicable.",
    Insurance: "KYC, nominee details, health or asset details where applicable.",
    Security: "Registered mobile, email, account verification, or card details.",
    Statements: "Account number and date range.",
    "Branch Services": "Account number, KYC, request form, supporting proof.",
    Support: "Complaint details, transaction reference, supporting documents.",
    "Business Banking": "Business KYC, authorization letter, GST or registration proof.",
    "Digital Services": "Registered mobile or email, KYC verification."
  };

  return map[category] || "Valid KYC and service-specific documents.";
}

function getServiceFee(category) {
  const freeCategories = ["Security", "Statements", "Support", "Digital Services"];
  return freeCategories.includes(category) ? "Usually free" : "As per bank schedule of charges";
}

function getServiceProcessingTime(category) {
  const map = {
    Payments: "Instant to same working day",
    Cards: "Instant controls, 5 to 7 working days for physical cards",
    Loans: "1 to 7 working days after document verification",
    Deposits: "Instant to 1 working day",
    Bills: "Instant to 2 working days",
    Investments: "Same day to 3 working days",
    Insurance: "Instant quote, policy issuance as per insurer",
    Security: "Instant",
    Statements: "Instant",
    Support: "Same day to 7 working days",
    "Business Banking": "Same day to 5 working days",
    "Digital Services": "Instant to 1 working day"
  };

  return map[category] || "Instant to 2 working days";
}

function getServiceChannels(category) {
  const branchHeavy = ["Branch Services", "Loans", "Business Banking"];
  return branchHeavy.includes(category)
    ? "Online, mobile banking, branch, relationship manager"
    : "Online, mobile banking, branch";
}

function getDefaultBranches() {
  return [
    ["Bengaluru Central", "Bengaluru", "Karnataka"],
    ["Mysuru Palace", "Mysuru", "Karnataka"],
    ["Mangaluru Coast", "Mangaluru", "Karnataka"],
    ["Hubballi Trade", "Hubballi", "Karnataka"],
    ["Belagavi Fort", "Belagavi", "Karnataka"],
    ["Mumbai West", "Mumbai", "Maharashtra"],
    ["Pune Main", "Pune", "Maharashtra"],
    ["Nagpur Orange", "Nagpur", "Maharashtra"],
    ["Nashik Valley", "Nashik", "Maharashtra"],
    ["Aurangabad Heritage", "Chhatrapati Sambhajinagar", "Maharashtra"],
    ["Delhi Central", "New Delhi", "Delhi"],
    ["Chennai South", "Chennai", "Tamil Nadu"],
    ["Coimbatore Textile", "Coimbatore", "Tamil Nadu"],
    ["Madurai Temple", "Madurai", "Tamil Nadu"],
    ["Trichy Junction", "Tiruchirappalli", "Tamil Nadu"],
    ["Salem Steel", "Salem", "Tamil Nadu"],
    ["Tirunelveli Delta", "Tirunelveli", "Tamil Nadu"],
    ["Hyderabad Prime", "Hyderabad", "Telangana"],
    ["Warangal Heritage", "Warangal", "Telangana"],
    ["Karimnagar Gold", "Karimnagar", "Telangana"],
    ["Nizamabad Square", "Nizamabad", "Telangana"],
    ["Khammam Trade", "Khammam", "Telangana"],
    ["Visakhapatnam Port", "Visakhapatnam", "Andhra Pradesh"],
    ["Vijayawada Capital", "Vijayawada", "Andhra Pradesh"],
    ["Guntur Spice", "Guntur", "Andhra Pradesh"],
    ["Kurnool Gateway", "Kurnool", "Andhra Pradesh"],
    ["Rajahmundry Godavari", "Rajahmundry", "Andhra Pradesh"],
    ["Tirupati Temple", "Tirupati", "Andhra Pradesh"],
    ["Nellore Coast", "Nellore", "Andhra Pradesh"],
    ["Kolkata North", "Kolkata", "West Bengal"],
    ["Siliguri Hills", "Siliguri", "West Bengal"],
    ["Durgapur Steel", "Durgapur", "West Bengal"],
    ["Ahmedabad City", "Ahmedabad", "Gujarat"],
    ["Surat Diamond", "Surat", "Gujarat"],
    ["Vadodara Crown", "Vadodara", "Gujarat"],
    ["Rajkot Metro", "Rajkot", "Gujarat"],
    ["Jaipur Pink City", "Jaipur", "Rajasthan"],
    ["Jodhpur Blue", "Jodhpur", "Rajasthan"],
    ["Udaipur Lake", "Udaipur", "Rajasthan"],
    ["Kota Education", "Kota", "Rajasthan"],
    ["Lucknow Capital", "Lucknow", "Uttar Pradesh"],
    ["Kanpur Market", "Kanpur", "Uttar Pradesh"],
    ["Varanasi Ghat", "Varanasi", "Uttar Pradesh"],
    ["Noida Tech Park", "Noida", "Uttar Pradesh"],
    ["Ghaziabad Link", "Ghaziabad", "Uttar Pradesh"],
    ["Agra Heritage", "Agra", "Uttar Pradesh"],
    ["Prayagraj Sangam", "Prayagraj", "Uttar Pradesh"],
    ["Patna Riverfront", "Patna", "Bihar"],
    ["Gaya Temple", "Gaya", "Bihar"],
    ["Muzaffarpur Litchi", "Muzaffarpur", "Bihar"],
    ["Bhopal Lake View", "Bhopal", "Madhya Pradesh"],
    ["Indore Commerce", "Indore", "Madhya Pradesh"],
    ["Jabalpur Marble", "Jabalpur", "Madhya Pradesh"],
    ["Gwalior Fort", "Gwalior", "Madhya Pradesh"],
    ["Chandigarh Plaza", "Chandigarh", "Chandigarh"],
    ["Gurugram Corporate", "Gurugram", "Haryana"],
    ["Faridabad Metro", "Faridabad", "Haryana"],
    ["Panipat Looms", "Panipat", "Haryana"],
    ["Ludhiana Textile", "Ludhiana", "Punjab"],
    ["Amritsar Heritage", "Amritsar", "Punjab"],
    ["Jalandhar Sports", "Jalandhar", "Punjab"],
    ["Kochi Marine", "Kochi", "Kerala"],
    ["Thiruvananthapuram Tech", "Thiruvananthapuram", "Kerala"],
    ["Kozhikode Beach", "Kozhikode", "Kerala"],
    ["Thrissur Gold", "Thrissur", "Kerala"],
    ["Bhubaneswar Smart", "Bhubaneswar", "Odisha"],
    ["Cuttack Silver", "Cuttack", "Odisha"],
    ["Rourkela Steel", "Rourkela", "Odisha"],
    ["Ranchi Hills", "Ranchi", "Jharkhand"],
    ["Jamshedpur Steel", "Jamshedpur", "Jharkhand"],
    ["Dhanbad Coal", "Dhanbad", "Jharkhand"],
    ["Raipur Green", "Raipur", "Chhattisgarh"],
    ["Bilaspur Central", "Bilaspur", "Chhattisgarh"],
    ["Korba Power", "Korba", "Chhattisgarh"],
    ["Guwahati Gateway", "Guwahati", "Assam"],
    ["Dibrugarh Tea", "Dibrugarh", "Assam"],
    ["Shillong Peak", "Shillong", "Meghalaya"],
    ["Imphal Valley", "Imphal", "Manipur"],
    ["Aizawl Ridge", "Aizawl", "Mizoram"],
    ["Agartala Palace", "Agartala", "Tripura"],
    ["Kohima Hills", "Kohima", "Nagaland"],
    ["Itanagar Green", "Itanagar", "Arunachal Pradesh"],
    ["Gangtok Summit", "Gangtok", "Sikkim"],
    ["Dehradun Valley", "Dehradun", "Uttarakhand"],
    ["Haridwar Ganga", "Haridwar", "Uttarakhand"],
    ["Srinagar Valley", "Srinagar", "Jammu and Kashmir"],
    ["Jammu City", "Jammu", "Jammu and Kashmir"],
    ["Shimla Ridge", "Shimla", "Himachal Pradesh"],
    ["Dharamshala Peak", "Dharamshala", "Himachal Pradesh"],
    ["Leh Heights", "Leh", "Ladakh"],
    ["Puducherry Coast", "Puducherry", "Puducherry"],
    ["Port Blair Bay", "Port Blair", "Andaman and Nicobar Islands"],
    ["Kavaratti Coral", "Kavaratti", "Lakshadweep"],
    ["Daman Harbor", "Daman", "Dadra and Nagar Haveli and Daman and Diu"],
    ["Silvassa River", "Silvassa", "Dadra and Nagar Haveli and Daman and Diu"],
    ["Goa Panaji", "Panaji", "Goa"]
  ].map((branch, index) => ({
    branch_name: branch[0],
    city: branch[1],
    state_name: branch[2],
    ifsc_code: `VEER${String(index + 1001).padStart(7, "0")}`
  }));
}

module.exports = {
  ensureTables,
  getDefaultBranches,
  getDefaultBankServices,
  seedAccounts,
  seedBankServices,
  seedBranches,
  seedCards,
  seedCustomers,
  seedEmployees,
  seedLoans,
  seedTransactions
};
