function getMessagingConfig() {
  return {
    otpMode: process.env.OTP_MODE || "demo",
    emailFrom:
      process.env.OTP_EMAIL_FROM ||
      process.env.MAIL_DEFAULT_SENDER ||
      process.env.MAIL_USERNAME ||
      process.env.SMTP_USER ||
      "",
    smtpHost: process.env.MAIL_SERVER || process.env.SMTP_HOST || "smtp.gmail.com",
    smtpPort: Number(process.env.MAIL_PORT || process.env.SMTP_PORT || 587),
    smtpSecure:
      String(
        process.env.MAIL_USE_SSL ||
          (String(process.env.MAIL_USE_TLS || "").toLowerCase() === "true" ? "false" : "") ||
          process.env.SMTP_SECURE ||
          "false"
      ) === "true",
    smtpUser: process.env.MAIL_USERNAME || process.env.SMTP_USER || "",
    smtpPass: process.env.MAIL_PASSWORD || process.env.SMTP_PASS || "",
    smtpService: process.env.SMTP_SERVICE || ""
  };
}

async function sendOtpMessage({ channel, destination, otp }) {
  const config = getMessagingConfig();

  if (config.otpMode !== "live") {
    return {
      deliveryMode: "demo",
      message: `OTP generated for ${channel}. Demo mode is active.`,
      previewOtp: otp
    };
  }

  if (channel === "email") {
    await sendEmailOtp(destination, otp, config);

    return {
      deliveryMode: "live",
      message: `OTP sent to email ${destination}.`
    };
  }

  throw new Error("Unsupported OTP delivery channel");
}

async function sendEmailOtp(destination, otp, config) {
  await ensureEmailConfig(config);
  const transporter = createTransporter(config);

  await transporter.sendMail({
    from: config.emailFrom || config.smtpUser,
    to: destination,
    subject: "Veeraops Bank OTP Verification",
    text: `Your Veeraops Bank OTP is ${otp}. It will expire in 10 minutes.`,
    html: `<div style="font-family:Segoe UI,Tahoma,sans-serif;line-height:1.6">
      <h2>Veeraops Bank Verification</h2>
      <p>Your OTP is <strong style="font-size:20px;letter-spacing:2px">${otp}</strong>.</p>
      <p>This OTP will expire in 10 minutes.</p>
      <p>If you did not request this, please ignore this email.</p>
    </div>`
  });
}

async function sendApprovalEmail({
  destination,
  customerName,
  accountNumber,
  accountType,
  branch,
  ifscCode,
  phone
}) {
  const config = getMessagingConfig();

  if (config.otpMode !== "live") {
    return {
      deliveryMode: "demo",
      message: `Approval email prepared for ${destination} in demo mode.`
    };
  }

  await ensureEmailConfig(config);
  const transporter = createTransporter(config);

  await transporter.sendMail({
    from: config.emailFrom || config.smtpUser,
    to: destination,
    subject: "Veeraops Bank Account Approved",
    text:
      `Dear ${customerName}, your Veeraops Bank account has been approved.\n` +
      `Account Number: ${accountNumber}\n` +
      `Account Type: ${accountType}\n` +
      `Branch: ${branch}\n` +
      `IFSC: ${ifscCode}\n` +
      `Registered Mobile: ${phone}\n` +
      `You can now log in using your account number, mobile number, and password.`,
    html: `<div style="font-family:Segoe UI,Tahoma,sans-serif;line-height:1.6;color:#1a2a3d">
      <h2 style="margin-bottom:8px">Veeraops Bank Account Approved</h2>
      <p>Dear <strong>${escapeHtml(customerName)}</strong>, your account request has been approved.</p>
      <div style="padding:16px 18px;border-radius:16px;background:#f4f9fc;border:1px solid #d7e6ee">
        <p style="margin:0 0 8px"><strong>Account Number:</strong> ${escapeHtml(accountNumber)}</p>
        <p style="margin:0 0 8px"><strong>Account Type:</strong> ${escapeHtml(accountType)}</p>
        <p style="margin:0 0 8px"><strong>Branch:</strong> ${escapeHtml(branch)}</p>
        <p style="margin:0 0 8px"><strong>IFSC Code:</strong> ${escapeHtml(ifscCode || "-")}</p>
        <p style="margin:0"><strong>Registered Mobile:</strong> ${escapeHtml(phone || "-")}</p>
      </div>
      <p style="margin-top:16px">You can now log in using your account number, mobile number, and password.</p>
      <p>If you did not request this account, please contact Veeraops Bank support immediately.</p>
    </div>`
  });

  return {
    deliveryMode: "live",
    message: `Approval email sent to ${destination}.`
  };
}

async function sendDebitCardApprovalEmail({
  destination,
  customerName,
  branch,
  ifscCode,
  cardNumber,
  provider,
  expiryLabel,
  accountNumber
}) {
  const config = getMessagingConfig();

  if (config.otpMode !== "live") {
    return {
      deliveryMode: "demo",
      message: `Debit card approval email prepared for ${destination} in demo mode.`
    };
  }

  await ensureEmailConfig(config);
  const transporter = createTransporter(config);

  await transporter.sendMail({
    from: config.emailFrom || config.smtpUser,
    to: destination,
    subject: "Veeraops Bank Debit Card Approved",
    text:
      `Dear ${customerName}, your debit card request has been approved.\n` +
      `Card Number: ${cardNumber}\n` +
      `Provider: ${provider}\n` +
      `Expiry: ${expiryLabel}\n` +
      `Linked Account Number: ${accountNumber}\n` +
      `Branch: ${branch}\n` +
      `IFSC: ${ifscCode}\n`,
    html: `<div style="font-family:Segoe UI,Tahoma,sans-serif;line-height:1.6;color:#1a2a3d">
      <h2 style="margin-bottom:8px">Veeraops Bank Debit Card Approved</h2>
      <p>Dear <strong>${escapeHtml(customerName)}</strong>, your debit card request has been approved.</p>
      <div style="padding:16px 18px;border-radius:16px;background:#f4f9fc;border:1px solid #d7e6ee">
        <p style="margin:0 0 8px"><strong>Card Number:</strong> ${escapeHtml(cardNumber)}</p>
        <p style="margin:0 0 8px"><strong>Provider:</strong> ${escapeHtml(provider)}</p>
        <p style="margin:0 0 8px"><strong>Expiry:</strong> ${escapeHtml(expiryLabel)}</p>
        <p style="margin:0 0 8px"><strong>Linked Account:</strong> ${escapeHtml(accountNumber)}</p>
        <p style="margin:0 0 8px"><strong>Branch:</strong> ${escapeHtml(branch)}</p>
        <p style="margin:0"><strong>IFSC Code:</strong> ${escapeHtml(ifscCode || "-")}</p>
      </div>
      <p style="margin-top:16px">You can now use this debit card for debit-card transactions in your customer portal.</p>
    </div>`
  });

  return {
    deliveryMode: "live",
    message: `Debit card approval email sent to ${destination}.`
  };
}

async function sendLoanApprovalEmail({
  destination,
  customerName,
  loanType,
  principalAmount,
  tenureMonths,
  annualInterestRate,
  emiAmount,
  totalPayableAmount,
  nextDueDate
}) {
  const config = getMessagingConfig();

  if (config.otpMode !== "live") {
    return {
      deliveryMode: "demo",
      message: `Loan approval email prepared for ${destination} in demo mode.`
    };
  }

  await ensureEmailConfig(config);
  const transporter = createTransporter(config);

  await transporter.sendMail({
    from: config.emailFrom || config.smtpUser,
    to: destination,
    subject: "Veeraops Bank Loan Approved",
    text:
      `Dear ${customerName}, your ${loanType} loan has been approved.\n` +
      `Principal Amount: ${principalAmount}\n` +
      `Tenure: ${tenureMonths} months\n` +
      `Annual Interest Rate: ${annualInterestRate}%\n` +
      `Monthly EMI: ${emiAmount}\n` +
      `Total Payable Amount: ${totalPayableAmount}\n` +
      `Next Due Date: ${nextDueDate}\n`,
    html: `<div style="font-family:Segoe UI,Tahoma,sans-serif;line-height:1.6;color:#1a2a3d">
      <h2 style="margin-bottom:8px">Veeraops Bank Loan Approved</h2>
      <p>Dear <strong>${escapeHtml(customerName)}</strong>, your <strong>${escapeHtml(
        loanType
      )}</strong> loan request has been approved.</p>
      <div style="padding:16px 18px;border-radius:16px;background:#f4f9fc;border:1px solid #d7e6ee">
        <p style="margin:0 0 8px"><strong>Principal Amount:</strong> ${escapeHtml(
          principalAmount
        )}</p>
        <p style="margin:0 0 8px"><strong>Tenure:</strong> ${escapeHtml(tenureMonths)} months</p>
        <p style="margin:0 0 8px"><strong>Annual Interest Rate:</strong> ${escapeHtml(
          annualInterestRate
        )}%</p>
        <p style="margin:0 0 8px"><strong>Monthly EMI:</strong> ${escapeHtml(emiAmount)}</p>
        <p style="margin:0 0 8px"><strong>Total Payable:</strong> ${escapeHtml(
          totalPayableAmount
        )}</p>
        <p style="margin:0"><strong>Next Due Date:</strong> ${escapeHtml(nextDueDate)}</p>
      </div>
      <p style="margin-top:16px">You can now view this loan and pay EMIs from your customer portal.</p>
    </div>`
  });

  return {
    deliveryMode: "live",
    message: `Loan approval email sent to ${destination}.`
  };
}

async function sendLoanReminderEmail({
  destination,
  customerName,
  loanType,
  emiAmount,
  outstandingAmount,
  nextDueDate
}) {
  const config = getMessagingConfig();

  if (config.otpMode !== "live") {
    return {
      deliveryMode: "demo",
      message: `Loan reminder email prepared for ${destination} in demo mode.`
    };
  }

  await ensureEmailConfig(config);
  const transporter = createTransporter(config);

  await transporter.sendMail({
    from: config.emailFrom || config.smtpUser,
    to: destination,
    subject: "Veeraops Bank Loan Payment Reminder",
    text:
      `Dear ${customerName}, this is a reminder for your ${loanType} loan.\n` +
      `Next Due Date: ${nextDueDate}\n` +
      `EMI Amount: ${emiAmount}\n` +
      `Outstanding Amount: ${outstandingAmount}\n`,
    html: `<div style="font-family:Segoe UI,Tahoma,sans-serif;line-height:1.6;color:#1a2a3d">
      <h2 style="margin-bottom:8px">Loan Payment Reminder</h2>
      <p>Dear <strong>${escapeHtml(customerName)}</strong>, this is a reminder for your <strong>${escapeHtml(
        loanType
      )}</strong> loan payment.</p>
      <div style="padding:16px 18px;border-radius:16px;background:#fff8ec;border:1px solid #f1d7ab">
        <p style="margin:0 0 8px"><strong>Next Due Date:</strong> ${escapeHtml(nextDueDate)}</p>
        <p style="margin:0 0 8px"><strong>EMI Amount:</strong> ${escapeHtml(emiAmount)}</p>
        <p style="margin:0"><strong>Outstanding Amount:</strong> ${escapeHtml(outstandingAmount)}</p>
      </div>
      <p style="margin-top:16px">Please make your EMI payment before the due date to keep your loan healthy.</p>
    </div>`
  });

  return {
    deliveryMode: "live",
    message: `Loan reminder email sent to ${destination}.`
  };
}

async function sendAccountActivityEmail({
  destination,
  customerName,
  activityTitle,
  accountNumber,
  amount,
  direction,
  referenceCode,
  description,
  runningBalance,
  activityTime
}) {
  const config = getMessagingConfig();

  if (config.otpMode !== "live") {
    return {
      deliveryMode: "demo",
      message: `Account activity email prepared for ${destination} in demo mode.`
    };
  }

  await ensureEmailConfig(config);
  const transporter = createTransporter(config);
  const safeDirection = direction ? String(direction).toUpperCase() : "INFO";

  await transporter.sendMail({
    from: config.emailFrom || config.smtpUser,
    to: destination,
    subject: `Veeraops Bank ${activityTitle}`,
    text:
      `Dear ${customerName}, activity has occurred on your Veeraops Bank account.\n` +
      `Activity: ${activityTitle}\n` +
      `Account: ${accountNumber}\n` +
      `Type: ${safeDirection}\n` +
      `Amount: ${amount || "-"}\n` +
      `Reference: ${referenceCode || "-"}\n` +
      `Description: ${description || "-"}\n` +
      `Available Balance: ${runningBalance || "-"}\n` +
      `Time: ${activityTime || new Date().toLocaleString("en-IN")}\n`,
    html: `<div style="font-family:Segoe UI,Tahoma,sans-serif;line-height:1.6;color:#1a2a3d">
      <h2 style="margin-bottom:8px">Veeraops Bank ${escapeHtml(activityTitle)}</h2>
      <p>Dear <strong>${escapeHtml(customerName)}</strong>, an activity has occurred on your account.</p>
      <div style="padding:16px 18px;border-radius:16px;background:#f4f9fc;border:1px solid #d7e6ee">
        <p style="margin:0 0 8px"><strong>Account:</strong> ${escapeHtml(accountNumber || "-")}</p>
        <p style="margin:0 0 8px"><strong>Type:</strong> ${escapeHtml(safeDirection)}</p>
        <p style="margin:0 0 8px"><strong>Amount:</strong> ${escapeHtml(amount || "-")}</p>
        <p style="margin:0 0 8px"><strong>Reference:</strong> ${escapeHtml(referenceCode || "-")}</p>
        <p style="margin:0 0 8px"><strong>Description:</strong> ${escapeHtml(description || "-")}</p>
        <p style="margin:0 0 8px"><strong>Available Balance:</strong> ${escapeHtml(
          runningBalance || "-"
        )}</p>
        <p style="margin:0"><strong>Time:</strong> ${escapeHtml(
          activityTime || new Date().toLocaleString("en-IN")
        )}</p>
      </div>
      <p style="margin-top:16px">If this was not done by you, please contact Veeraops Bank support immediately.</p>
    </div>`
  });

  return {
    deliveryMode: "live",
    message: `Account activity email sent to ${destination}.`
  };
}

async function ensureEmailConfig(config) {
  if (!config.smtpUser || !config.smtpPass) {
    throw new Error(
      "MAIL_USERNAME and MAIL_PASSWORD or SMTP_USER and SMTP_PASS are required for live email OTP delivery"
    );
  }
}

function createTransporter(config) {
  const nodemailer = require("nodemailer");
  const transportOptions = config.smtpService
    ? {
        service: config.smtpService,
        auth: {
          user: config.smtpUser,
          pass: config.smtpPass
        }
      }
    : {
        host: config.smtpHost,
        port: config.smtpPort,
        secure: config.smtpSecure,
        auth: {
          user: config.smtpUser,
          pass: config.smtpPass
        }
      };

  return nodemailer.createTransport(transportOptions);
}

function escapeHtml(value) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

module.exports = {
  getMessagingConfig,
  sendApprovalEmail,
  sendAccountActivityEmail,
  sendDebitCardApprovalEmail,
  sendLoanApprovalEmail,
  sendLoanReminderEmail,
  sendOtpMessage
};
