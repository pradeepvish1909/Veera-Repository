CREATE DATABASE IF NOT EXISTS banking_portal;
USE banking_portal;

CREATE TABLE IF NOT EXISTS employees (
  id INT AUTO_INCREMENT PRIMARY KEY,
  employee_code VARCHAR(30) NOT NULL UNIQUE,
  full_name VARCHAR(140) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password VARCHAR(120) NOT NULL,
  role VARCHAR(60) NOT NULL DEFAULT 'operations',
  branch VARCHAR(120) DEFAULT 'Bengaluru Central',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS branches (
  id INT AUTO_INCREMENT PRIMARY KEY,
  branch_name VARCHAR(120) NOT NULL UNIQUE,
  city VARCHAR(80) NOT NULL,
  state_name VARCHAR(80) NOT NULL,
  ifsc_code VARCHAR(20) NOT NULL UNIQUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS bank_services (
  id INT AUTO_INCREMENT PRIMARY KEY,
  service_code VARCHAR(80) NOT NULL UNIQUE,
  category VARCHAR(80) NOT NULL,
  service_name VARCHAR(140) NOT NULL,
  short_description VARCHAR(255) NOT NULL,
  detail TEXT NOT NULL,
  eligibility VARCHAR(255) DEFAULT NULL,
  required_documents VARCHAR(255) DEFAULT NULL,
  fee_label VARCHAR(120) DEFAULT 'As per bank policy',
  processing_time VARCHAR(80) DEFAULT 'Instant to 2 working days',
  channels VARCHAR(160) DEFAULT 'Online, branch, mobile banking',
  status VARCHAR(30) NOT NULL DEFAULT 'available',
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS customers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  customer_number VARCHAR(30) NOT NULL UNIQUE,
  full_name VARCHAR(140) NOT NULL,
  email VARCHAR(190) DEFAULT NULL UNIQUE,
  password VARCHAR(120) NOT NULL,
  phone VARCHAR(40) DEFAULT NULL,
  city VARCHAR(80) DEFAULT NULL,
  approval_status VARCHAR(20) NOT NULL DEFAULT 'pending',
  requested_account_type VARCHAR(40) NOT NULL DEFAULT 'savings',
  requested_branch VARCHAR(120) DEFAULT 'Bengaluru Central',
  employment_status VARCHAR(80) DEFAULT NULL,
  employer_name VARCHAR(140) DEFAULT NULL,
  monthly_income DECIMAL(12, 2) DEFAULT NULL,
  business_name VARCHAR(140) DEFAULT NULL,
  business_address VARCHAR(255) DEFAULT NULL,
  rejection_reason VARCHAR(255) DEFAULT NULL,
  approved_at TIMESTAMP NULL DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS accounts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  customer_id INT NOT NULL,
  account_number VARCHAR(30) NOT NULL UNIQUE,
  account_type VARCHAR(40) NOT NULL DEFAULT 'savings',
  balance DECIMAL(12, 2) NOT NULL DEFAULT 0,
  status VARCHAR(30) NOT NULL DEFAULT 'active',
  branch VARCHAR(120) DEFAULT 'Bengaluru Central',
  ifsc_code VARCHAR(20) DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_accounts_customer
    FOREIGN KEY (customer_id) REFERENCES customers(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS cards (
  id INT AUTO_INCREMENT PRIMARY KEY,
  customer_id INT NOT NULL,
  account_id INT NOT NULL,
  card_type VARCHAR(30) NOT NULL,
  provider VARCHAR(30) NOT NULL DEFAULT 'Visa',
  card_number VARCHAR(30) NOT NULL UNIQUE,
  status VARCHAR(30) NOT NULL DEFAULT 'active',
  approval_status VARCHAR(20) NOT NULL DEFAULT 'approved',
  rejection_reason VARCHAR(255) DEFAULT NULL,
  approved_at TIMESTAMP NULL DEFAULT NULL,
  pin_code VARCHAR(10) DEFAULT NULL,
  pin_set_at TIMESTAMP NULL DEFAULT NULL,
  credit_limit DECIMAL(12, 2) NOT NULL DEFAULT 0,
  available_limit DECIMAL(12, 2) NOT NULL DEFAULT 0,
  expiry_label VARCHAR(10) DEFAULT '12/29',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_cards_customer
    FOREIGN KEY (customer_id) REFERENCES customers(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT fk_cards_account
    FOREIGN KEY (account_id) REFERENCES accounts(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS transactions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  account_id INT NOT NULL,
  customer_id INT NOT NULL,
  reference_code VARCHAR(40) NOT NULL UNIQUE,
  transaction_type VARCHAR(30) NOT NULL,
  channel VARCHAR(40) NOT NULL DEFAULT 'online',
  amount DECIMAL(12, 2) NOT NULL,
  direction VARCHAR(10) NOT NULL,
  description VARCHAR(255) NOT NULL,
  recipient_account_number VARCHAR(30) DEFAULT NULL,
  recipient_bank_name VARCHAR(120) DEFAULT NULL,
  recipient_ifsc VARCHAR(20) DEFAULT NULL,
  transfer_mode VARCHAR(20) DEFAULT NULL,
  running_balance DECIMAL(12, 2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_transactions_account
    FOREIGN KEY (account_id) REFERENCES accounts(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT fk_transactions_customer
    FOREIGN KEY (customer_id) REFERENCES customers(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS bill_payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  customer_id INT NOT NULL,
  account_id INT NOT NULL,
  transaction_id INT NOT NULL,
  bill_category VARCHAR(60) NOT NULL,
  biller_name VARCHAR(140) NOT NULL,
  consumer_number VARCHAR(80) NOT NULL,
  amount DECIMAL(12, 2) NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'paid',
  reference_code VARCHAR(40) NOT NULL UNIQUE,
  paid_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_bill_payments_customer
    FOREIGN KEY (customer_id) REFERENCES customers(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT fk_bill_payments_account
    FOREIGN KEY (account_id) REFERENCES accounts(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT fk_bill_payments_transaction
    FOREIGN KEY (transaction_id) REFERENCES transactions(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS fixed_deposits (
  id INT AUTO_INCREMENT PRIMARY KEY,
  customer_id INT NOT NULL,
  account_id INT NOT NULL,
  transaction_id INT NOT NULL,
  deposit_number VARCHAR(40) NOT NULL UNIQUE,
  principal_amount DECIMAL(12, 2) NOT NULL,
  tenure_months INT NOT NULL,
  annual_interest_rate DECIMAL(6, 2) NOT NULL,
  maturity_amount DECIMAL(12, 2) NOT NULL,
  maturity_date DATE NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_fixed_deposits_customer
    FOREIGN KEY (customer_id) REFERENCES customers(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT fk_fixed_deposits_account
    FOREIGN KEY (account_id) REFERENCES accounts(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT fk_fixed_deposits_transaction
    FOREIGN KEY (transaction_id) REFERENCES transactions(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS cheque_book_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  customer_id INT NOT NULL,
  account_id INT NOT NULL,
  request_number VARCHAR(40) NOT NULL UNIQUE,
  leaf_count INT NOT NULL DEFAULT 25,
  delivery_address VARCHAR(255) NOT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'requested',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_cheque_book_requests_customer
    FOREIGN KEY (customer_id) REFERENCES customers(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT fk_cheque_book_requests_account
    FOREIGN KEY (account_id) REFERENCES accounts(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS loans (
  id INT AUTO_INCREMENT PRIMARY KEY,
  customer_id INT NOT NULL,
  loan_type VARCHAR(40) NOT NULL,
  purpose VARCHAR(255) DEFAULT NULL,
  principal_amount DECIMAL(12, 2) NOT NULL,
  tenure_months INT NOT NULL DEFAULT 12,
  annual_interest_rate DECIMAL(6, 2) NOT NULL DEFAULT 12.50,
  total_payable_amount DECIMAL(12, 2) NOT NULL DEFAULT 0,
  outstanding_amount DECIMAL(12, 2) NOT NULL,
  emi_amount DECIMAL(12, 2) NOT NULL,
  approval_status VARCHAR(20) NOT NULL DEFAULT 'pending',
  rejection_reason VARCHAR(255) DEFAULT NULL,
  approved_at TIMESTAMP NULL DEFAULT NULL,
  next_due_date DATE DEFAULT NULL,
  last_payment_at TIMESTAMP NULL DEFAULT NULL,
  reminder_sent_at TIMESTAMP NULL DEFAULT NULL,
  status VARCHAR(30) NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_loans_customer
    FOREIGN KEY (customer_id) REFERENCES customers(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);

CREATE INDEX idx_accounts_customer_id ON accounts(customer_id);
CREATE INDEX idx_cards_customer_id ON cards(customer_id);
CREATE INDEX idx_cards_account_id ON cards(account_id);
CREATE INDEX idx_transactions_account_id ON transactions(account_id);
CREATE INDEX idx_transactions_customer_id ON transactions(customer_id);
CREATE INDEX idx_bill_payments_customer_id ON bill_payments(customer_id);
CREATE INDEX idx_bill_payments_account_id ON bill_payments(account_id);
CREATE INDEX idx_fixed_deposits_customer_id ON fixed_deposits(customer_id);
CREATE INDEX idx_fixed_deposits_account_id ON fixed_deposits(account_id);
CREATE INDEX idx_cheque_book_requests_customer_id ON cheque_book_requests(customer_id);
CREATE INDEX idx_cheque_book_requests_account_id ON cheque_book_requests(account_id);
CREATE INDEX idx_loans_customer_id ON loans(customer_id);
CREATE INDEX idx_bank_services_category ON bank_services(category);
CREATE INDEX idx_bank_services_sort_order ON bank_services(sort_order);
