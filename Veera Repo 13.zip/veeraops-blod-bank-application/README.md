# VeeraOps Blod Link

BloodLink is a blood bank coordination application for donor registration, urgent blood requests, matching donors, live WebSocket alerts, and Gmail SMTP email communication.


## Features

- Donor registration and login with JWT authentication
- Donor dashboard with profile, donation history, and availability toggle
- Blood request creation with urgency, location, patient, and contact details
- Matching donors by blood group and city
- Real-time donor alerts over WebSocket
- Email alerts using Gmail SMTP and App Passwords
- Request management: open, fulfilled, cancelled, and deleted

## 1. Backend Deployment Process On AWS

Backend deployment includes two parts:

1. Create Amazon RDS MySQL.
2. Deploy the Node.js backend on an Amazon Linux 2 EC2 server.

### 1.1 Create Amazon RDS MySQL

1. Open AWS RDS.
2. Create a MySQL database.
3. Database name: `bloodlink`
4. Save:
   - RDS endpoint
   - username
   - password
   - port `3306`

Recommended RDS security:

- Do not open RDS to the full internet.
- RDS inbound rule should allow MySQL `3306` only from the backend EC2 security group.
- Enable automated backups.


### 1.2 Deploy Backend On Amazon Linux 2 EC2

Launch one EC2 instance for backend:

- AMI: Amazon Linux 2
- Instance type: `t2.micro` or higher
- Security group inbound:
  - SSH `22` from your IP
  - Backend `8000` from frontend server or public internet
  - Optional HTTP `80` and HTTPS `443` if using Nginx

Connect:

```bash
ssh -i your-key.pem ec2-user@BACKEND_PUBLIC_IP
```

Install Node.js, Git, PM2, and MySQL client:

```bash
sudo yum update -y
sudo yum install -y git mariadb105-server
sudo dnf install -y nodejs
sudo npm install -g pm2
```

Clone and install backend:

```bash
git clone YOUR_REPO_URL bloodlink
cd bloodlink/backend
npm install --omit=dev
```

Create backend `.env`:

```bash
vi .env
```

Example production backend `.env`:

```env
PORT=8000
DB_HOST=your-rds-endpoint.region.rds.amazonaws.com
DB_PORT=3306
DB_USER=admin
DB_PASSWORD=your_rds_password
DB_NAME=bloodlink

JWT_SECRET=use_a_long_random_secret
JWT_EXPIRES=7d

MAIL_ENABLED=true
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_SECURE=false
SMTP_USER=yourgmail@gmail.com
SMTP_PASS=your-gmail-app-password
MAIL_FROM=yourgmail@gmail.com
```
Run schema on RDS from backend server :

```bash
mysql -h your-rds-endpoint.region.rds.amazonaws.com -P 3306 -u admin -p bloodlink < test.sql
```

Start backend with PM2:

```bash
pm2 start src/server.js --name bloodlink-backend
pm2 save
pm2 startup
```

Check backend:

```bash
curl http://localhost:8000/health
curl http://BACKEND_PUBLIC_IP:8000/health
```


## 2. Frontend Deployment Process On AWS

Launch a separate EC2 instance for frontend:

- AMI: Amazon Linux 2
- Security group inbound:
  - SSH `22` from your IP
  - HTTP `80` from public internet
  - Optional HTTPS `443`

Connect:

```bash
ssh -i your-key.pem ec2-user@FRONTEND_PUBLIC_IP
```

Install Node.js, Git, and Nginx:

```bash
sudo yum update -y
sudo yum install -y  git nginx
sudo dnf install -y nodejs
```

Clone and build frontend:

```bash
git clone YOUR_REPO_URL bloodlink
cd bloodlink/frontend
npm install
```

For backend by public IP: change on vite config.js

```env
VITE_API_URL=http://BACKEND_PUBLIC_IP:8000/api
VITE_WS_URL=ws://BACKEND_PUBLIC_IP:8000/ws/donor
```

Build:

```bash
npm run build
```

Deploy static files to Nginx:

```bash
sudo systemctl start nginx
sudo rm -rf /usr/share/nginx/html/*
sudo cp -r dist/* /usr/share/nginx/html/
sudo systemctl enable nginx
sudo systemctl restart nginx
```

Open:

```text
http://FRONTEND_PUBLIC_IP
```

## 4. Gmail SMTP Notes

For Gmail email sending:

1. Enable 2-step verification in Google account.
2. Create a Gmail App Password.
3. Use the app password in `SMTP_PASS`.
4. Use port `587` with `SMTP_SECURE=false`.
5. Restart backend after changing `.env`.

