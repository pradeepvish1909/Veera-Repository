import { useEffect, useState } from "react";
import { deleteBloodRequest, getMyRequests, updateBloodRequestStatus } from "../services/api";
import "./MyRequests.css";

export default function MyRequests() {
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [busyId, setBusyId] = useState(null);

  useEffect(() => {
    let active = true;

    const load = async () => {
      try {
        const res = await getMyRequests();
        if (active) setRequests(res.data || []);
      } catch (err) {
        if (active) setError(err.message || "Could not load your requests.");
      } finally {
        if (active) setLoading(false);
      }
    };

    load();
    return () => {
      active = false;
    };
  }, []);

  const updateStatus = async (requestId, status) => {
    setBusyId(requestId);
    setError("");
    try {
      const res = await updateBloodRequestStatus(requestId, status);
      setRequests((prev) =>
        prev.map((request) =>
          request.id === requestId
            ? {
                ...request,
                ...res.data,
                response_count: request.response_count,
                accepted_count: request.accepted_count,
              }
            : request
        )
      );
    } catch (err) {
      setError(err.message || "Could not update request.");
    } finally {
      setBusyId(null);
    }
  };

  const removeRequest = async (requestId) => {
    const ok = window.confirm("Delete this blood request permanently?");
    if (!ok) return;

    setBusyId(requestId);
    setError("");
    try {
      await deleteBloodRequest(requestId);
      setRequests((prev) => prev.filter((request) => request.id !== requestId));
    } catch (err) {
      setError(err.message || "Could not delete request.");
    } finally {
      setBusyId(null);
    }
  };

  return (
    <main className="page-wide">
      <header className="my-requests__header">
        <p className="section-title">My Requests</p>
        <h1 className="my-requests__title">Track every blood request you created.</h1>
      </header>

      {loading ? (
        <div className="card">Loading your requests...</div>
      ) : error ? (
        <div className="form-error">{error}</div>
      ) : requests.length === 0 ? (
        <div className="card">You have not created any blood requests yet.</div>
      ) : (
        <div className="my-requests__grid">
          {requests.map((request) => (
            <article
              key={request.id}
              className={`card my-request-card ${
                request.status === "fulfilled"
                  ? "card--mint"
                  : request.urgency === "critical"
                    ? "card--rose"
                    : request.urgency === "urgent"
                      ? "card--gold"
                      : "card--blue"
              }`}
            >
              <p className="section-title">{request.blood_group} Request</p>
              <h2>{request.hospital || request.city || "Blood Request"}</h2>
              <p className="text-muted">
                {request.city || "Unknown city"} | {request.urgency}
              </p>
              <p className="my-request-card__date text-muted">
                Created{" "}
                {new Date(request.created_at).toLocaleDateString("en-IN", {
                  day: "numeric",
                  month: "short",
                  year: "numeric",
                })}
              </p>

              <div className="my-request-card__details">
                <div className="my-request-card__detail">
                  <span className="my-request-card__label">Patient Name</span>
                  <span>{request.patient_name || "Not provided"}</span>
                </div>
                <div className="my-request-card__detail">
                  <span className="my-request-card__label">Contact Person</span>
                  <span>{request.contact_name || "Not provided"}</span>
                </div>
                <div className="my-request-card__detail">
                  <span className="my-request-card__label">Contact Number</span>
                  <span>{request.contact_phone || "Not provided"}</span>
                </div>
                <div className="my-request-card__detail">
                  <span className="my-request-card__label">Hospital</span>
                  <span>{request.hospital || "Not provided"}</span>
                </div>
                <div className="my-request-card__detail">
                  <span className="my-request-card__label">City</span>
                  <span>{request.city || "Not provided"}</span>
                </div>
                <div className="my-request-card__detail">
                  <span className="my-request-card__label">Request ID</span>
                  <span>#{request.id}</span>
                </div>
              </div>

              <div className="my-request-card__stats">
                <span>Units: {request.units}</span>
                <span>Responses: {request.response_count}</span>
                <span>Accepted: {request.accepted_count}</span>
                <span>Status: {request.status}</span>
              </div>
              <div className="my-request-card__actions">
                {request.status === "open" && (
                  <>
                    <button
                      className="btn btn-primary"
                      type="button"
                      disabled={busyId === request.id}
                      onClick={() => updateStatus(request.id, "fulfilled")}
                    >
                      Mark Fulfilled
                    </button>
                    <button
                      className="btn btn-ghost"
                      type="button"
                      disabled={busyId === request.id}
                      onClick={() => updateStatus(request.id, "cancelled")}
                    >
                      Turn Off
                    </button>
                  </>
                )}
                {request.status !== "open" && (
                  <button
                    className="btn btn-ghost"
                    type="button"
                    disabled={busyId === request.id}
                    onClick={() => removeRequest(request.id)}
                  >
                    Delete
                  </button>
                )}
              </div>
              {request.notes && (
                <div className="my-request-card__notes">
                  <span className="my-request-card__label">Notes</span>
                  <p className="text-muted">{request.notes}</p>
                </div>
              )}
            </article>
          ))}
        </div>
      )}
    </main>
  );
}
