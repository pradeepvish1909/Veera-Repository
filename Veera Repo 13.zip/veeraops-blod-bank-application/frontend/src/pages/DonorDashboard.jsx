import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { updateDonorAvailability, getDonorProfile, getDonorDonationHistory, getDonorStats, getMe } from "../services/api";
import { connectSocket, offEvent, emitDonorResponse } from "../services/socket";
import "./DonorDashboard.css";

export default function DonorDashboard() {
  const navigate = useNavigate();
  const [donorId, setDonorId] = useState(() => {
    const storedId = Number(localStorage.getItem("donorId"));
    return Number.isFinite(storedId) && storedId > 0 ? storedId : null;
  });
  const [donor, setDonor]         = useState(null);
  const [history, setHistory]     = useState([]);
  const [requests, setRequests]   = useState([]); // live incoming requests
  const [loading, setLoading]     = useState(true);
  const [error, setError]         = useState("");
  const [toggling, setToggling]   = useState(false);
  const [stats, setStats]         = useState({ totalDonors: 0, availableGroups: [] });

  // ── Load mock donor data (backend endpoints not implemented) ───────────────
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) {
      navigate("/login", { replace: true });
      return;
    }

    let alive = true;
    const load = async () => {
      try {
        let activeId = donorId;
        if (!activeId) {
          const meRes = await getMe();
          activeId = meRes.data?.donor?.id;
          if (activeId) {
            localStorage.setItem("donorId", String(activeId));
            if (alive) setDonorId(activeId);
          }
        }

        if (!activeId) throw new Error("Missing donor profile");

        const [profileRes, historyRes, statsRes] = await Promise.all([
          getDonorProfile(activeId),
          getDonorDonationHistory(activeId),
          getDonorStats(),
        ]);
        if (!alive) return;
        setDonor(profileRes.data);
        setHistory(historyRes.data || []);
        setStats(statsRes.data || { totalDonors: 0, availableGroups: [] });
      } catch (err) {
        if (!alive) return;
        setError(err.message || "Could not load donor data");
      } finally {
        if (alive) setLoading(false);
      }
    };
    load();
    return () => {
      alive = false;
    };
  }, [donorId, navigate]);

  // ── Live socket for incoming requests ─────────────────────────────────────
  useEffect(() => {
    if (!donorId) return;
    const socket = connectSocket(donorId);

    const handleRequest = (data) => {
      setRequests((prev) => [{ ...data, id: `${data.requestId}-${Date.now()}` }, ...prev].slice(0, 10));
    };

    socket.on("blood_request", handleRequest);
    return () => offEvent("blood_request", handleRequest);
  }, []);

  // ── Toggle availability ────────────────────────────────────────────────────
  const toggleAvailability = async () => {
    if (!donor) return;
    setToggling(true);
    try {
      await updateDonorAvailability(donor._id, !donor.available);
      setDonor((d) => ({ ...d, available: !d.available }));
    } catch (err) {
      setError(err.message || "Could not update availability");
    } finally {
      setToggling(false);
    }
  };

  // ── Respond to request ─────────────────────────────────────────────────────
  const respondToRequest = (request) => {
    emitDonorResponse({ requestId: request.requestId, donorId, accept: request.accept });
    setRequests((prev) => prev.filter((r) => r.id !== request.id));
  };

  // ── Render ─────────────────────────────────────────────────────────────────
  if (loading) {
    return (
      <main className="page">
        <div className="dash-loading">
          <span className="spinner-lg" aria-label="Loading" />
          <p className="text-muted">Loading dashboard…</p>
        </div>
      </main>
    );
  }

  return (
    <main className="page-wide">
      <header className="dash-header">
        <p className="section-title">Donor Dashboard</p>
        <div className="dash-header__row">
          <h1 className="dash-title">
            Welcome,<br />
            <span className="dash-name">{donor?.name ?? "—"}</span>
          </h1>
          <div className="dash-badge">
            <span className="dash-blood-group">{donor?.bloodGroup}</span>
          </div>
        </div>
      </header>

      {error && (
        <div className="dash-notice">
          Could not reach server — showing cached data.
        </div>
      )}

      {/* Summary */}
      <div className="dash-summary card">
        <div className="dash-summary__item">
          <p className="section-title">Total Registered Donors</p>
          <p className="stat-value">{stats.totalDonors}</p>
        </div>
        <div className="dash-summary__item">
          <p className="section-title">Available Blood Groups</p>
          {stats.availableGroups.length === 0 ? (
            <p className="text-muted" style={{ fontSize: "0.85rem" }}>No available donors yet.</p>
          ) : (
            <div className="dash-groups">
              {stats.availableGroups.map((g) => (
                <span key={g.bloodGroup} className="dash-group-pill">
                  {g.bloodGroup} · {g.count}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Stats row */}
      <div className="dash-stats">
        {[
          { label: "Total Donations",  value: donor?.totalDonations ?? 0 },
          { label: "Lives Impacted",   value: (donor?.totalDonations ?? 0) * 3 },
          { label: "City",             value: donor?.city ?? "—" },
          { label: "Last Donated",     value: donor?.lastDonated ? new Date(donor.lastDonated).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }) : "—" },
        ].map(({ label, value }) => (
          <div
            key={label}
            className={`stat-card card ${
              label === "Total Donations"
                ? "card--rose"
                : label === "Lives Impacted"
                  ? "card--mint"
                  : label === "City"
                    ? "card--blue"
                    : "card--gold"
            }`}
          >
            <p className="stat-label section-title">{label}</p>
            <p className="stat-value">{value}</p>
          </div>
        ))}
      </div>

      <div className="dash-grid">
        {/* Left column */}
        <div className="dash-col">
          {/* Availability toggle */}
          <div className="card card--mint avail-card">
            <p className="section-title">Availability</p>
            <div className="avail-row">
              <div>
                <p className="avail-status">
                  {donor?.available ? (
                    <><span className="dot dot--green" /> Available to donate</>
                  ) : (
                    <><span className="dot dot--red" /> Currently unavailable</>
                  )}
                </p>
                <p className="text-muted avail-hint" style={{ fontSize: "0.78rem", marginTop: 4 }}>
                  Toggle to let requesters know if you can donate.
                </p>
              </div>
              <button
                className={`toggle-btn ${donor?.available ? "toggle-btn--on" : ""}`}
                onClick={toggleAvailability}
                disabled={toggling}
                aria-label="Toggle availability"
              >
                <span className="toggle-knob" />
              </button>
            </div>
          </div>

          {/* Donation history */}
          <div className="card card--gold mt-3">
            <p className="section-title">Donation History</p>
            {history.length === 0 ? (
              <p className="text-muted" style={{ fontSize: "0.85rem", marginTop: "0.8rem" }}>
                No donations recorded yet.
              </p>
            ) : (
              <ul className="history-list">
                {history.map((d) => (
                  <li key={d._id} className="history-item">
                    <div className="history-date">
                      {new Date(d.date).toLocaleDateString("en-IN", {
                        day: "numeric", month: "short", year: "numeric",
                      })}
                    </div>
                    <div className="history-info">
                      <span className="history-hospital">{d.hospital}</span>
                      <span className="history-units text-muted">
                        {d.units} unit{d.units > 1 ? "s" : ""}
                      </span>
                    </div>
                    <span className="history-tag">Donated</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>

        {/* Right column — live requests */}
        <div className="dash-col">
          <div className="card card--lilac live-card">
            <div className="live-header">
              <p className="section-title">Live Requests</p>
              {requests.length > 0 && (
                <span className="live-badge">{requests.length}</span>
              )}
            </div>
            <p className="text-muted live-sub">
              Incoming requests compatible with your blood group.
            </p>
            {requests.length === 0 ? (
              <div className="live-empty">
                <span className="live-pulse" aria-hidden="true" />
                <p>Listening for requests…</p>
              </div>
            ) : (
              <ul className="live-list">
                {requests.map((req) => (
                  <li key={req.id} className="live-item">
                    <div className="live-item__top">
                      <span className="live-item__group">{req.bloodGroup}</span>
                      <span className="live-item__urgency live-item__urgency--urgent">
                        {req.urgency ?? "urgent"}
                      </span>
                    </div>
                    <p className="live-item__hospital">
                      {req.hospital}, {req.city}
                    </p>
                    {req.notes && (
                      <p className="live-item__notes text-muted">{req.notes}</p>
                    )}
                    {(req.contact_name || req.contact_phone) && (
                      <p className="live-item__notes text-muted">
                        Contact: {req.contact_name || "Requester"}
                        {req.contact_phone ? ` - ${req.contact_phone}` : ""}
                      </p>
                    )}
                    <div className="live-item__actions">
                      {req.contact_phone && (
                        <a className="btn btn-ghost" href={`tel:${req.contact_phone}`}>
                          Call
                        </a>
                      )}
                      <button
                        className="btn btn-primary"
                        onClick={() => respondToRequest({ ...req, accept: true })}
                      >
                        I can donate
                      </button>
                      <button
                        className="btn btn-ghost"
                        onClick={() => respondToRequest({ ...req, accept: false })}
                      >
                        Skip
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}
