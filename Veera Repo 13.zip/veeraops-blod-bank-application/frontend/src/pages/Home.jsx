import { Link } from "react-router-dom";
import "./Home.css";

const BLOOD_TYPES = ["A+", "B+", "AB+", "O+", "A-", "B-", "AB-", "O-"];

const STATS = [
  { value: "24/7", label: "Emergency alerts" },
  { value: "8", label: "Blood groups" },
  { value: "1", label: "Coordinated workflow" },
];

const FEATURES = [
  {
    title: "Request blood faster",
    description: "Create a complete request with patient, hospital, urgency, and contact details in one focused flow.",
  },
  {
    title: "Reach matching donors",
    description: "Notify compatible donors by city through dashboard alerts and SMTP email communication.",
  },
  {
    title: "Track every response",
    description: "Manage open, fulfilled, cancelled, and deleted requests with clear requester notifications.",
  },
];

const WORKFLOW = [
  "Donor registers with blood group, city, email, and mobile number.",
  "Requester creates an urgent blood request from the application.",
  "Matching donors receive live alerts and full details by email.",
  "Requester follows responses, calls donors, and closes the request.",
];

export default function Home() {
  return (
    <main className="home-page">
      <section className="home-hero">
        <div className="home-nav">
          <Link to="/" className="home-logo">
            <span className="home-logo__mark">BL</span>
            <span>BloodLink</span>
          </Link>
          <div className="home-nav__links">
            <Link to="/login">Login</Link>
            <Link to="/register">Register</Link>
          </div>
        </div>

        <div className="home-hero__content">
          <p className="home-kicker">Multicloud DevOps by Veera Sir Blood Bank</p>
          <h1 className="home-title">Urgent blood requests, coordinated without confusion.</h1>
          <p className="home-sub">
            BloodLink brings donors and requesters into one calm workflow with live alerts,
            direct contact actions, request tracking, and Gmail SMTP updates.
          </p>

          <div className="home-actions">
            <Link to="/register" className="btn btn-primary">
              Register Donor
            </Link>
            <Link to="/login" className="btn btn-ghost">
              Login
            </Link>
          </div>

          <div className="home-blood-row" aria-label="Supported blood groups">
            {BLOOD_TYPES.map((type) => (
              <span key={type}>{type}</span>
            ))}
          </div>
        </div>

        <div className="home-hero__status" aria-label="Platform highlights">
          {STATS.map((stat) => (
            <div key={stat.label}>
              <strong>{stat.value}</strong>
              <span>{stat.label}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="home-section page-wide home-overview">
        <div className="home-section__intro">
          <p className="section-title">Fast Response</p>
          <h2>Built for the moments where every call matters.</h2>
        </div>

        <div className="home-feature-grid">
          {FEATURES.map((feature) => (
            <article key={feature.title} className="home-feature card">
              <h3>{feature.title}</h3>
              <p className="text-muted">{feature.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="home-section page-wide home-workflow">
        <div className="home-workflow__copy">
          <p className="section-title">Workflow</p>
          <h2>From request creation to donor communication.</h2>
          <p className="text-muted">
            The application keeps each step visible, so donors can respond quickly and requesters
            can close or delete requests after the situation is handled.
          </p>
        </div>

        <ol className="home-workflow__list">
          {WORKFLOW.map((item, index) => (
            <li key={item}>
              <span>{String(index + 1).padStart(2, "0")}</span>
              <p>{item}</p>
            </li>
          ))}
        </ol>
      </section>
    </main>
  );
}
