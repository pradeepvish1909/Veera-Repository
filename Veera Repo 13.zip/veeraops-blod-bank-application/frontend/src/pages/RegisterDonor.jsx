import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { registerDonor } from "../services/api";
import { getCitiesForState, INDIA, INDIA_STATES } from "../data/indiaLocations";
import "./RegisterDonor.css";

const BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
const LAST_DONATED_OPTIONS = Array.from({ length: 12 }, (_, index) => {
  const months = index + 1;
  return {
    value: String(months),
    label: `${months} month${months > 1 ? "s" : ""} back`,
  };
});

const INITIAL = {
  name: "",
  age: "",
  gender: "",
  bloodGroup: "",
  country: INDIA,
  state: "",
  phone: "",
  email: "",
  city: "",
  address: "",
  lastDonated: "",
  medicalConditions: "",
  password: "",
  confirmPassword: "",
};

export default function RegisterDonor() {
  const navigate = useNavigate();
  const [form, setForm] = useState(INITIAL);
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState("");
  const [donorId, setDonorId] = useState(null);

  const set = (field) => (e) =>
    setForm((prev) => ({ ...prev, [field]: e.target.value }));

  const handleStateChange = (e) => {
    const nextState = e.target.value;
    setForm((prev) => ({
      ...prev,
      state: nextState,
      city: "",
    }));
  };

  const cityOptions = getCitiesForState(form.state);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus("loading");
    setError("");

    try {
      if (!String(form.phone || "").trim() && !String(form.email || "").trim()) {
        setError("Enter at least an email address or mobile number.");
        setStatus("error");
        return;
      }

      if (form.password !== form.confirmPassword) {
        setError("Passwords do not match.");
        setStatus("error");
        return;
      }

      const monthsBack = Number(form.lastDonated);
      const computedLastDonated = monthsBack
        ? new Date(new Date().setMonth(new Date().getMonth() - monthsBack))
            .toISOString()
            .slice(0, 10)
        : "";

      const { confirmPassword, country, state, ...rest } = form;
      const payload = {
        ...rest,
        lastDonated: computedLastDonated,
      };

      const res = await registerDonor(payload);
      const newId = res.data?.donor?._id || res.data?._id || "-";
      const token = res.data?.token;
      if (newId !== "-") localStorage.setItem("donorId", String(newId));
      if (token) localStorage.setItem("token", token);
      setDonorId(newId);
      setStatus("success");
      navigate("/dashboard", { replace: true });
    } catch (err) {
      setError(err.message);
      setStatus("error");
    }
  };

  if (status === "success") {
    return (
      <main className="page">
        <div className="reg-success card card--mint">
          <div className="reg-success__icon">*</div>
          <p className="section-title">Registered</p>
          <h2 className="reg-success__title">You're a lifesaver.</h2>
          <p className="reg-success__sub text-muted">
            Your donor ID has been created. You may receive alerts when compatible
            requests appear in your city.
          </p>
          <div className="reg-success__id">
            <span className="section-title">Donor ID</span>
            <code>{donorId}</code>
          </div>
          <button
            className="btn btn-ghost mt-3"
            onClick={() => {
              setForm(INITIAL);
              setStatus("idle");
              setDonorId(null);
            }}
          >
            Register another donor
          </button>
        </div>
      </main>
    );
  }

  return (
    <main className="page">
      <header className="reg-header">
        <div className="reg-top-actions">
          <Link to="/" className="btn btn-ghost reg-top-link">
            Home
          </Link>
          <Link to="/login" className="btn btn-ghost reg-top-link">
            Login
          </Link>
        </div>
        <p className="section-title">Donor Registration</p>
        <h1 className="reg-title">
          Give Blood.
          <br />
          Save Lives.
        </h1>
        <p className="reg-sub text-muted">
          One unit of blood can save up to three lives. Complete the form below
          to join our donor network.
        </p>
        <p className="reg-contact-note text-muted">
          Use either your email, mobile number, or both for account access.
        </p>
        <p className="reg-contact-note text-muted">
          Location is selected in India-only blocks: country, state, and city.
        </p>
      </header>

      <form className="reg-form card" onSubmit={handleSubmit} noValidate>
        <fieldset className="form-section">
          <legend className="form-legend">Personal Information</legend>
          <div className="form-grid-2">
            <div className="field">
              <label htmlFor="name">Full Name</label>
              <input
                id="name"
                value={form.name}
                onChange={set("name")}
                placeholder="Arjun Sharma"
                required
              />
            </div>
            <div className="field">
              <label htmlFor="age">Age</label>
              <input
                id="age"
                type="number"
                min="18"
                max="65"
                value={form.age}
                onChange={set("age")}
                placeholder="25"
                required
              />
            </div>
            <div className="field">
              <label htmlFor="gender">Gender</label>
              <select id="gender" value={form.gender} onChange={set("gender")} required>
                <option value="">Select</option>
                <option>Male</option>
                <option>Female</option>
                <option>Other</option>
                <option>Prefer not to say</option>
              </select>
            </div>
            <div className="field">
              <label htmlFor="bloodGroup">Blood Group</label>
              <select
                id="bloodGroup"
                value={form.bloodGroup}
                onChange={set("bloodGroup")}
                required
              >
                <option value="">Select</option>
                {BLOOD_GROUPS.map((group) => (
                  <option key={group}>{group}</option>
                ))}
              </select>
            </div>
          </div>
        </fieldset>

        <fieldset className="form-section">
          <legend className="form-legend">Contact Details</legend>
          <div className="form-grid-2">
            <div className="field">
              <label htmlFor="phone">Mobile Number</label>
              <input
                id="phone"
                type="tel"
                value={form.phone}
                onChange={set("phone")}
                placeholder="+91 98765 43210"
              />
            </div>
            <div className="field">
              <label htmlFor="email">Email Address</label>
              <input
                id="email"
                type="email"
                value={form.email}
                onChange={set("email")}
                placeholder="arjun@email.com"
              />
            </div>
            <div className="field">
              <label htmlFor="password">Password</label>
              <input
                id="password"
                type="password"
                value={form.password}
                onChange={set("password")}
                placeholder="Create a password"
                required
              />
            </div>
            <div className="field">
              <label htmlFor="confirmPassword">Confirm Password</label>
              <input
                id="confirmPassword"
                type="password"
                value={form.confirmPassword}
                onChange={set("confirmPassword")}
                placeholder="Re-enter password"
                required
              />
            </div>
            <div className="field">
              <label htmlFor="country">Country</label>
              <select id="country" value={form.country} disabled>
                <option>{INDIA}</option>
              </select>
            </div>
            <div className="field">
              <label htmlFor="state">State</label>
              <select id="state" value={form.state} onChange={handleStateChange} required>
                <option value="">Select State</option>
                {INDIA_STATES.map((stateName) => (
                  <option key={stateName} value={stateName}>
                    {stateName}
                  </option>
                ))}
              </select>
            </div>
            <div className="field">
              <label htmlFor="city">City</label>
              <select
                id="city"
                value={form.city}
                onChange={set("city")}
                disabled={!form.state}
                required
              >
                <option value="">{form.state ? "Select City" : "Select State First"}</option>
                {cityOptions.map((city) => (
                  <option key={city} value={city}>
                    {city}
                  </option>
                ))}
              </select>
            </div>
            <div className="field">
              <label htmlFor="address">Address</label>
              <input
                id="address"
                value={form.address}
                onChange={set("address")}
                placeholder="Banjara Hills, Hyderabad"
              />
            </div>
          </div>
        </fieldset>

        <fieldset className="form-section">
          <legend className="form-legend">Medical History</legend>
          <div className="form-grid-2">
            <div className="field">
              <label htmlFor="lastDonated">Last Donation</label>
              <select id="lastDonated" value={form.lastDonated} onChange={set("lastDonated")}>
                <option value="">Select</option>
                {LAST_DONATED_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div className="field mt-2">
            <label htmlFor="medicalConditions">Known Medical Conditions</label>
            <textarea
              id="medicalConditions"
              rows={3}
              value={form.medicalConditions}
              onChange={set("medicalConditions")}
              placeholder="None / Hypertension / Diabetes ..."
            />
          </div>
        </fieldset>

        {error && (
          <div className="form-error" role="alert">
            {error}
          </div>
        )}

        <button
          type="submit"
          className="btn btn-primary reg-submit"
          disabled={status === "loading"}
        >
          {status === "loading" ? (
            <>
              <span className="spinner" aria-hidden="true" /> Registering...
            </>
          ) : (
            "Register as Donor ->"
          )}
        </button>
      </form>
    </main>
  );
}
