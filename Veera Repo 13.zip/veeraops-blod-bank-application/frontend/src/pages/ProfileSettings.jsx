import { useEffect, useState } from "react";
import { getMe, getDonorProfile, updateDonorProfile } from "../services/api";
import "./ProfileSettings.css";

const INITIAL = {
  name: "",
  age: "",
  gender: "",
  phone: "",
  email: "",
  city: "",
  address: "",
  medicalConditions: "",
};

export default function ProfileSettings() {
  const [donorId, setDonorId] = useState(() => Number(localStorage.getItem("donorId")) || null);
  const [form, setForm] = useState(INITIAL);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");

  const set = (field) => (e) =>
    setForm((prev) => ({ ...prev, [field]: e.target.value }));

  useEffect(() => {
    let active = true;
    const load = async () => {
      try {
        let id = donorId;
        if (!id) {
          const meRes = await getMe();
          id = meRes.data?.donor?.id;
          if (id) {
            localStorage.setItem("donorId", String(id));
            if (active) setDonorId(id);
          }
        }

        if (!id) throw new Error("Missing donor profile");
        const res = await getDonorProfile(id);
        if (!active) return;
        setForm({
          name: res.data?.name || "",
          age: res.data?.age || "",
          gender: res.data?.gender || "",
          phone: res.data?.phone || "",
          email: res.data?.email || "",
          city: res.data?.city || "",
          address: res.data?.address || "",
          medicalConditions: res.data?.medicalConditions || "",
        });
      } catch (err) {
        if (active) setError(err.message || "Could not load profile.");
      } finally {
        if (active) setLoading(false);
      }
    };
    load();
    return () => {
      active = false;
    };
  }, [donorId]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!donorId) return;

    setSaving(true);
    setError("");
    setNotice("");
    try {
      await updateDonorProfile(donorId, form);
      setNotice("Profile updated successfully.");
    } catch (err) {
      setError(err.message || "Could not update profile.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <main className="page">
        <div className="profile-settings card">Loading profile...</div>
      </main>
    );
  }

  return (
    <main className="page">
      <header className="profile-settings__header">
        <p className="section-title">Profile Settings</p>
        <h1 className="profile-settings__title">Keep your donor profile current.</h1>
        <p className="text-muted">
          Update your contact details and medical information so requests reach you correctly.
        </p>
      </header>

      <form className="profile-settings card" onSubmit={handleSubmit}>
        <div className="form-grid-2">
          <div className="field">
            <label htmlFor="name">Full Name</label>
            <input id="name" value={form.name} onChange={set("name")} required />
          </div>
          <div className="field">
            <label htmlFor="age">Age</label>
            <input id="age" type="number" value={form.age} onChange={set("age")} required />
          </div>
          <div className="field">
            <label htmlFor="gender">Gender</label>
            <input id="gender" value={form.gender} onChange={set("gender")} required />
          </div>
          <div className="field">
            <label htmlFor="city">City</label>
            <input id="city" value={form.city} onChange={set("city")} required />
          </div>
          <div className="field">
            <label htmlFor="phone">Phone</label>
            <input id="phone" value={form.phone} onChange={set("phone")} />
          </div>
          <div className="field">
            <label htmlFor="email">Email</label>
            <input id="email" type="email" value={form.email} onChange={set("email")} />
          </div>
        </div>

        <div className="field mt-2">
          <label htmlFor="address">Address</label>
          <input id="address" value={form.address} onChange={set("address")} />
        </div>

        <div className="field mt-2">
          <label htmlFor="medicalConditions">Medical Conditions</label>
          <textarea
            id="medicalConditions"
            rows={4}
            value={form.medicalConditions}
            onChange={set("medicalConditions")}
          />
        </div>

        {error && <div className="form-error">{error}</div>}
        {notice && <div className="profile-settings__notice">{notice}</div>}

        <button className="btn btn-primary profile-settings__submit" disabled={saving}>
          {saving ? "Saving..." : "Save Changes"}
        </button>
      </form>
    </main>
  );
}
