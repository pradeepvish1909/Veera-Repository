import { useState } from "react";
import { createBloodRequest, emailDonorForRequest, getMatchingDonors } from "../services/api";
import { getCitiesForState, INDIA, INDIA_STATES } from "../data/indiaLocations";
import "./RequestBlood.css";

const BLOOD_GROUPS = ["A+", "A−", "B+", "B−", "AB+", "AB−", "O+", "O−"];
const URGENCY_LEVELS = [
  { value: "critical", label: "Critical — within hours" },
  { value: "urgent",   label: "Urgent — within 24 hrs" },
  { value: "normal",   label: "Normal — within a week" },
];

const INITIAL = {
  patientName: "",
  bloodGroup: "",
  units: "1",
  country: INDIA,
  state: "",
  hospital: "",
  city: "",
  contactName: "",
  contactPhone: "",
  urgency: "urgent",
  notes: "",
};

export default function RequestBlood() {
  const [form, setForm]         = useState(INITIAL);
  const [status, setStatus]     = useState("idle");
  const [error, setError]       = useState("");
  const [donors, setDonors]     = useState(null);
  const [requestId, setReqId]   = useState(null);
  const [emailingId, setEmailingId] = useState(null);
  const [emailedIds, setEmailedIds] = useState(() => new Set());

  const set = (f) => (e) => setForm((p) => ({ ...p, [f]: e.target.value }));
  const handleStateChange = (e) => {
    const nextState = e.target.value;
    setForm((prev) => ({
      ...prev,
      state: nextState,
      city: "",
    }));
  };
  const cityOptions = getCitiesForState(form.state);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus("loading");
    setError("");
    setDonors(null);
    setEmailedIds(new Set());

    try {
      const payload = {
        patient_name: form.patientName,
        blood_group: form.bloodGroup,
        units: Number(form.units),
        hospital: form.hospital,
        city: form.city,
        contact_name: form.contactName,
        contact_phone: form.contactPhone,
        urgency: form.urgency,
        notes: form.notes,
      };

      const res = await createBloodRequest(payload);
      const id = res.data?.id;
      setReqId(id);

      // Fetch compatible donors
      const donorRes = await getMatchingDonors(id);
      setDonors(donorRes.data || []);

      setStatus("success");
    } catch (err) {
      setError(err.message);
      setStatus("error");
    }
  };

  const sendDonorEmail = async (donorId) => {
    if (!requestId) return;
    setEmailingId(donorId);
    setError("");
    try {
      await emailDonorForRequest(requestId, donorId);
      setEmailedIds((prev) => new Set([...prev, donorId]));
    } catch (err) {
      setError(err.message || "Could not send email.");
    } finally {
      setEmailingId(null);
    }
  };

  return (
    <main className="page">
      <header className="req-header">
        <p className="section-title">Blood Request</p>
        <h1 className="req-title">Request<br />Blood Now.</h1>
        <p className="req-sub text-muted">
          Fill in the details below. Nearby compatible donors will be notified
          instantly via the real-time alert system.
        </p>
        <p className="req-location-note text-muted">
          Choose location in India by country, state, and city instead of typing it manually.
        </p>
      </header>

      <form className="req-form card" onSubmit={handleSubmit} noValidate>
        <fieldset className="form-section">
          <legend className="form-legend">Patient Details</legend>
          <div className="form-grid-2">
            <div className="field">
              <label htmlFor="patientName">Patient Name</label>
              <input id="patientName" value={form.patientName}
                onChange={set("patientName")} placeholder="Priya Reddy" required />
            </div>
            <div className="field">
              <label htmlFor="bloodGroup">Blood Group Required</label>
              <select id="bloodGroup" value={form.bloodGroup}
                onChange={set("bloodGroup")} required>
                <option value="">Select</option>
                {BLOOD_GROUPS.map((g) => <option key={g}>{g}</option>)}
              </select>
            </div>
            <div className="field">
              <label htmlFor="units">Units Required</label>
              <input id="units" type="number" min="1" max="10"
                value={form.units} onChange={set("units")} required />
            </div>
            <div className="field">
              <label htmlFor="urgency">Urgency Level</label>
              <select id="urgency" value={form.urgency} onChange={set("urgency")}>
                {URGENCY_LEVELS.map(({ value, label }) => (
                  <option key={value} value={value}>{label}</option>
                ))}
              </select>
            </div>
          </div>
        </fieldset>

        <fieldset className="form-section">
          <legend className="form-legend">Hospital / Location</legend>
          <div className="form-grid-2">
            <div className="field">
              <label htmlFor="hospital">Hospital Name</label>
              <input id="hospital" value={form.hospital}
                onChange={set("hospital")} placeholder="AIIMS Hyderabad" required />
            </div>
            <div className="field">
              <label htmlFor="country">Country</label>
              <select id="country" value={form.country} disabled>
                <option>{INDIA}</option>
              </select>
            </div>
            <div className="field">
              <label htmlFor="state">State</label>
              <select id="state" value={form.state} onChange={handleStateChange} required>
                <option value="">Select State</option>
                {INDIA_STATES.map((state) => (
                  <option key={state} value={state}>
                    {state}
                  </option>
                ))}
              </select>
            </div>
            <div className="field">
              <label htmlFor="city">City</label>
              <select
                id="city"
                value={form.city}
                onChange={set("city")}
                disabled={!form.state}
                required
              >
                <option value="">{form.state ? "Select City" : "Select State First"}</option>
                {cityOptions.map((city) => (
                  <option key={city} value={city}>
                    {city}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </fieldset>

        <fieldset className="form-section">
          <legend className="form-legend">Contact Person</legend>
          <div className="form-grid-2">
            <div className="field">
              <label htmlFor="contactName">Name</label>
              <input id="contactName" value={form.contactName}
                onChange={set("contactName")} placeholder="Rahul Reddy" required />
            </div>
            <div className="field">
              <label htmlFor="contactPhone">Phone</label>
              <input id="contactPhone" type="tel" value={form.contactPhone}
                onChange={set("contactPhone")} placeholder="+91 99887 76655" required />
            </div>
          </div>
        </fieldset>

        <div className="field">
          <label htmlFor="notes">Additional Notes</label>
          <textarea id="notes" rows={2} value={form.notes}
            onChange={set("notes")} placeholder="Thalassemia patient, O+ preferred …" />
        </div>

        {error && (
          <div className="form-error" role="alert">⚠ {error}</div>
        )}

        <button type="submit" className="btn btn-primary req-submit"
          disabled={status === "loading"}>
          {status === "loading"
            ? <><span className="spinner" aria-hidden="true" /> Sending alert…</>
            : "Send Blood Request →"}
        </button>
      </form>

      {/* Matched donors */}
      {status === "success" && (
        <section className="req-donors mt-4" aria-live="polite">
          <div className="req-donors__header">
            <p className="section-title">Request Sent</p>
            <h2 className="req-donors__title">
              {donors && donors.length > 0
                ? `${donors.length} compatible donor${donors.length > 1 ? "s" : ""} found nearby`
                : "No donors found in this city right now"}
            </h2>
            {requestId && (
              <p className="req-donors__id text-muted">
                Request ID: <code>{requestId}</code>
              </p>
            )}
          </div>

            {donors && donors.length > 0 && (
            <ul className="donors-list">
              {donors.map((d) => (
                <li
                  key={d.id}
                  className={`donor-card card ${d.blood_group?.includes("O") ? "card--gold" : d.blood_group?.includes("A") ? "card--rose" : d.blood_group?.includes("B") ? "card--blue" : "card--lilac"}`}
                >
                  <div className="donor-card__group">{d.blood_group}</div>
                  <div className="donor-card__info">
                    <span className="donor-card__name">{d.username}</span>
                    <span className="donor-card__city text-muted">
                      {d.phone || "—"} · {d.email || "—"}
                    </span>
                    <span className="text-muted" style={{ fontSize: "0.8rem" }}>
                      Last donated: {d.last_donated ? new Date(d.last_donated).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }) : "—"}
                    </span>
                  </div>
                  <div className="donor-card__actions">
                    {d.phone && (
                      <a className="btn btn-ghost donor-card__call" href={`tel:${d.phone}`}>
                        Call
                      </a>
                    )}
                    {d.email && (
                      <button
                        type="button"
                        className="btn btn-ghost donor-card__call"
                        disabled={emailingId === d.id}
                        onClick={() => sendDonorEmail(d.id)}
                      >
                        {emailingId === d.id ? "Sending..." : emailedIds.has(d.id) ? "Sent" : "Email"}
                      </button>
                    )}
                  </div>
                </li>
              ))}
            </ul>
          )}

          <button className="btn btn-ghost mt-3"
            onClick={() => { setForm(INITIAL); setStatus("idle"); setDonors(null); setEmailedIds(new Set()); }}>
            New Request
          </button>
        </section>
      )}
    </main>
  );
}
