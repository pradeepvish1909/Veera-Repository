import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { loginDonor } from "../services/api";
import "./Login.css";

const INITIAL = { identifier: "", password: "" };

export default function Login() {
  const [form, setForm] = useState(INITIAL);
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const set = (field) => (e) =>
    setForm((prev) => ({ ...prev, [field]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus("loading");
    setError("");

    try {
      const res = await loginDonor(form);
      const token = res.data?.token;
      const donorId = res.data?.donor?.id;
      if (token) localStorage.setItem("token", token);
      if (donorId) localStorage.setItem("donorId", String(donorId));
      setStatus("success");
      navigate("/dashboard", { replace: true });
    } catch (err) {
      setError(err.message);
      setStatus("error");
    }
  };

  return (
    <main className="page">
      <div className="login-card card">
        <div className="login-top-actions">
          <Link to="/" className="btn btn-ghost login-top-link">
            Home
          </Link>
          <Link to="/register" className="btn btn-ghost login-top-link">
            Register
          </Link>
        </div>
        <p className="section-title">Donor Login</p>
        <h1 className="login-title">Welcome back</h1>
        <p className="login-sub text-muted">
          Sign in to manage your availability and receive live requests.
        </p>

        <form className="login-form" onSubmit={handleSubmit} noValidate>
          <div className="field">
            <label htmlFor="identifier">Email or Mobile Number</label>
            <input
              id="identifier"
              type="text"
              value={form.identifier}
              onChange={set("identifier")}
              placeholder="name@email.com or +91 98765 43210"
              required
            />
          </div>
          <div className="field">
            <label htmlFor="password">Password</label>
            <input
              id="password"
              type="password"
              value={form.password}
              onChange={set("password")}
              placeholder="Your password"
              required
            />
          </div>

          {error && (
            <div className="form-error" role="alert">
              ⚠ {error}
            </div>
          )}

          <button
            type="submit"
            className="btn btn-primary"
            disabled={status === "loading"}
          >
            {status === "loading" ? "Signing in..." : "Sign in"}
          </button>
        </form>
      </div>
    </main>
  );
}
