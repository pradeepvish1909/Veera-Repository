import { useEffect, useState } from "react";
import { getNotifications, markNotificationRead } from "../services/api";
import "./Notifications.css";

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;

    const load = async () => {
      try {
        const res = await getNotifications();
        if (active) setNotifications(res.data || []);
      } catch (err) {
        if (active) setError(err.message || "Could not load notifications.");
      } finally {
        if (active) setLoading(false);
      }
    };

    load();
    return () => {
      active = false;
    };
  }, []);

  const markRead = async (id) => {
    try {
      await markNotificationRead(id);
      setNotifications((prev) =>
        prev.map((item) => (item.id === id ? { ...item, is_read: 1 } : item))
      );
    } catch (err) {
      setError(err.message || "Could not update notification.");
    }
  };

  return (
    <main className="page">
      <header className="notifications__header">
        <p className="section-title">Notifications</p>
        <h1 className="notifications__title">All your request and donor updates.</h1>
      </header>

      {loading ? (
        <div className="card">Loading notifications...</div>
      ) : error ? (
        <div className="form-error">{error}</div>
      ) : notifications.length === 0 ? (
        <div className="card">No notifications yet.</div>
      ) : (
        <div className="notifications__list">
          {notifications.map((item) => (
            <article
              key={item.id}
              className={`card notification-card ${
                item.is_read ? "notification-card--read card--blue" : "card--gold"
              }`}
            >
              <div className="notification-card__top">
                <div>
                  <p className="section-title">{item.type}</p>
                  <h2>{item.title}</h2>
                  <p className="notification-card__date text-muted">
                    {new Date(item.created_at).toLocaleString("en-IN", {
                      day: "numeric",
                      month: "short",
                      year: "numeric",
                      hour: "numeric",
                      minute: "2-digit",
                    })}
                  </p>
                </div>
                {!item.is_read && (
                  <button className="btn btn-ghost" onClick={() => markRead(item.id)}>
                    Mark Read
                  </button>
                )}
              </div>
              <p className="text-muted">{item.message}</p>
            </article>
          ))}
        </div>
      )}
    </main>
  );
}
