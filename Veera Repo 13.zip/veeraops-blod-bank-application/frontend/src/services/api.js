import axios from "axios";

const BASE_URL = import.meta.env.VITE_API_URL || "/api";

const api = axios.create({
  baseURL: BASE_URL,
  headers: { "Content-Type": "application/json" },
  timeout: 10000,
});

// Request interceptor: attach JWT if present
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("token");
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Response interceptor: normalize errors
api.interceptors.response.use(
  (res) => res,
  (err) => {
    const message =
      err.response?.data?.message || err.message || "An error occurred";
    return Promise.reject(new Error(message));
  }
);

// Donor
export const registerDonor = (data) => api.post("/auth/register", data);
export const loginDonor = (data) => api.post("/auth/login", data);
export const getMe = () => api.get("/auth/me");
export const getDonorProfile = (id) => api.get(`/donors/${id}/`);
export const getDonorDonationHistory = (id) =>
  api.get(`/donors/${id}/donations/`);
export const updateDonorProfile = (id, data) => api.patch(`/donors/${id}/`, data);
export const updateDonorAvailability = (id, available) =>
  api.patch(`/donors/${id}/toggle/`, { available });
export const getDonorStats = () => api.get("/donors/stats/summary/");

// Blood Requests
export const createBloodRequest = (data) => api.post("/requests/", data);
export const getMyRequests = () => api.get("/requests/mine/");
export const updateBloodRequestStatus = (requestId, status) =>
  api.patch(`/requests/${requestId}/status/`, { status });
export const deleteBloodRequest = (requestId) => api.delete(`/requests/${requestId}/`);
export const emailDonorForRequest = (requestId, donorId) =>
  api.post(`/requests/${requestId}/email-donor/${donorId}/`);
export const getMatchingDonors = (requestId) =>
  api.get(`/requests/${requestId}/matches/`);

// Notifications
export const getNotifications = () => api.get("/notifications/");
export const markNotificationRead = (id) => api.patch(`/notifications/${id}/read/`);

export default api;
