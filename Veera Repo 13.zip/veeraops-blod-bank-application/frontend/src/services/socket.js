const WS_BASE = import.meta.env.VITE_WS_URL || "ws://localhost:8000/ws/donor";

let socket = null;

const listeners = {
  blood_request: new Set(),
  request_update: new Set(),
};

const emit = (event, payload) => {
  for (const cb of listeners[event] || []) cb(payload);
};

const buildUrl = (donorId) => {
  const token = localStorage.getItem("token");
  const base =
    WS_BASE.startsWith("ws://") || WS_BASE.startsWith("wss://")
      ? WS_BASE
      : `${window.location.origin.replace("http", "ws")}${WS_BASE}`;
  const url = new URL(`${base}/${donorId}/`);
  if (token) url.searchParams.set("token", token);
  return url.toString();
};

const attachHandlers = () => {
  socket.onopen = () => {
    console.log("[Socket] Connected");
  };

  socket.onclose = (evt) => {
    console.warn("[Socket] Disconnected:", evt.code);
  };

  socket.onerror = () => {
    console.error("[Socket] Connection error");
  };

  socket.onmessage = (evt) => {
    try {
      const data = JSON.parse(evt.data);
      if (data.type === "blood_request_alert") {
        emit("blood_request", {
          ...data,
          bloodGroup: data.blood_group ?? data.bloodGroup,
          requestId: data.request_id ?? data.requestId,
        });
      } else if (data.type === "request_update") {
        emit("request_update", data);
      }
    } catch {
      // Ignore non-JSON messages
    }
  };
};

const onEvent = (event, cb) => {
  if (event === "blood_request") listeners.blood_request.add(cb);
  if (event === "request_update") listeners.request_update.add(cb);
};

/** Initialise (or return existing) socket connection */
export const connectSocket = (donorId) => {
  if (!donorId) return { on: () => {}, off: () => {} };
  if (!localStorage.getItem("token")) return { on: () => {}, off: () => {} };
  if (socket && socket.readyState === WebSocket.OPEN) return { on: onEvent, off: offEvent };

  socket = new WebSocket(buildUrl(donorId));
  attachHandlers();

  return { on: onEvent, off: offEvent };
};

/** Gracefully disconnect */
export const disconnectSocket = () => {
  if (socket) {
    socket.close();
    socket = null;
  }
};

/** Return the active socket (null if not connected) */
export const getSocket = () => socket;

// Convenience event helpers

/** Subscribe to a blood-request alert */
export const onBloodRequest = (cb) => {
  listeners.blood_request.add(cb);
};

/** Subscribe to request status updates */
export const onRequestUpdate = (cb) => {
  listeners.request_update.add(cb);
};

/** Emit donor response to a request */
export const emitDonorResponse = (payload) => {
  if (!socket || socket.readyState !== WebSocket.OPEN) return;
  socket.send(JSON.stringify(payload));
};

/** Remove specific event listener */
export const offEvent = (event, cb) => {
  listeners[event]?.delete(cb);
};
