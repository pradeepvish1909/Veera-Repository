import { useEffect, useState, useCallback } from "react";
import { connectSocket, offEvent } from "../services/socket";
import "./AlertBanner.css";

const MAX_ALERTS = 5;
let idCounter = 0;

export default function AlertBanner() {
  const [alerts, setAlerts] = useState([]);

  const addAlert = useCallback((alert) => {
    const id = ++idCounter;
    setAlerts((prev) => [{ ...alert, id }, ...prev].slice(0, MAX_ALERTS));

    // Auto-dismiss after 7 s
    setTimeout(() => dismissAlert(id), 7000);
  }, []);

  const dismissAlert = (id) => {
    setAlerts((prev) => prev.filter((a) => a.id !== id));
  };

  useEffect(() => {
    const storedId = Number(localStorage.getItem("donorId"));
    const donorId = Number.isFinite(storedId) && storedId > 0 ? storedId : null;
    const socket = connectSocket(donorId);

    const handleBloodRequest = (data) => {
      addAlert({
        type: "urgent",
        bloodGroup: data.bloodGroup,
        city: data.city,
        hospital: data.hospital,
        message: `Urgent: ${data.bloodGroup} needed at ${data.hospital}, ${data.city}`,
      });
    };

    const handleRequestUpdate = (data) => {
      addAlert({
        type: "update",
        message: data.message || "A blood request has been updated.",
      });
    };

    socket.on("blood_request", handleBloodRequest);
    socket.on("request_update", handleRequestUpdate);

    return () => {
      offEvent("blood_request", handleBloodRequest);
      offEvent("request_update", handleRequestUpdate);
    };
  }, [addAlert]);

  if (alerts.length === 0) return null;

  return (
    <div className="alert-stack" role="region" aria-label="Live alerts">
      {alerts.map((alert) => (
        <div
          key={alert.id}
          className={`alert-item alert-item--${alert.type}`}
          role="alert"
        >
          <div className="alert-left">
            {alert.type === "urgent" ? (
              <>
                <span className="alert-pulse" aria-hidden="true" />
                <span className="alert-blood-group">{alert.bloodGroup}</span>
              </>
            ) : (
              <span className="alert-icon">↑</span>
            )}
          </div>

          <div className="alert-body">
            <span className="alert-tag">
              {alert.type === "urgent" ? "URGENT REQUEST" : "STATUS UPDATE"}
            </span>
            <p className="alert-message">{alert.message}</p>
          </div>

          <button
            className="alert-close"
            onClick={() => dismissAlert(alert.id)}
            aria-label="Dismiss alert"
          >
            ✕
          </button>
        </div>
      ))}
    </div>
  );
}
