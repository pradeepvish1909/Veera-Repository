import { NavLink, useNavigate } from "react-router-dom";
import "./Navbar.css";

const NAV_ITEMS = [
  { to: "/dashboard", label: "Dashboard" },
  { to: "/request", label: "Request Blood" },
  { to: "/profile", label: "Profile" },
  { to: "/my-requests", label: "My Requests" },
  { to: "/notifications", label: "Notifications" },
];

export default function Navbar() {
  const navigate = useNavigate();
  const authed = Boolean(localStorage.getItem("token"));

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("donorId");
    navigate("/login");
  };

  return (
    <header className="navbar">
      <NavLink to="/" className="navbar-brand">
        <span className="brand-drop" aria-hidden="true">B</span>
        <span className="brand-text">BloodLink</span>
      </NavLink>

      <nav className="navbar-links">
        {NAV_ITEMS.map(({ to, label }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              "nav-link" + (isActive ? " nav-link--active" : "")
            }
          >
            {label}
          </NavLink>
        ))}
        {!authed ? (
          <NavLink
            to="/login"
            className={({ isActive }) =>
              "nav-link" + (isActive ? " nav-link--active" : "")
            }
          >
            Login
          </NavLink>
        ) : (
          <button className="nav-link nav-link--btn" onClick={handleLogout}>
            Logout
          </button>
        )}
      </nav>
    </header>
  );
}
