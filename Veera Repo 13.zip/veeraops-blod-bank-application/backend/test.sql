CREATE DATABASE IF NOT EXISTS bloodlink;
USE bloodlink;

CREATE TABLE IF NOT EXISTS donors (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  age INT NOT NULL,
  gender VARCHAR(30) NOT NULL,
  blood_group VARCHAR(6) NOT NULL,
  phone VARCHAR(30) NULL,
  email VARCHAR(120) NULL,
  city VARCHAR(120) NOT NULL,
  address VARCHAR(255),
  last_donated DATE,
  medical_conditions TEXT,
  password_hash VARCHAR(255),
  available TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_donors_phone (phone),
  UNIQUE KEY uniq_donors_email (email),
  INDEX idx_donors_group_city (blood_group, city),
  INDEX idx_donors_available (available)
);

UPDATE donors SET phone = NULL WHERE phone = '';
UPDATE donors SET email = NULL WHERE email = '';
UPDATE donors
SET phone = CONCAT(
  CASE WHEN phone LIKE '+%' THEN '+' ELSE '' END,
  REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(phone, ' ', ''), '-', ''), '(', ''), ')', ''), '+', '')
)
WHERE phone IS NOT NULL;

ALTER TABLE donors MODIFY phone VARCHAR(30) NULL;
ALTER TABLE donors MODIFY email VARCHAR(120) NULL;

CREATE TABLE IF NOT EXISTS donations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  donor_id INT NOT NULL,
  date DATE NOT NULL,
  hospital VARCHAR(160) NOT NULL,
  units INT NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (donor_id) REFERENCES donors(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  created_by INT NULL,
  patient_name VARCHAR(120),
  blood_group VARCHAR(6) NOT NULL,
  units INT NOT NULL DEFAULT 1,
  hospital VARCHAR(160),
  city VARCHAR(120),
  contact_name VARCHAR(120),
  contact_phone VARCHAR(30),
  urgency ENUM('critical','urgent','normal') NOT NULL DEFAULT 'urgent',
  notes TEXT,
  status ENUM('open','fulfilled','cancelled') NOT NULL DEFAULT 'open',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES donors(id) ON DELETE SET NULL,
  INDEX idx_requests_group_city (blood_group, city)
);


CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  donor_id INT NOT NULL,
  type VARCHAR(40) NOT NULL DEFAULT 'info',
  title VARCHAR(160) NOT NULL,
  message TEXT NOT NULL,
  request_id INT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (donor_id) REFERENCES donors(id) ON DELETE CASCADE,
  FOREIGN KEY (request_id) REFERENCES requests(id) ON DELETE SET NULL,
  INDEX idx_notifications_donor_created (donor_id, created_at),
  INDEX idx_notifications_read (donor_id, is_read)
);

CREATE TABLE IF NOT EXISTS request_responses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  request_id INT NOT NULL,
  donor_id INT NOT NULL,
  accepted TINYINT(1) NOT NULL,
  responded_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (request_id) REFERENCES requests(id) ON DELETE CASCADE,
  FOREIGN KEY (donor_id) REFERENCES donors(id) ON DELETE CASCADE,
  UNIQUE KEY uniq_request_donor (request_id, donor_id)
);
