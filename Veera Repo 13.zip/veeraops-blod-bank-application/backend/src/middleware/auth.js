const jwt = require("jsonwebtoken");

const getJwtSecret = () => {
  const secret = process.env.JWT_SECRET;
  if (!secret) {
    const err = new Error("JWT_SECRET not configured");
    err.status = 500;
    throw err;
  }
  return secret;
};

const signToken = (payload) =>
  jwt.sign(payload, getJwtSecret(), {
    expiresIn: process.env.JWT_EXPIRES || "7d",
  });

const verifyToken = (token) => jwt.verify(token, getJwtSecret());

const requireAuth = (req, res, next) => {
  const header = req.headers.authorization || "";
  const [scheme, token] = header.split(" ");
  if (scheme !== "Bearer" || !token) {
    return res.status(401).json({ message: "Unauthorized" });
  }

  try {
    req.user = verifyToken(token);
    return next();
  } catch {
    return res.status(401).json({ message: "Invalid or expired token" });
  }
};

const requireSameDonor = (req, res, next) => {
  const donorId = Number(req.params.id);
  if (!Number.isFinite(donorId)) {
    return res.status(400).json({ message: "Invalid donor id." });
  }
  if (!req.user || req.user.donorId !== donorId) {
    return res.status(403).json({ message: "Forbidden" });
  }
  return next();
};

module.exports = { signToken, verifyToken, requireAuth, requireSameDonor };
