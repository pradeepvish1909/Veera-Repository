const bcrypt = require("bcryptjs");
const { query } = require("../db");
const { signToken } = require("../middleware/auth");

const normalizePhone = (value) => {
  const raw = String(value || "").trim();
  if (!raw) return "";

  const hasPlusPrefix = raw.startsWith("+");
  const digitsOnly = raw.replace(/\D/g, "");
  if (!digitsOnly) return "";

  return hasPlusPrefix ? `+${digitsOnly}` : digitsOnly;
};
const normalizeEmail = (value) => String(value || "").trim().toLowerCase();
const phoneDigitsOnly = (value) => String(value || "").replace(/\D/g, "");

const normalizeDonor = (row) => ({
  _id: row.id,
  id: row.id,
  name: row.name,
  age: row.age,
  gender: row.gender,
  bloodGroup: row.blood_group,
  phone: row.phone,
  email: row.email,
  city: row.city,
  address: row.address,
  lastDonated: row.last_donated,
  medicalConditions: row.medical_conditions,
  available: Boolean(row.available),
  totalDonations: row.total_donations || 0,
});

const registerDonor = async (payload) => {
  const {
    name,
    age,
    gender,
    bloodGroup,
    phone,
    email,
    city,
    address,
    lastDonated,
    medicalConditions,
    password,
  } = payload || {};

  const normalizedPhone = normalizePhone(phone);
  const normalizedEmail = normalizeEmail(email);

  if (!name || !age || !gender || !bloodGroup || !city || !password) {
    const err = new Error("Missing required donor fields.");
    err.status = 400;
    throw err;
  }

  if (!normalizedPhone && !normalizedEmail) {
    const err = new Error("Provide at least an email address or mobile number.");
    err.status = 400;
    throw err;
  }

  if (String(password).length < 6) {
    const err = new Error("Password must be at least 6 characters.");
    err.status = 400;
    throw err;
  }

  if (normalizedPhone) {
    const existingPhone = await query(
      `SELECT id
       FROM donors
       WHERE phone = ?
          OR REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(phone, ' ', ''), '-', ''), '(', ''), ')', ''), '+', '') = ?
       LIMIT 1`,
      [normalizedPhone, phoneDigitsOnly(normalizedPhone)]
    );
    if (existingPhone.length > 0) {
      const err = new Error("Donor with this mobile number already exists.");
      err.status = 409;
      throw err;
    }
  }

  if (normalizedEmail) {
    const existingEmail = await query(
      "SELECT id FROM donors WHERE LOWER(email) = ? LIMIT 1",
      [normalizedEmail]
    );
    if (existingEmail.length > 0) {
      const err = new Error("Donor with this email already exists.");
      err.status = 409;
      throw err;
    }
  }

  const passwordHash = await bcrypt.hash(String(password), 10);

  const result = await query(
    `INSERT INTO donors
    (name, age, gender, blood_group, phone, email, city, address, last_donated, medical_conditions, password_hash)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      name,
      Number(age),
      gender,
      bloodGroup,
      normalizedPhone || null,
      normalizedEmail || null,
      city,
      address || null,
      lastDonated || null,
      medicalConditions || null,
      passwordHash,
    ]
  );

  const donorId = result.insertId;
  const rows = await query("SELECT * FROM donors WHERE id = ?", [donorId]);
  const donor = normalizeDonor(rows[0]);
  const token = signToken({
    donorId,
    phone: normalizedPhone || undefined,
    email: normalizedEmail || undefined,
  });

  return { donor, token, donorId };
};

module.exports = { normalizeDonor, registerDonor };
