const nodemailer = require("nodemailer");

const getBooleanEnv = (name, defaultValue = false) => {
  const raw = process.env[name];
  if (raw == null || raw === "") return defaultValue;
  return ["1", "true", "yes", "on"].includes(String(raw).trim().toLowerCase());
};

const envValue = (...names) => {
  for (const name of names) {
    const value = process.env[name];
    if (value != null && String(value).trim() !== "") return String(value).trim();
  }
  return "";
};

const getSmtpHost = () => envValue("SMTP_HOST", "MAIL_HOST") || "smtp.gmail.com";
const getSmtpPort = () => Number(envValue("SMTP_PORT", "MAIL_PORT") || 587);
const getSmtpUser = () => envValue("SMTP_USER", "MAIL_USER", "MAIL_USERNAME");
const getSmtpPass = () => {
  const password = envValue("SMTP_PASS", "MAIL_PASS", "MAIL_PASSWORD");
  return getSmtpHost().includes("gmail.com") ? password.replace(/[^a-zA-Z0-9]/g, "") : password;
};
const getMailFrom = () => envValue("MAIL_FROM", "SMTP_FROM") || getSmtpUser();
const getSmtpSecure = (port) => getBooleanEnv("SMTP_SECURE", getBooleanEnv("MAIL_SECURE", port === 465));
const BRAND_NAME = "Multicloud DevOps by Veera Sir Blood Bank";

const escapeHtml = (value) =>
  String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");

const field = (label, value) => {
  if (value == null || value === "") return "";
  return `${label}: ${value}`;
};

const withBrandText = (text) => `${text}\n\n--\n${BRAND_NAME}`;

const withBrandHtml = (html) => `
  ${html}
  <p style="margin-top: 20px; padding-top: 12px; border-top: 1px solid #ddd; color: #666; font-size: 12px;">
    ${escapeHtml(BRAND_NAME)}
  </p>
`;

const buildRequestText = (request) =>
  [
    `Blood request #${request.id}`,
    "",
    field("Blood group", request.blood_group),
    field("Units needed", request.units || 1),
    field("Urgency", request.urgency || "urgent"),
    field("Patient", request.patient_name),
    field("Hospital", request.hospital),
    field("City", request.city),
    field("Contact name", request.contact_name),
    field("Contact phone", request.contact_phone),
    field("Contact email", request.contact_email),
    field("Notes", request.notes),
    "",
    "Please contact the requester directly if you can help.",
  ]
    .filter(Boolean)
    .join("\n");

const buildRequestHtml = (request) => {
  const rows = [
    ["Blood group", request.blood_group],
    ["Units needed", request.units || 1],
    ["Urgency", request.urgency || "urgent"],
    ["Patient", request.patient_name],
    ["Hospital", request.hospital],
    ["City", request.city],
    ["Contact name", request.contact_name],
    ["Contact phone", request.contact_phone],
    ["Contact email", request.contact_email],
    ["Notes", request.notes],
  ].filter(([, value]) => value != null && value !== "");

  return `
    <div style="font-family: Arial, sans-serif; color: #222; line-height: 1.5;">
      <h2 style="margin: 0 0 12px;">Blood request #${escapeHtml(request.id)}</h2>
      <p>A matching blood request was created. Please contact the requester directly if you can help.</p>
      <table cellpadding="8" cellspacing="0" style="border-collapse: collapse;">
        ${rows
          .map(
            ([label, value]) => `
              <tr>
                <td style="font-weight: 700; border: 1px solid #ddd;">${escapeHtml(label)}</td>
                <td style="border: 1px solid #ddd;">${escapeHtml(value)}</td>
              </tr>`
          )
          .join("")}
      </table>
    </div>
  `;
};

const isMailConfigured = () =>
  Boolean(getSmtpUser() && getSmtpPass()) && getBooleanEnv("MAIL_ENABLED", true);

const getMailConfigStatus = () => ({
  enabled: getBooleanEnv("MAIL_ENABLED", true),
  hasUser: Boolean(getSmtpUser()),
  hasPass: Boolean(getSmtpPass()),
  host: getSmtpHost(),
  port: getSmtpPort(),
  secure: getSmtpSecure(getSmtpPort()),
});

let transporter;

const getTransporter = () => {
  if (!isMailConfigured()) return null;
  if (!transporter) {
    const port = getSmtpPort();
    const host = getSmtpHost();
    transporter = nodemailer.createTransport({
      service: host.includes("gmail.com") ? "gmail" : undefined,
      host,
      port,
      secure: getSmtpSecure(port),
      requireTLS: port === 587,
      auth: {
        user: getSmtpUser(),
        pass: getSmtpPass(),
      },
    });
  }
  return transporter;
};

const sendBloodRequestEmails = async (request, donors, requester) => {
  const mailer = getTransporter();
  if (!mailer || !Array.isArray(donors) || donors.length === 0) return { sent: 0, skipped: true };

  const recipients = donors.filter((donor) => donor.email);
  if (recipients.length === 0) return { sent: 0, skipped: true };

  const from = getMailFrom();
  const subject = `Urgent ${request.blood_group} blood request${request.city ? ` in ${request.city}` : ""}`;
  const requestWithContactEmail = {
    ...request,
    contact_email: requester?.email || request.contact_email,
  };
  const text = buildRequestText(requestWithContactEmail);
  const html = buildRequestHtml(requestWithContactEmail);

  const results = await Promise.allSettled(
    recipients.map((donor) =>
      mailer.sendMail({
        from,
        to: donor.email,
        replyTo: requester?.email || undefined,
        subject,
        text: withBrandText(`Hello ${donor.name || "Donor"},\n\n${text}`),
        html: withBrandHtml(html),
      })
    )
  );

  const failed = results.filter((result) => result.status === "rejected");
  if (failed.length > 0) {
    console.error(`Failed to send ${failed.length} blood request email(s).`, failed.map((f) => f.reason?.message || f.reason));
  }

  return {
    sent: results.length - failed.length,
    failed: failed.length,
    error: failed[0]?.reason?.response || failed[0]?.reason?.message || undefined,
  };
};

const buildDonorResponseText = (request, donor, accepted) =>
  [
    accepted ? "A donor accepted your blood request." : "A donor declined your blood request.",
    "",
    `Request #${request.id}`,
    field("Blood group", request.blood_group),
    field("Hospital", request.hospital),
    field("City", request.city),
    "",
    accepted ? "Donor details" : "",
    accepted ? field("Name", donor.name) : "",
    accepted ? field("Phone", donor.phone) : "",
    accepted ? field("Email", donor.email) : "",
    "",
    accepted
      ? "Please contact the donor quickly and coordinate the donation safely."
      : "The request remains visible to other matching donors.",
  ]
    .filter(Boolean)
    .join("\n");

const buildDonorResponseHtml = (request, donor, accepted) => {
  const rows = [
    ["Request ID", request.id],
    ["Blood group", request.blood_group],
    ["Hospital", request.hospital],
    ["City", request.city],
    accepted ? ["Donor name", donor.name] : null,
    accepted ? ["Donor phone", donor.phone] : null,
    accepted ? ["Donor email", donor.email] : null,
  ].filter(Boolean).filter(([, value]) => value != null && value !== "");

  return `
    <div style="font-family: Arial, sans-serif; color: #222; line-height: 1.5;">
      <h2 style="margin: 0 0 12px;">${accepted ? "Request accepted" : "Request updated"}</h2>
      <p>${
        accepted
          ? "A donor accepted your blood request. Contact them quickly and coordinate the next step."
          : "A donor declined your blood request. Other matching donors can still respond."
      }</p>
      <table cellpadding="8" cellspacing="0" style="border-collapse: collapse;">
        ${rows
          .map(
            ([label, value]) => `
              <tr>
                <td style="font-weight: 700; border: 1px solid #ddd;">${escapeHtml(label)}</td>
                <td style="border: 1px solid #ddd;">${escapeHtml(value)}</td>
              </tr>`
          )
          .join("")}
      </table>
    </div>
  `;
};

const sendDonorResponseEmail = async (request, requester, donor, accepted) => {
  const mailer = getTransporter();
  if (!mailer || !requester?.email) return { sent: 0, skipped: true };

  try {
    await mailer.sendMail({
      from: getMailFrom(),
      to: requester.email,
      replyTo: accepted && donor?.email ? donor.email : undefined,
      subject: accepted
        ? `Donor accepted your ${request.blood_group} request`
        : `Update on your ${request.blood_group} blood request`,
      text: withBrandText(`Hello ${requester.name || "Requester"},\n\n${buildDonorResponseText(request, donor, accepted)}`),
      html: withBrandHtml(buildDonorResponseHtml(request, donor, accepted)),
    });
    return { sent: 1 };
  } catch (err) {
    console.error("Failed to send donor response email.", err?.message || err);
    return { sent: 0, failed: 1 };
  }
};

const buildRequestStatusText = (request, status, actionLabel) =>
  [
    `Your blood request has been ${actionLabel}.`,
    "",
    `Request #${request.id}`,
    field("Blood group", request.blood_group),
    field("Units", request.units || 1),
    field("Patient", request.patient_name),
    field("Hospital", request.hospital),
    field("City", request.city),
    field("Status", status),
    field("Notes", request.notes),
  ]
    .filter(Boolean)
    .join("\n");

const buildRequestStatusHtml = (request, status, actionLabel) => {
  const rows = [
    ["Request ID", request.id],
    ["Blood group", request.blood_group],
    ["Units", request.units || 1],
    ["Patient", request.patient_name],
    ["Hospital", request.hospital],
    ["City", request.city],
    ["Status", status],
    ["Notes", request.notes],
  ].filter(([, value]) => value != null && value !== "");

  return `
    <div style="font-family: Arial, sans-serif; color: #222; line-height: 1.5;">
      <h2 style="margin: 0 0 12px;">Blood request ${escapeHtml(actionLabel)}</h2>
      <p>Your request status has been updated.</p>
      <table cellpadding="8" cellspacing="0" style="border-collapse: collapse;">
        ${rows
          .map(
            ([label, value]) => `
              <tr>
                <td style="font-weight: 700; border: 1px solid #ddd;">${escapeHtml(label)}</td>
                <td style="border: 1px solid #ddd;">${escapeHtml(value)}</td>
              </tr>`
          )
          .join("")}
      </table>
    </div>
  `;
};

const sendRequestStatusEmail = async (request, requester, status, actionLabel = status) => {
  const mailer = getTransporter();
  if (!mailer || !requester?.email) return { sent: 0, skipped: true };

  try {
    await mailer.sendMail({
      from: getMailFrom(),
      to: requester.email,
      subject: `Blood request #${request.id} ${actionLabel}`,
      text: withBrandText(`Hello ${requester.name || "Requester"},\n\n${buildRequestStatusText(request, status, actionLabel)}`),
      html: withBrandHtml(buildRequestStatusHtml(request, status, actionLabel)),
    });
    return { sent: 1 };
  } catch (err) {
    console.error("Failed to send request status email.", err?.message || err);
    return { sent: 0, failed: 1, error: err?.response || err?.message };
  }
};

module.exports = {
  sendBloodRequestEmails,
  sendDonorResponseEmail,
  sendRequestStatusEmail,
  isMailConfigured,
  getMailConfigStatus,
};
