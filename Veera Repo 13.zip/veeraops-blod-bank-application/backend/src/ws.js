const { WebSocketServer, WebSocket } = require("ws");
const url = require("url");
const { query } = require("./db");
const { verifyToken } = require("./middleware/auth");
const { sendDonorResponseEmail } = require("./services/mailer");

const donorSockets = new Map();

const parseDonorId = (reqUrl) => {
  const parsed = url.parse(reqUrl);
  const parts = (parsed.pathname || "").split("/").filter(Boolean);
  const idx = parts.indexOf("donor");
  if (idx === -1 || !parts[idx + 1]) return null;
  const raw = parts[idx + 1];
  const donorId = Number(raw);
  return Number.isFinite(donorId) ? donorId : null;
};

const parseToken = (reqUrl) => {
  const parsed = url.parse(reqUrl, true);
  return parsed.query?.token ? String(parsed.query.token) : null;
};

const attachSocketHandlers = (socket, donorId) => {
  socket.on("message", async (buffer) => {
    try {
      const payload = JSON.parse(buffer.toString());
      const requestId = Number(payload.requestId);
      const accept = Boolean(payload.accept);

      if (!Number.isFinite(requestId) || !Number.isFinite(donorId)) return;

      await query(
        "INSERT INTO request_responses (request_id, donor_id, accepted) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE accepted = VALUES(accepted)",
        [requestId, donorId, accept ? 1 : 0]
      );

      if (accept) {
        await query("UPDATE requests SET status = 'fulfilled' WHERE id = ?", [requestId]);
      }

      const requestRows = await query(
        "SELECT id, created_by, blood_group, hospital, city FROM requests WHERE id = ? LIMIT 1",
        [requestId]
      );
      const request = requestRows[0];

      if (request?.created_by) {
        const donorRows = await query("SELECT id, name, phone, email FROM donors WHERE id = ? LIMIT 1", [donorId]);
        const requesterRows = await query("SELECT id, name, email FROM donors WHERE id = ? LIMIT 1", [
          request.created_by,
        ]);
        const donor = donorRows[0];
        const requester = requesterRows[0];

        await query(
          `INSERT INTO notifications (donor_id, type, title, message, request_id)
           VALUES (?, ?, ?, ?, ?)`,
          [
            request.created_by,
            accept ? "request_accepted" : "request_declined",
            accept ? "Request Accepted" : "Request Updated",
            accept
              ? `${donor?.name || "A donor"} accepted your ${request.blood_group} request for ${request.hospital || request.city || "your selected location"}. Contact: ${donor?.phone || donor?.email || "details shared by email"}.`
              : `A donor declined your ${request.blood_group} request for ${request.hospital || request.city || "your selected location"}.`,
            requestId,
          ]
        );

        await sendDonorResponseEmail(request, requester, donor, accept);
      }

      broadcast({
        type: "request_update",
        request_id: requestId,
        message: accept
          ? `Request ${requestId} accepted by donor ${donorId}.`
          : `Donor ${donorId} declined request ${requestId}.`,
      });
    } catch {
      // Ignore malformed messages
    }
  });

  socket.on("close", () => {
    const set = donorSockets.get(donorId);
    if (set) {
      set.delete(socket);
      if (set.size === 0) donorSockets.delete(donorId);
    }
  });
};

const broadcast = (payload) => {
  const message = JSON.stringify(payload);
  for (const set of donorSockets.values()) {
    for (const socket of set) {
      if (socket.readyState === WebSocket.OPEN) socket.send(message);
    }
  }
};

const notifyDonors = (donorIds, payload) => {
  const message = JSON.stringify(payload);
  donorIds.forEach((donorId) => {
    const set = donorSockets.get(donorId);
    if (!set) return;
    for (const socket of set) {
      if (socket.readyState === WebSocket.OPEN) socket.send(message);
    }
  });
};

const setupWebSockets = (server) => {
  const wss = new WebSocketServer({ noServer: true });

  server.on("upgrade", (req, socket, head) => {
    const donorId = parseDonorId(req.url);
    const token = parseToken(req.url);
    if (!donorId || !token) {
      socket.destroy();
      return;
    }

    try {
      const payload = verifyToken(token);
      if (payload?.donorId !== donorId) {
        socket.destroy();
        return;
      }
    } catch {
      socket.destroy();
      return;
    }

    wss.handleUpgrade(req, socket, head, (ws) => {
      wss.emit("connection", ws, req, donorId);
    });
  });

  wss.on("connection", (ws, _req, donorId) => {
    const set = donorSockets.get(donorId) || new Set();
    set.add(ws);
    donorSockets.set(donorId, set);

    attachSocketHandlers(ws, donorId);

    ws.send(
      JSON.stringify({
        type: "connected",
        donor_id: donorId,
      })
    );
  });

  return { notifyDonors, broadcast };
};

const findMatchingDonorIds = async (bloodGroup, city) => {
  const params = [bloodGroup];
  let sql = "SELECT id FROM donors WHERE blood_group = ? AND available = 1";
  if (city) {
    sql += " AND city = ?";
    params.push(city);
  }
  const rows = await query(sql, params);
  return rows.map((r) => r.id);
};

module.exports = { setupWebSockets, findMatchingDonorIds, notifyDonors, broadcast };
