const path = require("path");
const http = require("http");
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");

require("dotenv").config({ path: path.join(__dirname, "../.env") });

const donorsRouter = require("./routes/donors");
const createRequestsRouter = require("./routes/requests");
const authRouter = require("./routes/auth");
const notificationsRouter = require("./routes/notifications");
const { setupWebSockets, findMatchingDonorIds, notifyDonors } = require("./ws");
const { query } = require("./db");
const { sendBloodRequestEmails } = require("./services/mailer");

const app = express();

app.use(helmet());
app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(morgan("dev"));

app.get("/health", (_req, res) => res.json({ ok: true }));

app.use("/api/auth", authRouter);
app.use("/api/donors", donorsRouter);
app.use("/api/notifications", notificationsRouter);
app.use(
  "/api/requests",
  createRequestsRouter(async (request) => {
    const donorIds = await findMatchingDonorIds(request.blood_group, request.city || null);
    if (donorIds.length > 0) {
      notifyDonors(donorIds, {
        type: "blood_request_alert",
        request_id: request.id,
        blood_group: request.blood_group,
        hospital: request.hospital,
        city: request.city,
        contact_name: request.contact_name,
        contact_phone: request.contact_phone,
        urgency: request.urgency || "urgent",
        notes: request.notes,
      });

      const placeholders = donorIds.map(() => "?").join(", ");
      const donors = await query(
        `SELECT id, name, email FROM donors WHERE id IN (${placeholders}) AND email IS NOT NULL AND email <> ''`,
        donorIds
      );
      const requesterRows = request.created_by
        ? await query("SELECT id, name, email FROM donors WHERE id = ? LIMIT 1", [request.created_by])
        : [];
      await sendBloodRequestEmails(request, donors, requesterRows[0]);
    }
  })
);

// Error handler
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(err.status || 500).json({ message: err.message || "Server error" });
});

const server = http.createServer(app);
setupWebSockets(server);

const PORT = Number(process.env.PORT || 8000);
server.listen(PORT, () => {
  console.log(`API listening on http://localhost:${PORT}`);
});
