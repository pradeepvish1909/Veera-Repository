const express = require("express");
const { query } = require("../db");
const { requireAuth } = require("../middleware/auth");
const {
  getMailConfigStatus,
  isMailConfigured,
  sendBloodRequestEmails,
  sendRequestStatusEmail,
} = require("../services/mailer");

const createRequestsRouter = (onRequestCreated) => {
  const router = express.Router();

  const normalizeRequest = (row) => ({
    id: row.id,
    created_by: row.created_by,
    patient_name: row.patient_name,
    blood_group: row.blood_group,
    units: row.units,
    hospital: row.hospital,
    city: row.city,
    contact_name: row.contact_name,
    contact_phone: row.contact_phone,
    urgency: row.urgency,
    notes: row.notes,
    status: row.status,
    created_at: row.created_at,
  });

  router.post("/", requireAuth, async (req, res, next) => {
    try {
      const creatorId = Number(req.user?.donorId);
      const {
        patient_name,
        blood_group,
        units,
        hospital,
        city,
        contact_name,
        contact_phone,
        urgency,
        notes,
      } = req.body || {};

      if (!blood_group) {
        return res.status(400).json({ message: "Missing required request fields." });
      }

      if (!Number.isFinite(creatorId)) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const existingOpenRequests = await query(
        `SELECT id, status, created_at
         FROM requests
         WHERE created_by = ? AND status = 'open'
         ORDER BY created_at DESC
         LIMIT 1`,
        [creatorId]
      );

      if (existingOpenRequests.length > 0) {
        return res.status(409).json({
          message: `You already have an active blood request (Request ID #${existingOpenRequests[0].id}). Please complete or close it before creating another request.`,
        });
      }

      const result = await query(
        `INSERT INTO requests
        (created_by, patient_name, blood_group, units, hospital, city, contact_name, contact_phone, urgency, notes)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          Number.isFinite(creatorId) ? creatorId : null,
          patient_name || null,
          blood_group,
          Number(units || 1),
          hospital || null,
          city || null,
          contact_name || null,
          contact_phone || null,
          urgency || "urgent",
          notes || null,
        ]
      );

      const rows = await query("SELECT * FROM requests WHERE id = ?", [result.insertId]);
      const request = normalizeRequest(rows[0]);

      await query(
        `INSERT INTO notifications (donor_id, type, title, message, request_id)
         VALUES (?, 'request_created', 'Request Created', ?, ?)`,
        [
          creatorId,
          `Your ${blood_group} blood request has been created for ${hospital || city || "the selected location"}.`,
          result.insertId,
        ]
      );

      if (typeof onRequestCreated === "function") {
        await onRequestCreated(request);
      }

      res.status(201).json(request);
    } catch (err) {
      next(err);
    }
  });

  router.get("/mine/", requireAuth, async (req, res, next) => {
    try {
      const donorId = Number(req.user?.donorId);
      if (!Number.isFinite(donorId)) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const rows = await query(
        `SELECT r.*,
                COUNT(rr.id) AS response_count,
                SUM(CASE WHEN rr.accepted = 1 THEN 1 ELSE 0 END) AS accepted_count
         FROM requests r
         LEFT JOIN request_responses rr ON rr.request_id = r.id
         WHERE r.created_by = ?
         GROUP BY r.id
         ORDER BY r.created_at DESC`,
        [donorId]
      );

      res.json(
        rows.map((row) => ({
          ...normalizeRequest(row),
          response_count: Number(row.response_count || 0),
          accepted_count: Number(row.accepted_count || 0),
        }))
      );
    } catch (err) {
      next(err);
    }
  });

  router.patch("/:id/status/", requireAuth, async (req, res, next) => {
    try {
      const donorId = Number(req.user?.donorId);
      const requestId = Number(req.params.id);
      const nextStatus = String(req.body?.status || "").trim().toLowerCase();

      if (!Number.isFinite(donorId) || !Number.isFinite(requestId)) {
        return res.status(400).json({ message: "Invalid request id." });
      }

      if (!["open", "fulfilled", "cancelled"].includes(nextStatus)) {
        return res.status(400).json({ message: "Invalid request status." });
      }

      const result = await query(
        "UPDATE requests SET status = ? WHERE id = ? AND created_by = ?",
        [nextStatus, requestId, donorId]
      );

      if (result.affectedRows === 0) {
        return res.status(404).json({ message: "Request not found." });
      }

      await query(
        `INSERT INTO notifications (donor_id, type, title, message, request_id)
         VALUES (?, 'request_status', 'Request Updated', ?, ?)`,
        [
          donorId,
          `Your request #${requestId} is now ${nextStatus}.`,
          requestId,
        ]
      );

      const rows = await query("SELECT * FROM requests WHERE id = ?", [requestId]);
      const request = normalizeRequest(rows[0]);
      const requesterRows = await query("SELECT id, name, email FROM donors WHERE id = ? LIMIT 1", [donorId]);
      await sendRequestStatusEmail(request, requesterRows[0], nextStatus, nextStatus);

      res.json(request);
    } catch (err) {
      next(err);
    }
  });

  router.delete("/:id/", requireAuth, async (req, res, next) => {
    try {
      const donorId = Number(req.user?.donorId);
      const requestId = Number(req.params.id);

      if (!Number.isFinite(donorId) || !Number.isFinite(requestId)) {
        return res.status(400).json({ message: "Invalid request id." });
      }

      const requestRows = await query("SELECT * FROM requests WHERE id = ? AND created_by = ? LIMIT 1", [
        requestId,
        donorId,
      ]);
      if (requestRows.length === 0) {
        return res.status(404).json({ message: "Request not found." });
      }

      const requesterRows = await query("SELECT id, name, email FROM donors WHERE id = ? LIMIT 1", [donorId]);
      await sendRequestStatusEmail(normalizeRequest(requestRows[0]), requesterRows[0], "deleted", "deleted");

      const result = await query("DELETE FROM requests WHERE id = ? AND created_by = ?", [
        requestId,
        donorId,
      ]);

      if (result.affectedRows === 0) {
        return res.status(404).json({ message: "Request not found." });
      }

      res.status(204).send();
    } catch (err) {
      next(err);
    }
  });

  router.post("/:id/email-donor/:donorId/", requireAuth, async (req, res, next) => {
    try {
      const requesterId = Number(req.user?.donorId);
      const requestId = Number(req.params.id);
      const donorId = Number(req.params.donorId);

      if (!Number.isFinite(requesterId) || !Number.isFinite(requestId) || !Number.isFinite(donorId)) {
        return res.status(400).json({ message: "Invalid request or donor id." });
      }

      if (!isMailConfigured()) {
        const mailStatus = getMailConfigStatus();
        return res.status(503).json({
          message: `Email is not configured. MAIL_ENABLED=${mailStatus.enabled}, SMTP_USER=${mailStatus.hasUser ? "set" : "missing"}, SMTP_PASS=${mailStatus.hasPass ? "set" : "missing"}.`,
        });
      }

      const requestRows = await query("SELECT * FROM requests WHERE id = ? AND created_by = ? LIMIT 1", [
        requestId,
        requesterId,
      ]);
      if (requestRows.length === 0) {
        return res.status(404).json({ message: "Request not found." });
      }

      const donorRows = await query(
        `SELECT id, name, email, phone, blood_group, last_donated
         FROM donors
         WHERE id = ? AND email IS NOT NULL AND email <> ''
         LIMIT 1`,
        [donorId]
      );
      if (donorRows.length === 0) {
        return res.status(404).json({ message: "Donor email not found." });
      }

      const requesterRows = await query("SELECT id, name, email FROM donors WHERE id = ? LIMIT 1", [requesterId]);
      const mailResult = await sendBloodRequestEmails(
        normalizeRequest(requestRows[0]),
        donorRows,
        requesterRows[0]
      );

      if (!mailResult.sent) {
        return res.status(502).json({
          message: mailResult.error
            ? `Email could not be sent: ${mailResult.error}`
            : "Email could not be sent. Check SMTP credentials.",
        });
      }

      res.json({ sent: true, donor_id: donorId, request_id: requestId });
    } catch (err) {
      next(err);
    }
  });

  router.get("/:id/matches/", async (req, res, next) => {
    try {
      const requestId = Number(req.params.id);
      if (!Number.isFinite(requestId)) {
        return res.status(400).json({ message: "Invalid request id." });
      }

      const reqRows = await query("SELECT blood_group, city FROM requests WHERE id = ?", [requestId]);
      if (reqRows.length === 0) {
        return res.status(404).json({ message: "Request not found." });
      }

      const { blood_group, city } = reqRows[0];
      const params = [blood_group];
      let sql =
        "SELECT id, name, email, phone, blood_group, last_donated FROM donors WHERE blood_group = ? AND available = 1";
      if (city) {
        sql += " AND city = ?";
        params.push(city);
      }

      const donors = await query(sql, params);
      const payload = donors.map((d) => ({
        id: d.id,
        username: d.name,
        email: d.email,
        phone: d.phone,
        blood_group: d.blood_group,
        last_donated: d.last_donated,
      }));

      res.json(payload);
    } catch (err) {
      next(err);
    }
  });

  return router;
};

module.exports = createRequestsRouter;
