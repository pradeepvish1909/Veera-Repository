const express = require("express");
const { query } = require("../db");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();

router.get("/", requireAuth, async (req, res, next) => {
  try {
    const donorId = Number(req.user?.donorId);
    if (!Number.isFinite(donorId)) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const rows = await query(
      `SELECT id, type, title, message, request_id, is_read, created_at
       FROM notifications
       WHERE donor_id = ?
       ORDER BY created_at DESC
       LIMIT 50`,
      [donorId]
    );

    res.json(rows);
  } catch (err) {
    next(err);
  }
});

router.patch("/:id/read/", requireAuth, async (req, res, next) => {
  try {
    const donorId = Number(req.user?.donorId);
    const notificationId = Number(req.params.id);
    if (!Number.isFinite(donorId) || !Number.isFinite(notificationId)) {
      return res.status(400).json({ message: "Invalid notification id." });
    }

    await query(
      "UPDATE notifications SET is_read = 1 WHERE id = ? AND donor_id = ?",
      [notificationId, donorId]
    );

    res.json({ ok: true });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
