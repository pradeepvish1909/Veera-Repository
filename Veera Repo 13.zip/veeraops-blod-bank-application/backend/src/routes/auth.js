const express = require("express");
const bcrypt = require("bcryptjs");
const { query } = require("../db");
const { signToken, requireAuth } = require("../middleware/auth");
const { normalizeDonor, registerDonor } = require("../services/donorAuth");

const router = express.Router();

const normalizePhone = (value) => {
  const raw = String(value || "").trim();
  if (!raw) return "";

  const hasPlusPrefix = raw.startsWith("+");
  const digitsOnly = raw.replace(/\D/g, "");
  if (!digitsOnly) return "";

  return hasPlusPrefix ? `+${digitsOnly}` : digitsOnly;
};
const phoneDigitsOnly = (value) => String(value || "").replace(/\D/g, "");

router.post("/register", async (req, res, next) => {
  try {
    const { donor, token, donorId } = await registerDonor(req.body);
    res.status(201).json({ donor, _id: donorId, token });
  } catch (err) {
    next(err);
  }
});

router.post("/login", async (req, res, next) => {
  try {
    const { identifier, phone, email, password } = req.body || {};
    const loginValue = String(identifier || email || phone || "").trim();
    const normalizedEmail = loginValue.toLowerCase();
    const normalizedPhone = normalizePhone(loginValue);

    if (!loginValue || !password) {
      return res.status(400).json({ message: "Email or mobile number and password are required." });
    }

    const rows = await query(
      `SELECT *
       FROM donors
       WHERE phone = ?
          OR REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(phone, ' ', ''), '-', ''), '(', ''), ')', ''), '+', '') = ?
          OR LOWER(email) = ?
       LIMIT 1`,
      [normalizedPhone, phoneDigitsOnly(normalizedPhone), normalizedEmail]
    );
    if (rows.length === 0) {
      return res.status(401).json({ message: "Invalid credentials." });
    }

    const donor = rows[0];
    if (!donor.password_hash) {
      return res.status(400).json({ message: "Password not set for this donor." });
    }

    const ok = await bcrypt.compare(password, donor.password_hash);
    if (!ok) {
      return res.status(401).json({ message: "Invalid credentials." });
    }

    const token = signToken({
      donorId: donor.id,
      phone: donor.phone || undefined,
      email: donor.email || undefined,
    });
    res.json({ token, donor: normalizeDonor(donor) });
  } catch (err) {
    next(err);
  }
});

router.get("/me", requireAuth, async (req, res, next) => {
  try {
    const donorId = Number(req.user?.donorId);
    if (!Number.isFinite(donorId)) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const rows = await query("SELECT * FROM donors WHERE id = ?", [donorId]);
    if (rows.length === 0) return res.status(404).json({ message: "Donor not found." });

    res.json({ donor: normalizeDonor(rows[0]) });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
