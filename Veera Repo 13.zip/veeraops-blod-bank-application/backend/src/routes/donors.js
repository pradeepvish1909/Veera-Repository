const express = require("express");
const { query } = require("../db");
const { requireAuth, requireSameDonor } = require("../middleware/auth");
const { normalizeDonor, registerDonor } = require("../services/donorAuth");

const router = express.Router();

const normalizePhone = (value) => {
  const raw = String(value || "").trim();
  if (!raw) return "";

  const hasPlusPrefix = raw.startsWith("+");
  const digitsOnly = raw.replace(/\D/g, "");
  if (!digitsOnly) return "";

  return hasPlusPrefix ? `+${digitsOnly}` : digitsOnly;
};

const normalizeEmail = (value) => String(value || "").trim().toLowerCase();
const phoneDigitsOnly = (value) => String(value || "").replace(/\D/g, "");

router.post("/register/", async (req, res, next) => {
  try {
    const { donor, token, donorId } = await registerDonor(req.body);
    res.status(201).json({ donor, _id: donorId, token });
  } catch (err) {
    next(err);
  }
});

router.get("/stats/summary/", async (_req, res, next) => {
  try {
    const totals = await query("SELECT COUNT(*) AS total FROM donors");
    const groups = await query(
      `SELECT blood_group, COUNT(*) AS count
       FROM donors
       WHERE available = 1
       GROUP BY blood_group
       ORDER BY blood_group`
    );

    res.json({
      totalDonors: totals[0]?.total || 0,
      availableGroups: groups.map((g) => ({
        bloodGroup: g.blood_group,
        count: g.count,
      })),
    });
  } catch (err) {
    next(err);
  }
});

router.get("/:id/", requireAuth, requireSameDonor, async (req, res, next) => {
  try {
    const donorId = Number(req.params.id);
    if (!Number.isFinite(donorId)) return res.status(400).json({ message: "Invalid donor id." });

    const rows = await query(
      `SELECT d.*, COUNT(n.id) AS total_donations
       FROM donors d
       LEFT JOIN donations n ON n.donor_id = d.id
       WHERE d.id = ?
       GROUP BY d.id`,
      [donorId]
    );

    if (rows.length === 0) return res.status(404).json({ message: "Donor not found." });

    res.json(normalizeDonor(rows[0]));
  } catch (err) {
    next(err);
  }
});

router.get("/:id/donations/", requireAuth, requireSameDonor, async (req, res, next) => {
  try {
    const donorId = Number(req.params.id);
    if (!Number.isFinite(donorId)) return res.status(400).json({ message: "Invalid donor id." });

    const rows = await query(
      "SELECT id AS _id, date, hospital, units FROM donations WHERE donor_id = ? ORDER BY date DESC",
      [donorId]
    );

    res.json(rows);
  } catch (err) {
    next(err);
  }
});

router.patch("/:id/toggle/", requireAuth, requireSameDonor, async (req, res, next) => {
  try {
    const donorId = Number(req.params.id);
    if (!Number.isFinite(donorId)) return res.status(400).json({ message: "Invalid donor id." });

    const desired = req.body && typeof req.body.available === "boolean" ? req.body.available : null;

    if (desired === null) {
      await query("UPDATE donors SET available = NOT available WHERE id = ?", [donorId]);
    } else {
      await query("UPDATE donors SET available = ? WHERE id = ?", [desired ? 1 : 0, donorId]);
    }

    const rows = await query("SELECT * FROM donors WHERE id = ?", [donorId]);
    if (rows.length === 0) return res.status(404).json({ message: "Donor not found." });

    res.json(normalizeDonor(rows[0]));
  } catch (err) {
    next(err);
  }
});

router.patch("/:id/", requireAuth, requireSameDonor, async (req, res, next) => {
  try {
    const donorId = Number(req.params.id);
    if (!Number.isFinite(donorId)) return res.status(400).json({ message: "Invalid donor id." });

    const {
      name,
      age,
      gender,
      phone,
      email,
      city,
      address,
      medicalConditions,
    } = req.body || {};

    if (!name || !age || !gender || !city) {
      return res.status(400).json({ message: "Name, age, gender, and city are required." });
    }

    const normalizedPhone = normalizePhone(phone);
    const normalizedEmail = normalizeEmail(email);

    if (!normalizedPhone && !normalizedEmail) {
      return res.status(400).json({ message: "Provide at least an email address or mobile number." });
    }

    if (normalizedPhone) {
      const existingPhone = await query(
        `SELECT id
         FROM donors
         WHERE id <> ?
           AND (
             phone = ?
             OR REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(phone, ' ', ''), '-', ''), '(', ''), ')', ''), '+', '') = ?
           )
         LIMIT 1`,
        [donorId, normalizedPhone, phoneDigitsOnly(normalizedPhone)]
      );

      if (existingPhone.length > 0) {
        return res.status(409).json({ message: "Donor with this mobile number already exists." });
      }
    }

    if (normalizedEmail) {
      const existingEmail = await query(
        "SELECT id FROM donors WHERE id <> ? AND LOWER(email) = ? LIMIT 1",
        [donorId, normalizedEmail]
      );

      if (existingEmail.length > 0) {
        return res.status(409).json({ message: "Donor with this email already exists." });
      }
    }

    await query(
      `UPDATE donors
       SET name = ?, age = ?, gender = ?, phone = ?, email = ?, city = ?, address = ?, medical_conditions = ?
       WHERE id = ?`,
      [
        String(name).trim(),
        Number(age),
        String(gender).trim(),
        normalizedPhone || null,
        normalizedEmail || null,
        String(city).trim(),
        address || null,
        medicalConditions || null,
        donorId,
      ]
    );

    const rows = await query(
      `SELECT d.*, COUNT(n.id) AS total_donations
       FROM donors d
       LEFT JOIN donations n ON n.donor_id = d.id
       WHERE d.id = ?
       GROUP BY d.id`,
      [donorId]
    );

    if (rows.length === 0) return res.status(404).json({ message: "Donor not found." });
    res.json(normalizeDonor(rows[0]));
  } catch (err) {
    next(err);
  }
});

module.exports = router;
